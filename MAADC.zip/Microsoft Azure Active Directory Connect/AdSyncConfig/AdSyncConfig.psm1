﻿<# 
 
.SYNOPSIS
    Prepares Active Directory configuration for various purposes.

.DESCRIPTION

    AdSyncConfig.psm1 is a Windows PowerShell script module that provides functions that are
    used to prepare your Active Directory forest and domains for Azure AD Connect Sync
    features.
#>

#----------------------------------------------------------
# STATIC VARIABLES
#----------------------------------------------------------
# Well known SIDS
$selfSid = "S-1-5-10"
$enterpriseDomainControllersSid = "S-1-5-9"

# Regex variables
$distinguishedNameRegex = [Regex] '^(?:(?<cn>CN=(?<name>[^,]*)),)?(?:(?<path>(?:(?:CN|OU)=[^,]+,?)+),)?(?<domain>(?:DC=[^,]+,?)+)$'
$defaultADobjProperties = @('UserPrincipalName','ObjectGUID','ObjectSID','mS-DS-ConsistencyGuid','sAMAccountName','objectSid')

# Parameter variables
$commaSeparator =","
$periodSeparator = "."
$colonSeparator = ":"
$atSeparator = "@"
$aclSeparator = '" "'
$inheritanceSubObjectsOnly = 'S'
$inheritanceThisAndSubObjects = 'T'
$inheritanceNone = 'N'

<#
    .SYNOPSIS
        Tighten permissions on an AD object that is not otherwise included in any AD protected security group.
        A typical example is the AD Connect account (MSOL) created by AAD Connect automatically. This account
        has replicate permissions on all domains, however can be easily compromised as it is not protected.

    .DESCRIPTION
        The Set-ADSyncRestrictedPermissions Function will tighten permissions oo the 
        account provided. Tightening permissions involves the following steps:
        1. Disable inheritance on the specified object
        2. Remove all ACEs on the specific object, except ACEs specific to SELF. We want to keep
           the default permissions intact when it comes to SELF.
        3. Assign these specific permissions:

                Type	Name										Access				Applies To
                =============================================================================================
                Allow	SYSTEM										Full Control		This object
                Allow	Enterprise Admins							Full Control		This object
                Allow	Domain Admins								Full Control		This object
                Allow	Administrators								Full Control		This object

                Allow	Enterprise Domain Controllers				List Contents
                                                                    Read All Properties
                                                                    Read Permissions	This object

                Allow	Authenticated Users							List Contents
                                                                    Read All Properties
                                                                    Read Permissions	This object

    .PARAMETER ADConnectorAccountDN
        DistinguishedName of the Active Directory account whose permissions need to be tightened. This is typically the MSOL_nnnnnnnnnn 
        account or a custom domain account that is configured in your AD Connector.

    .PARAMETER Credential
        Administrator credential that has the necessary privileges to restrict the permissions on the ADConnectorAccountDN account. 
        This is typically the Enterprise or Domain administrator. 
        Use the fully qualified domain name of the administrator account to avoid account lookup failures. Example: CONTOSO\admin

    .PARAMETER DisableCredentialValidation
        When DisableCredentialValidation is used, the function will not check if the credentials provided in -Credential are valid in AD 
        and if the account provided has the necessary privileges to restrict the permissions on the ADConnectorAccountDN account.

    .PARAMETER TargetForest
        Optional parameter to configure a target forest instead of the one used by the current user context.

    .EXAMPLE
       Set-ADSyncRestrictedPermissions -ADConnectorAccountDN "CN=TestAccount1,CN=Users,DC=Contoso,DC=com" -Credential $(Get-Credential)
#>
Function Set-ADSyncRestrictedPermissions
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="high")]
    Param(
        [Parameter(Mandatory=$True)] 
        [string] $ADConnectorAccountDN,

        [Parameter(Mandatory=$True)] 
        [System.Management.Automation.PSCredential] $Credential,

        [Parameter(Mandatory=$False)] 
        [switch] $DisableCredentialValidation,

        [string] $TargetForest = $null
    )

    # Function init
    [string] $functionMsg = "Set-ADSyncRestrictedPermissions:"

    If (!$DisableCredentialValidation)
    {
        # Validate Credential
        TestCredential $Credential
    }

    If ($PSCmdlet.ShouldProcess($ADConnectorAccountDN, "Set restricted permissions")) 
    {
        $networkCredential = $Credential.GetNetworkCredential()
        If ($TargetForest)
        {
            $path = "LDAP://" + $TargetForest + "/" + $ADConnectorAccountDN	
        }
        Else
        {
            $path = "LDAP://" + $networkCredential.Domain + "/" + $ADConnectorAccountDN		
        }
        
        $de = New-Object System.DirectoryServices.DirectoryEntry($path, $Credential.UserName, $networkCredential.Password)
        $selfName = ConvertSIDtoName $selfSid			

        Try
        {	
            [System.DirectoryServices.DirectoryEntryConfiguration]$deOptions = $de.get_Options()
            $deOptions.SecurityMasks = [System.DirectoryServices.SecurityMasks]::Dacl
        }
        Catch
        {
            Throw "$functionMsg Failure using credential to access Active Directory. Error Details: $($_.Exception.Message)"
        }

        Try
        {
            Write-Output "$functionMsg Setting Restricted permissions on '$ADConnectorAccountDN'..."
            # disable inheritance on the object and remove inherited DACLs
            $de.ObjectSecurity.SetAccessRuleProtection($true, $false);

            # remove all DACLs on the object except SELF
            $acl = $de.ObjectSecurity.GetAccessRules($true, $false, [System.Security.Principal.NTAccount])
            ForEach ($ace in $acl) 
            {
                If ($ace.IdentityReference -ne $selfName) 
                {
                    $de.ObjectSecurity.RemoveAccessRule($ace) > $null
                }
            }

            # Add specific DACLs on the object
            # Add Full Control for SYSTEM
            $systemSid = New-Object System.Security.Principal.SecurityIdentifier([System.Security.Principal.WellKnownSidType]::LocalSystemSid, $null)
            $systemDacl = New-Object System.DirectoryServices.ActiveDirectoryAccessRule($systemSid, [System.DirectoryServices.ActiveDirectoryRights]::GenericAll, [System.Security.AccessControl.AccessControlType]::Allow)
            $de.ObjectSecurity.AddAccessRule($systemDacl)

            # Add Full Control for Enterprise Admins
            $eaSid = GetEnterpriseAdminsSid $Credential
            $eaDacl = New-Object System.DirectoryServices.ActiveDirectoryAccessRule($eaSid, [System.DirectoryServices.ActiveDirectoryRights]::GenericAll, [System.Security.AccessControl.AccessControlType]::Allow)
            $de.ObjectSecurity.AddAccessRule($eaDacl)

            # Add Full Control for Domain Admins
            $daSid = GetDomainAdminsSid $Credential
            $daDacl = New-Object System.DirectoryServices.ActiveDirectoryAccessRule($daSid, [System.DirectoryServices.ActiveDirectoryRights]::GenericAll, [System.Security.AccessControl.AccessControlType]::Allow)
            $de.ObjectSecurity.AddAccessRule($daDacl)

            # Add Full Control for Administrators
            $adminSid = New-Object System.Security.Principal.SecurityIdentifier([System.Security.Principal.WellKnownSidType]::BuiltinAdministratorsSid, $null)
            $adminDacl = New-Object System.DirectoryServices.ActiveDirectoryAccessRule($adminSid, [System.DirectoryServices.ActiveDirectoryRights]::GenericAll, [System.Security.AccessControl.AccessControlType]::Allow)
            $de.ObjectSecurity.AddAccessRule($adminDacl)

            # Add Generic Read for ENTERPRISE DOMAIN CONTROLLERS
            $edcSid = New-Object System.Security.Principal.SecurityIdentifier($enterpriseDomainControllersSid)
            $edcDacl = New-Object System.DirectoryServices.ActiveDirectoryAccessRule($edcSid, [System.DirectoryServices.ActiveDirectoryRights]::GenericRead, [System.Security.AccessControl.AccessControlType]::Allow)
            $de.ObjectSecurity.AddAccessRule($edcDacl)

            # Add Generic Read for Authenticated Users
            $authenticatedUsersSid = New-Object System.Security.Principal.SecurityIdentifier([System.Security.Principal.WellKnownSidType]::AuthenticatedUserSid, $null)
            $authenticatedUsersDacl = New-Object System.DirectoryServices.ActiveDirectoryAccessRule($authenticatedUsersSid, [System.DirectoryServices.ActiveDirectoryRights]::GenericRead, [System.Security.AccessControl.AccessControlType]::Allow)
            $de.ObjectSecurity.AddAccessRule($authenticatedUsersDacl)

            $de.CommitChanges()
        }
        Catch [Exception]
        {
            Throw "$functionMsg Setting Restricted permissions on $ADConnectorAccountDN failed. Error Details: $($_.Exception.Message)"
        }
        Finally
        {
            If ($de -ne $null)
            {
                $de.Dispose()
            }			
        }
    }
}

<#
    .SYNOPSIS
        Initialize your Active Directory forest and domain for password hash synchronization.

    .DESCRIPTION
        The Set-ADSyncPasswordHashSyncPermissions Function will give required permissions to the AD synchronization account, which include the following:
        1. Replicating Directory Changes
        2. Replicating Directory Changes All

        These permissions are given to all domains in the forest.

    .PARAMETER ADConnectorAccountName
        The Name of the Active Directory account that will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDomain
        The Domain of the Active Directory account that will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDN
        The DistinguishedName of the Active Directory account that will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER TargetForest
        Optional parameter to configure a target forest instead of the one used by the current user context.

    .PARAMETER TargetForestCredential
        Required if the TargetForest parameter is used. Credentials that will be used to perform operations on the target forest.

    .EXAMPLE
       Set-ADSyncPasswordHashSyncPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com'

    .EXAMPLE
       Set-ADSyncPasswordHashSyncPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com'

#>
Function Set-ADSyncPasswordHashSyncPermissions
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="high")]
    Param
    (
        # AD Connector Account Name used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountName,

        # AD Connector Account Domain used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDomain,

        # AD Connector Account DistinguishedName used by Azure AD Connect Sync
        [Parameter(ParameterSetName='DistinguishedName', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDN,

        # Forest to set the permissions on
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $TargetForest = $null,

        # Credentials used to configure the permissions
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [System.Management.Automation.PSCredential] $TargetForestCredential = $null
    )

    # Resolve AD Connector account identity on AD
    $ADConnectorIdentity = ResolveADobject -IdentityName $ADConnectorAccountName -IdentityDomain $ADConnectorAccountDomain -IdentityDN $ADConnectorAccountDN `
                            -IdentityParameterSet $($PSCmdlet.ParameterSetName) -ReturnADobject -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential

    $ADConnectorAccountSid = $ADConnectorIdentity.objectSid

    # Define AD ACL
    $acls = "`"$ADConnectorAccountSid" + ":CA;Replicating Directory Changes`"" + " " 
    $acls += "`"$ADConnectorAccountSid" + ":CA;Replicating Directory Changes All`""

    # Set root permissions for all Domains in the Forest
    $message = "Grant Password Hash Synchronization permissions"
    GrantADPermissionsOnAllDomains -ACL $acls -Message $message -Inheritance $inheritanceNone -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
}

<#
    .SYNOPSIS
        Initialize your Active Directory forest and domain for password write-back from Azure AD.

    .DESCRIPTION
        The Set-ADSyncPasswordWritebackPermissions Function will give required permissions to the AD synchronization account, which include the following:
        1. Reset Password on descendant user objects
        2. Write Property access on lockoutTime attribute for all descendant user objects
        3. Write Property access on pwdLastSet attribute for all descendant user objects

        These permissions are applied to all domains in the forest.
        Optionally you can provide a DistinguishedName in ADobjectDN parameter to set these permissions on that AD Object only (including inheritance to sub objects).

    .PARAMETER ADConnectorAccountName
        The Name of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDomain
        The Domain of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDN
        The DistinguishedName of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER IncludeAdminSDHolders
        Optional parameter to indicate if AdminSDHolder container should be updated with these permissions

    .PARAMETER TargetForest
        Optional parameter to configure a target forest instead of the one used by the current user context.

    .PARAMETER TargetForestCredential
        Required if the TargetForest parameter is used. Credentials that will be used to perform operations on the target forest.

    .EXAMPLE
       Set-ADSyncPasswordWritebackPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com'

    .EXAMPLE
       Set-ADSyncPasswordWritebackPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com'

    .EXAMPLE
       Set-ADSyncPasswordWritebackPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com' -IncludeAdminSDHolders

    .EXAMPLE
       Set-ADSyncPasswordWritebackPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com' -ADobjectDN 'OU=AzureAD,DC=Contoso,DC=com'
#>
Function Set-ADSyncPasswordWritebackPermissions
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="high")]
    Param
    (
        # AD Connector Account Name used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountName,

        # AD Connector Account Domain used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDomain,

        # AD Connector Account DistinguishedName used by Azure AD Connect Sync
        [Parameter(ParameterSetName='DistinguishedName', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDN,

        # DistinguishedName of the target AD object to set permissions (optional)
        [string] $ADobjectDN = $null,
        
        # Update permissions on the AdminSdHolders container (optional)
        [switch] $IncludeAdminSDHolders = $false,

        # Forest to set the permissions on
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $TargetForest = $null,

        # Credentials used to configure the permissions
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [System.Management.Automation.PSCredential] $TargetForestCredential = $null
    )

    # Resolve AD Connector account identity on AD
    $ADConnectorIdentity = ResolveADobject -IdentityName $ADConnectorAccountName -IdentityDomain $ADConnectorAccountDomain -IdentityDN $ADConnectorAccountDN `
                            -IdentityParameterSet $($PSCmdlet.ParameterSetName) -ReturnADobject -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential

    $ADConnectorAccountSid = $ADConnectorIdentity.objectSid

    # Define AD ACL
    $acls = "`"$ADConnectorAccountSid" + ":CA;Reset Password;user`"" + " "
    $acls += "`"$ADConnectorAccountSid" + ":WP;lockoutTime;user`"" + " "
    $acls += "`"$ADConnectorAccountSid" + ":WP;pwdLastSet;user`""

    # Check if setting permissions on a AD object only
    $message = "Grant Password Writeback permissions"

    If (![string]::IsNullOrEmpty($ADobjectDN))
    {
        # Get target AD Object
        Write-Verbose "Set-ADSyncPasswordWritebackPermissions: Get AD user object > Get-ADObject -SearchBase $ADobjectDN -SearchScope Base -Filter * "
        $errorMsg = "Set-ADSyncPasswordWritebackPermissions: Unable to find Active Directory object '$ADobjectDN'. "
        $object = Get-ADSyncADObject $ADobjectDN $errorMsg

        # Define Inheritance Type
        $objectInheritanceType = $inheritanceThisAndSubObjects
        If (($object.objectclass -eq 'container') -or ($object.objectclass -eq 'organizationalUnit') -or ($object.objectclass -eq 'domainDNS'))
        {
            $objectInheritanceType = $inheritanceSubObjectsOnly
        }

        # Set AD Permissions on a target AD object
        Write-Verbose "Set-ADSyncPasswordWritebackPermissions: Calling GrantADPermissionsOnADobject on target object '$ADobjectDN' with inheritanceType = '$objectInheritanceType'..."
        GrantADPermissionsOnADobject -ACL $acls -ADobjectDN $ADobjectDN -Message $message -InheritanceType $objectInheritanceType -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential

        # In case target ADObjectDN is a domain root, set Unexpire Password for the domain
        # Note: Unexpire Password permissions are only applicable on a domain root object (i.e. domainDNS objectClass)
        if ($object.objectclass -eq 'domainDNS')
        {
            # Define Inheritance Type for Unexpire Password
            $objectInheritanceType = $inheritanceThisAndSubObjects

            # Set ACL for Unexpire Password on the domain's root (domainDNS)
            $acls = "`"$ADConnectorAccountSid" + ":CA;Unexpire Password;`""
            $message = "Grant Password Writeback permission for Unexpire Password extended right"
            GrantADPermissionsOnADobject -ACL $acls -ADobjectDN $ADobjectDN -Message $message -InheritanceType $objectInheritanceType -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
        }
    }
    Else
    {
        # Set root permissions for all Domains in the Forest
        Write-Verbose "Set-ADSyncPasswordWritebackPermissions: Calling GrantADPermissionsOnAllDomains on all domain's root"
        GrantADPermissionsOnAllDomains -ACL $acls -Message $message -IncludeAdminSDHolders:$IncludeAdminSDHolders -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential

        # Define Inheritance Type for Unexpire Password
        $objectInheritanceType = $inheritanceThisAndSubObjects

        # Set ACL for Unexpire Password on all domains in the forest
        $acls = "`"$ADConnectorAccountSid" + ":CA;Unexpire Password;`""
        $message = "Grant Password Writeback permission for Unexpire Password extended right"
        GrantADPermissionsOnAllDomains -ACL $acls -Message $message -Inheritance $objectInheritanceType -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
    }
}

<#
    .SYNOPSIS
        Initialize your Active Directory forest and domain for Group writeback from Azure AD.

    .DESCRIPTION
        The Set-ADSyncUnifiedGroupWritebackPermissions Function will give required permissions to the AD synchronization account, which include the following:
        1. Generic Read/Write, Delete, Delete Tree and Create\Delete Child for Group Object types and SubObjects

        These permissions are applied to all domains in the forest.
        Optionally you can provide a DistinguishedName in ADobjectDN parameter to set these permissions on that AD Object only (including inheritance to sub objects).
        In this case, ADobjectDN will be the Distinguished Name of the Container that you desire to link with the GroupWriteback feature.

    .PARAMETER ADConnectorAccountName
        The Name of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDomain
        The Domain of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDN
        The DistinguishedName of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER includeAdminSDHolders
        Optional parameter to indicate if AdminSDHolder container should be updated with these permissions

    .PARAMETER TargetForest
        Optional parameter to configure a target forest instead of the one used by the current user context.

    .PARAMETER TargetForestCredential
        Required if the TargetForest parameter is used. Credentials that will be used to perform operations on the target forest.

    .EXAMPLE
       Set-ADSyncUnifiedGroupWritebackPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com'

    .EXAMPLE
       Set-ADSyncUnifiedGroupWritebackPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com'

    .EXAMPLE
       Set-ADSyncUnifiedGroupWritebackPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com' -IncludeAdminSDHolders

    .EXAMPLE
       Set-ADSyncUnifiedGroupWritebackPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com' -ADobjectDN 'OU=AzureAD,DC=Contoso,DC=com'
#>
Function Set-ADSyncUnifiedGroupWritebackPermissions
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="high")]
    Param
    (
        # AD Connector Account Name used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountName,

        # AD Connector Account Domain used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDomain,

        # AD Connector Account DistinguishedName used by Azure AD Connect Sync
        [Parameter(ParameterSetName='DistinguishedName', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDN,

        # DistinguishedName of the target AD object to set permissions (optional)
        [string] $ADobjectDN = $null,
        
        # Update permissions on the AdminSdHolders container (optional)
        [switch] $IncludeAdminSDHolders = $false,

        # Forest to set the permissions on
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $TargetForest = $null,

        # Credentials used to configure the permissions
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [System.Management.Automation.PSCredential] $TargetForestCredential = $null
    )

	# Ensure the function is being run as Administrator
    $isRunningAsAdmin = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")
    If (!$isRunningAsAdmin)
    {
        Write-Error "This cmdlet must be run in an elevated PowerShell window."
        return
    }

    # Resolve AD Connector account identity on AD
    $ADConnectorIdentity = ResolveADobject -IdentityName $ADConnectorAccountName -IdentityDomain $ADConnectorAccountDomain -IdentityDN $ADConnectorAccountDN `
                            -IdentityParameterSet $($PSCmdlet.ParameterSetName) -ReturnADobject -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential

    $ADConnectorAccountSid = $ADConnectorIdentity.objectSid

    # Check if setting permissions on a AD object only
    $message = "Grant Group Writeback permissions"

    If (![string]::IsNullOrEmpty($ADobjectDN))
    {
        # Get target AD Object
        Write-Verbose "Set-ADSyncUnifiedGroupWritebackPermissions: Get AD user object > Get-ADObject -SearchBase $ADobjectDN -SearchScope Base -Filter * "
        $errorMsg = "Set-ADSyncUnifiedGroupWritebackPermissions: Unable to find Active Directory object '$ADobjectDN'. "
        $object = Get-ADSyncADObject $ADobjectDN $errorMsg        

        # Set AD Permissions on a target AD object and apply different inheritance flags as necessary       
        If (($object.objectclass -eq 'container') -or ($object.objectclass -eq 'organizationalUnit') -or ($object.objectclass -eq 'domainDNS'))
        {
            # Create/Delete Child group objects applies to the AD object and all children
            Write-Verbose "Set-ADSyncUnifiedGroupWritebackPermissions: Calling GrantADPermissionsOnADobject on target object '$ADobjectDN' with inheritanceType = '$inheritanceThisAndSubObjects'..."
            $acls  = "`"$ADConnectorAccountSid" + ":CCDC;group;`""
            GrantADPermissionsOnADobject -ACL $acls -ADobjectDN $ADobjectDN -Message $message -InheritanceType $inheritanceThisAndSubObjects -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential

            # Generic Read/Write, Delete object, and Delete tree applies to child inherited group objects of the AD object
            Write-Verbose "Set-ADSyncUnifiedGroupWritebackPermissions: Calling GrantADPermissionsOnADobject on target object '$ADobjectDN' with inheritanceType = '$inheritanceSubObjectsOnly'..."
            $acls = "`"$ADConnectorAccountSid" + ":GRGWSDDT;;group`""
            GrantADPermissionsOnADobject -ACL $acls -ADobjectDN $ADobjectDN -Message $message -InheritanceType $inheritanceSubObjectsOnly -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
        }
        Else
        {
            Throw "Group writeback permissions can only be set on a Active Directory Domain, Organizational Unit or Container object."
        }
    }
    Else
    {
        # Define AD ACL
	    # Create/Delete Child group objects applies to the AD object and all children
        $acls = "`"$ADConnectorAccountSid" + ":CCDC;group;`"" + " "
        # Generic Read/Write, Delete object, and Delete tree applies to child inherited group objects of the AD object
        $acls += "`"$ADConnectorAccountSid" + ":GRGWSDDT;;group`""

        # Set root permissions for all Domains in the Forest
        Write-Verbose "Set-ADSyncUnifiedGroupWritebackPermissions: Calling GrantADPermissionsOnAllDomains on all domain's root"
        GrantADPermissionsOnAllDomains -ACL $acls -Message $message -IncludeAdminSDHolders:$IncludeAdminSDHolders -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
    }
}

<#
    .SYNOPSIS
        Initialize your Active Directory forest and domain for mS-DS-ConsistencyGuid feature.

    .DESCRIPTION
        The Set-ADSyncMsDsConsistencyGuidPermissions Function will give required permissions to the AD synchronization account, which include the following:
        1. Read/Write Property access on mS-DS-ConsistencyGuid attribute for all descendant user and group objects

        These permissions are applied to all domains in the forest.
        Optionally you can provide a DistinguishedName in ADobjectDN parameter to set these permissions on that AD Object only (including inheritance to sub objects).

    .PARAMETER ADConnectorAccountName
        The Name of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDomain
        The Domain of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDN
        The DistinguishedName of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER includeAdminSDHolders
        Optional parameter to indicate if AdminSDHolder container should be updated with these permissions

    .PARAMETER TargetForest
        Optional parameter to configure a target forest instead of the one used by the current user context.

    .PARAMETER TargetForestCredential
        Required if the TargetForest parameter is used. Credentials that will be used to perform operations on the target forest.

    .EXAMPLE
       Set-ADSyncMsDsConsistencyGuidPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com'

    .EXAMPLE
       Set-ADSyncMsDsConsistencyGuidPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com'

    .EXAMPLE
       Set-ADSyncMsDsConsistencyGuidPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com' -IncludeAdminSDHolders

    .EXAMPLE
       Set-ADSyncMsDsConsistencyGuidPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com' -ADobjectDN 'OU=AzureAD,DC=Contoso,DC=com'
#>
Function Set-ADSyncMsDsConsistencyGuidPermissions
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="high")]
    Param(
        # AD Connector Account Name used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountName,

        # AD Connector Account Domain used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDomain,

        # AD Connector Account DistinguishedName used by Azure AD Connect Sync
        [Parameter(ParameterSetName='DistinguishedName', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDN,

        # DistinguishedName of the target AD object to set permissions (optional)
        [string] $ADobjectDN = $null,
        
        # Update permissions on the AdminSdHolders container (optional)
        [switch] $IncludeAdminSDHolders = $false,

        # Forest to set the permissions on
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $TargetForest = $null,

        # Credentials used to configure the permissions
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [System.Management.Automation.PSCredential] $TargetForestCredential = $null
    )	

    # Resolve AD Connector account identity on AD
    $ADConnectorIdentity = ResolveADobject -IdentityName $ADConnectorAccountName -IdentityDomain $ADConnectorAccountDomain -IdentityDN $ADConnectorAccountDN `
                            -IdentityParameterSet $($PSCmdlet.ParameterSetName) -ReturnADobject -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential

    $ADConnectorAccountSid = $ADConnectorIdentity.objectSid

    # Define AD ACL
    $acls = "`"$ADConnectorAccountSid" + ":RPWP;mS-DS-ConsistencyGuid;user`"" + " "
    $acls += "`"$ADConnectorAccountSid" + ":RPWP;mS-DS-ConsistencyGuid;group`""

    # Check if setting permissions on a AD object only
    $message = "Grant mS-DS-ConsistencyGuid permissions"

    If (![string]::IsNullOrEmpty($ADobjectDN))
    {
        # Get target AD Object
        Write-Verbose "Set-ADSyncMsDsConsistencyGuidPermissions: Get AD user object > Get-ADObject -SearchBase $ADobjectDN -SearchScope Base -Filter * "
        $errorMsg = "Set-ADSyncMsDsConsistencyGuidPermissions: Unable to find Active Directory object '$ADobjectDN'. "
        $object = Get-ADSyncADObject $ADobjectDN $errorMsg

        # Define Inheritance Type
        $objectInheritanceType = $inheritanceThisAndSubObjects
        If (($object.objectclass -eq 'container') -or ($object.objectclass -eq 'organizationalUnit') -or ($object.objectclass -eq 'domainDNS'))
        {
            $objectInheritanceType = $inheritanceSubObjectsOnly
        }

        # Set AD Permissions on a target AD object
        Write-Verbose "Set-ADSyncMsDsConsistencyGuidPermissions: Calling GrantADPermissionsOnADobject on target object '$ADobjectDN' with inheritanceType = '$objectInheritanceType'..."
        GrantADPermissionsOnADobject -ACL $acls -ADobjectDN $ADobjectDN -Message $message -InheritanceType $objectInheritanceType -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
    }
    Else
    {
        # Set root permissions for all Domains in the Forest
        Write-Verbose "Set-ADSyncMsDsConsistencyGuidPermissions: Calling GrantADPermissionsOnAllDomains on all domain's root"
        GrantADPermissionsOnAllDomains -ACL $acls -Message $message -IncludeAdminSDHolders:$IncludeAdminSDHolders -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
    }
}

<#
    .SYNOPSIS
        Initialize your Active Directory forest and domain for Exchange Mail Public Folder feature.

    .DESCRIPTION
        The Set-ADSyncExchangeMailPublicFolderPermissions Function will give required permissions to the AD synchronization account, which include the following:
        1. Read Property access on all attributes for all descendant publicfolder objects

        These permissions are applied to all domains in the forest.
        Optionally you can provide a DistinguishedName in ADobjectDN parameter to set these permissions on that AD Object only (including inheritance to sub objects).

    .PARAMETER ADConnectorAccountName
        The Name of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDomain
        The Domain of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDN
        The DistinguishedName of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER includeAdminSDHolders
        Optional parameter to indicate if AdminSDHolder container should be updated with these permissions

    .PARAMETER TargetForest
        Optional parameter to configure a target forest instead of the one used by the current user context.

    .PARAMETER TargetForestCredential
        Required if the TargetForest parameter is used. Credentials that will be used to perform operations on the target forest.

    .EXAMPLE
       Set-ADSyncExchangeMailPublicFolderPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com'

    .EXAMPLE
       Set-ADSyncExchangeMailPublicFolderPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com'

    .EXAMPLE
       Set-ADSyncExchangeMailPublicFolderPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com' -IncludeAdminSDHolders

    .EXAMPLE
       Set-ADSyncExchangeMailPublicFolderPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com' -ADobjectDN 'OU=AzureAD,DC=Contoso,DC=com'
#>
Function Set-ADSyncExchangeMailPublicFolderPermissions
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="high")]
    Param(
        # AD Connector Account Name used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountName,

        # AD Connector Account Domain used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDomain,

        # AD Connector Account DistinguishedName used by Azure AD Connect Sync
        [Parameter(ParameterSetName='DistinguishedName', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDN,

        # DistinguishedName of the target AD object to set permissions (optional)
        [string] $ADobjectDN = $null,
        
        # Update permissions on the AdminSdHolders container (optional)
        [switch] $IncludeAdminSDHolders = $false,

        # Forest to set the permissions on
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $TargetForest = $null,

        # Credentials used to configure the permissions
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [System.Management.Automation.PSCredential] $TargetForestCredential = $null
    )

    # Resolve AD Connector account identity on AD
    $ADConnectorIdentity = ResolveADobject -IdentityName $ADConnectorAccountName -IdentityDomain $ADConnectorAccountDomain -IdentityDN $ADConnectorAccountDN `
                            -IdentityParameterSet $($PSCmdlet.ParameterSetName) -ReturnADobject -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential

    $ADConnectorAccountSid = $ADConnectorIdentity.objectSid

    # Define AD ACL
    $acls = "`"$ADConnectorAccountSid" + ":RP;;publicFolder`""

    # Check if setting permissions on a AD object only
    $message = "Grant Exchange Mail Public Folder permissions"
    If (![string]::IsNullOrEmpty($ADobjectDN))
    {
        # Get target AD Object
        Write-Verbose "Set-ADSyncExchangeMailPublicFolderPermissions: Get AD user object > Get-ADObject -SearchBase $ADobjectDN -SearchScope Base -Filter * "
        $errorMsg = "Set-ADSyncExchangeMailPublicFolderPermissions: Unable to find Active Directory object '$ADobjectDN'. "
        $object = Get-ADSyncADObject $ADobjectDN $errorMsg

        # Define Inheritance Type
        $objectInheritanceType = $inheritanceThisAndSubObjects
        If (($object.objectclass -eq 'container') -or ($object.objectclass -eq 'organizationalUnit') -or ($object.objectclass -eq 'domainDNS'))
        {
            $objectInheritanceType = $inheritanceSubObjectsOnly
        }

        # Set AD Permissions on a target AD object
        Write-Verbose "Set-ADSyncExchangeMailPublicFolderPermissions: Calling GrantADPermissionsOnADobject on target object '$ADobjectDN' with inheritanceType = '$objectInheritanceType'..."
        GrantADPermissionsOnADobject -ACL $acls -ADobjectDN $ADobjectDN -Message $message -InheritanceType $objectInheritanceType -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
    }
    Else
    {
        # Set root permissions for all Domains in the Forest
        Write-Verbose "Set-ADSyncExchangeMailPublicFolderPermissions: Calling GrantADPermissionsOnAllDomains on all domain's root"
        GrantADPermissionsOnAllDomains -ACL $acls -Message $message -IncludeAdminSDHolders:$IncludeAdminSDHolders -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
    }
}

<#.SYNOPSIS
        Initialize your Active Directory forest and domain for Exchange Hybrid feature.

    .DESCRIPTION
        The Set-ADSyncExchangeHybridPermissions Function will give required permissions to the 
        AD synchronization account, which include the following:
        1. Read/Write Property access on all attributes for all descendant user objects
        2. Read/Write Property access on all attributes for all descendant inetOrgPerson objects
        3. Read/Write Property access on all attributes for all descendant group objects
        4. Read/Write Property access on all attributes for all descendant contact objects

        These permissions are applied to all domains in the forest.
        Optionally you can provide a DistinguishedName in ADobjectDN parameter to set these permissions on that AD Object only (including inheritance to sub objects).

    .PARAMETER ADConnectorAccountName
        The Name of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDomain
        The Domain of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDN
        The DistinguishedName of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER includeAdminSDHolders
        Optional parameter to indicate if AdminSDHolder container should be updated with these permissions

    .PARAMETER TargetForest
        Optional parameter to configure a target forest instead of the one used by the current user context.

    .PARAMETER TargetForestCredential
        Required if the TargetForest parameter is used. Credentials that will be used to perform operations on the target forest.

    .EXAMPLE
       Set-ADSyncExchangeHybridPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com'

    .EXAMPLE
       Set-ADSyncExchangeHybridPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com'

    .EXAMPLE
       Set-ADSyncExchangeHybridPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com' -IncludeAdminSDHolders

    .EXAMPLE
       Set-ADSyncExchangeHybridPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com' -ADobjectDN 'OU=AzureAD,DC=Contoso,DC=com'
#>
Function Set-ADSyncExchangeHybridPermissions
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="high")]
    Param
    (
        # AD Connector Account Name used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountName,

        # AD Connector Account Domain used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDomain,

        # AD Connector Account DistinguishedName used by Azure AD Connect Sync
        [Parameter(ParameterSetName='DistinguishedName', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDN,

        # DistinguishedName of the target AD object to set permissions (optional)
        [string] $ADobjectDN = $null,
        
        # Update permissions on the AdminSdHolders container (optional)
        [switch] $IncludeAdminSDHolders = $false,

        # Forest to set the permissions on
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $TargetForest = $null,

        # Credentials used to configure the permissions
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [System.Management.Automation.PSCredential] $TargetForestCredential = $null
    )

    # Resolve AD Connector account identity on AD
    $ADConnectorIdentity = ResolveADobject -IdentityName $ADConnectorAccountName -IdentityDomain $ADConnectorAccountDomain -IdentityDN $ADConnectorAccountDN `
                            -IdentityParameterSet $($PSCmdlet.ParameterSetName) -ReturnADobject -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
    
    $ADConnectorAccountSid = $ADConnectorIdentity.objectSid

    # Define AD ACL
    $acls  = "`"$ADConnectorAccountSid" + ":RPWP;;user`"" + " "
    $acls += "`"$ADConnectorAccountSid" + ":RPWP;;inetOrgPerson`"" + " "
    $acls += "`"$ADConnectorAccountSid" + ":RPWP;;group`"" + " "
    $acls += "`"$ADConnectorAccountSid" + ":RPWP;;contact`""

    # Check if setting permissions on a AD object only
    $message = "Grant Exchange Hybrid permissions"
    If (![string]::IsNullOrEmpty($ADobjectDN))
    {
        # Get target AD Object
        Write-Verbose "Set-ADSyncExchangeHybridPermissions: Get AD user object > Get-ADObject -SearchBase $ADobjectDN -SearchScope Base -Filter * "
        $errorMsg = "Set-ADSyncExchangeHybridPermissions: Unable to find Active Directory object '$ADobjectDN'. "
        $object = Get-ADSyncADObject $ADobjectDN $errorMsg

        # Define Inheritance Type
        $objectInheritanceType = $inheritanceThisAndSubObjects
        If (($object.objectclass -eq 'container') -or ($object.objectclass -eq 'organizationalUnit') -or ($object.objectclass -eq 'domainDNS'))
        {
            $objectInheritanceType = $inheritanceSubObjectsOnly
        }

        # Set AD Permissions on a target AD object
        Write-Verbose "Set-ADSyncExchangeHybridPermissions: Calling GrantADPermissionsOnADobject on target object '$ADobjectDN' with inheritanceType = '$objectInheritanceType'..."
        GrantADPermissionsOnADobject -ACL $acls -ADobjectDN $ADobjectDN -Message $message -InheritanceType $objectInheritanceType -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
    }
    Else
    {
        # Set root permissions for all Domains in the Forest
        Write-Verbose "Set-ADSyncExchangeHybridPermissions: Calling GrantADPermissionsOnAllDomains on all domain's root"
        GrantADPermissionsOnAllDomains -ACL $acls -Message $message -IncludeAdminSDHolders:$IncludeAdminSDHolders -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
    }
}

<#
    .SYNOPSIS
        Initialize your Active Directory forest and domain for basic read permissions.

    .DESCRIPTION
        The Set-ADSyncBasicReadPermissions Function will give required permissions to the AD synchronization account, which include the following:
        1. Read Property access on all attributes for all descendant computer objects
        2. Read Property access on all attributes for all descendant device objects
        3. Read Property access on all attributes for all descendant foreignsecurityprincipal objects
        5. Read Property access on all attributes for all descendant user objects
        6. Read Property access on all attributes for all descendant inetOrgPerson objects
        7. Read Property access on all attributes for all descendant group objects
        8. Read Property access on all attributes for all descendant contact objects

        These permissions are applied to all domains in the forest.
        Optionally you can provide a DistinguishedName in ADobjectDN parameter to set these permissions on that AD Object only (including inheritance to sub objects).

    .PARAMETER ADConnectorAccountName
        The Name of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDomain
        The Domain of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER ADConnectorAccountDN
        The DistinguishedName of the Active Directory account that is or will be used by Azure AD Connect Sync to manage objects in the directory.

    .PARAMETER includeAdminSDHolders
        Optional parameter to indicate if AdminSDHolder container should be updated with these permissions

    .PARAMETER TargetForest
        Optional parameter to configure a target forest instead of the one used by the current user context.

    .PARAMETER TargetForestCredential
        Required if the TargetForest parameter is used. Credentials that will be used to perform operations on the target forest.

    .EXAMPLE
       Set-ADSyncBasicReadPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com'

    .EXAMPLE
       Set-ADSyncBasicReadPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com'

    .EXAMPLE
       Set-ADSyncBasicReadPermissions -ADConnectorAccountDN 'CN=ADConnector,OU=AzureAD,DC=Contoso,DC=com' -IncludeAdminSDHolders

    .EXAMPLE
       Set-ADSyncBasicReadPermissions -ADConnectorAccountName 'ADConnector' -ADConnectorAccountDomain 'Contoso.com' -ADobjectDN 'OU=AzureAD,DC=Contoso,DC=com'
#>
Function Set-ADSyncBasicReadPermissions
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="high")]
    Param(
        # AD Connector Account Name used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountName,

        # AD Connector Account Domain used by Azure AD Connect Sync
        [Parameter(ParameterSetName='UserDomain', Mandatory=$True)]
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDomain,

        # AD Connector Account DistinguishedName used by Azure AD Connect Sync
        [Parameter(ParameterSetName='DistinguishedName', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $ADConnectorAccountDN,

        # DistinguishedName of the target AD object to set permissions (optional)
        [string] $ADobjectDN = $null,
        
        # Update permissions on the AdminSdHolders container (optional)
        [switch] $IncludeAdminSDHolders = $false,

        # Forest to set the permissions on
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [string] $TargetForest = $null,

        # Credentials used to configure the permissions
        [Parameter(ParameterSetName='UserDomainWithCredential', Mandatory=$True)]
        [Parameter(ParameterSetName='DistinguishedNameWithCredential', Mandatory=$True)]
        [System.Management.Automation.PSCredential] $TargetForestCredential = $null
    )

    # Resolve AD Connector account identity on AD
    $ADConnectorIdentity = ResolveADobject -IdentityName $ADConnectorAccountName -IdentityDomain $ADConnectorAccountDomain -IdentityDN $ADConnectorAccountDN `
                            -IdentityParameterSet $($PSCmdlet.ParameterSetName) -ReturnADobject -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential

    $ADConnectorAccountSid = $ADConnectorIdentity.objectSid

    # Define AD ACL
    $acls =  "`"$ADConnectorAccountSid" + ":RP;;computer`"" + " "
    $acls += "`"$ADConnectorAccountSid" + ":RP;;device`"" + " "
    $acls += "`"$ADConnectorAccountSid" + ":RP;;foreignsecurityprincipal`"" + " "
    $acls += "`"$ADConnectorAccountSid" + ":RP;;user`"" + " "
    $acls += "`"$ADConnectorAccountSid" + ":RP;;inetOrgPerson`"" + " "
    $acls += "`"$ADConnectorAccountSid" + ":RP;;group`"" + " "
    $acls += "`"$ADConnectorAccountSid" + ":RP;;contact`""
    
    # Check if setting permissions on a AD object only
    $message = "Grant basic read permissions"
    If (![string]::IsNullOrEmpty($ADobjectDN))
    {
        # Get target AD Object
        Write-Verbose "Set-ADSyncBasicReadPermissions: Get AD user object > Get-ADObject -SearchBase $ADobjectDN -SearchScope Base -Filter * "
        $errorMsg = "Set-ADSyncBasicReadPermissions: Unable to find Active Directory object '$ADobjectDN'. "
        $object = Get-ADSyncADObject $ADobjectDN $errorMsg

        # Define Inheritance Type
        $objectInheritanceType = $inheritanceThisAndSubObjects
        If (($object.objectclass -eq 'container') -or ($object.objectclass -eq 'organizationalUnit') -or ($object.objectclass -eq 'domainDNS'))
        {
            $objectInheritanceType = $inheritanceSubObjectsOnly
        }

        # Set AD Permissions on a target AD object
        Write-Verbose "Set-ADSyncBasicReadPermissions: Calling GrantADPermissionsOnADobject on target object '$ADobjectDN' with inheritanceType = '$objectInheritanceType'..."
        GrantADPermissionsOnADobject -ACL $acls -ADobjectDN $ADobjectDN -Message $message -InheritanceType $objectInheritanceType -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential

        # In case target ADObjectDN is a domain root, set Replicating Directory Changes/All permission for the domain
        # Note: Replicating Directory Changes/All permissions are only applicable on a domain root object (i.e. domainDNS objectClass)
        if ($object.objectclass -eq 'domainDNS')
        {
            # Set Replicating Directory Changes root permission for all Domains in the Forest.
            $acls = "`"$ADConnectorAccountSid" + ":CA;Replicating Directory Changes`"" + " "
            $acls += "`"$ADConnectorAccountSid" + ":CA;Replicating Directory Changes All`""

            $message += " > replicating directory changes"
            Write-Verbose "Set-ADSyncBasicReadPermissions: Calling GrantADPermissionsOnADobject for 'Replicating Directory Changes' permissions on target object '$ADobjectDN'"
            GrantADPermissionsOnADobject -ACL $acls -ADobjectDN $ADobjectDN -Message $message -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
        }
    }
    Else
    {
        # Set root permissions for all Domains in the Forest.
        Write-Verbose "Set-ADSyncBasicReadPermissions: Calling GrantADPermissionsOnAllDomains on all domain's root"
        GrantADPermissionsOnAllDomains -ACL $acls -Message $message -IncludeAdminSDHolders:$IncludeAdminSDHolders -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential

        # Set Replicating Directory Changes/All root permissions for all Domains in the Forest.
        # Note: Replicating Directory Changes/All permissions are only applicable on a domain root object (i.e. domainDNS objectClass)
        $acls = "`"$ADConnectorAccountSid" + ":CA;Replicating Directory Changes`"" + " "
        $acls += "`"$ADConnectorAccountSid" + ":CA;Replicating Directory Changes All`""

        $functionMsg = 'Grant permissions on all Domains:'
        $message += " > replicating directory changes"
        Write-Verbose "Set-ADSyncBasicReadPermissions: Calling GrantADPermissionsOnAllDomains for 'Replicating Directory Changes' permissions on all domain's root"
        GrantADPermissionsOnAllDomains -ACL $acls -Message $message -Inheritance $inheritanceNone -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
    }
}

<#
    .SYNOPSIS
        Gets AD objects with permission inheritance disabled

    .DESCRIPTION
        Searches in AD starting from the SearchBase parameter and returns all objects, filtered by ObjectClass parameter, that have the ACL Inheritance currently disabled.

    .PARAMETER SearchBase
        The SearchBase for the LDAP query that can be an AD Domain DistinguishedName or a FQDN

    .PARAMETER ObjectClass
        The class of the objects to search that can be '*' (for any object class), 'user', 'group', 'container', etc. By default, this function will search for 'organizationalUnit' object class.

    .PARAMETER TargetForest
        Optional parameter to configure a target forest instead of the one used by the current user context.

    .PARAMETER TargetForestCredential
        Required if the TargetForest parameter is used. Credentials that will be used to perform operations on the target forest.

    .EXAMPLE
        Find objects with disabled inheritance in 'Contoso' domain (by default returns 'organizationalUnit' objects only)
        Get-ADSyncObjectsWithInheritanceDisabled -SearchBase 'Contoso' 

    .EXAMPLE
        Find 'user' objects with disabled inheritance in 'Contoso' domain
        Get-ADSyncObjectsWithInheritanceDisabled -SearchBase 'Contoso' -ObjectClass 'user'

    .EXAMPLE
        Find all types of objects with disabled inheritance in a OU
        Get-ADSyncObjectsWithInheritanceDisabled -SearchBase OU=AzureAD,DC=Contoso,DC=com -ObjectClass '*'
#>
Function Get-ADSyncObjectsWithInheritanceDisabled
{
    [CmdletBinding()]
    Param
    (
        [Parameter(ParameterSetName='WithoutCredential', Mandatory=$True,Position=0)]
        [Parameter(ParameterSetName='WithCredential', Mandatory=$True,Position=0)]
        [String] $SearchBase,

        [Parameter(Mandatory=$False,Position=1)] 
        [String] $ObjectClass = 'organizationalUnit',

        [Parameter(ParameterSetName='WithCredential', Mandatory=$True)]
        [string] $TargetForest = $null,

        [Parameter(ParameterSetName='WithCredential', Mandatory=$True)]
        [System.Management.Automation.PSCredential] $TargetForestCredential = $null
    )

    # Function init
    [string] $functionMsg = "Get-ADSyncObjectsWithInheritanceDisabled:"

    Try
    {
        # Init a DirectorySearcher object
        If ($TargetForest)
        {
            $networkCredential = $TargetForestCredential.GetNetworkCredential()

            $directoryEntry = New-Object System.DirectoryServices.DirectoryEntry("LDAP://$TargetForest/$SearchBase", $TargetForestCredential.UserName, $networkCredential.Password)

            $ldapFilter = "(&(ObjectClass=$ObjectClass))"
            $directorySearcher = New-Object System.DirectoryServices.DirectorySearcher($directoryEntry, $ldapFilter)
            $directorySearcher.PageSize = 1000
        }
        Else
        {
            $ldapFilter = "(&(ObjectClass=$ObjectClass))"
            $directorySearcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]"LDAP://$SearchBase", $ldapFilter)
            $directorySearcher.PageSize = 1000
        }
    }
    Catch
    {
        Throw "$functionMsg Unable to search Active Directory. Error Details: $($_.Exception.Message)"
    }

    Try
    {
        # Search All Objects
        Write-Verbose "$functionMsg Searching for objects in AD with LDAP Filter: $ldapFilter"
        $allADobjects = $directorySearcher.FindAll()
    }
    Catch
    {
        Throw "$functionMsg Unable to query Active Directory. Error Details: $($_.Exception.Message)"
    }
    Finally
    {
        If ($directorySearcher -ne $null)
        {
            $directorySearcher.Dispose()
        }

        If ($directoryEntry -ne $null)
        {
            $directoryEntry.Dispose()
        }
    }

    # Check if Inheritance is Disabled
    Foreach ($object in $allADobjects) 
    {
        $object = $object.GetDirectoryEntry()
        Write-Verbose "$functionMsg $($object.DistinguishedName)"
        If ($object.ObjectSecurity.AreAccessRulesProtected -eq $True)
        {
            ResolveADobject -IdentityDN $object.DistinguishedName -IdentityParameterSet 'DistinguishedName' -ReturnADobject -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
        }
    }
}

<#
.Synopsis
   Shows permissions of a specified AD object.
.DESCRIPTION
   This function retuns all the AD permissions currently set for a given AD object provided in the parameter -ADobjectDN.
   The ADobjectDN must be provided in a DistinguishedName format.
 .PARAMETER TargetForestCredential
   Optional paramter if the target object is on a different forest than the current user context.
.EXAMPLE
   Show-ADSyncADObjectPermissions -ADobjectDN 'DC=Contoso,DC=com'
#>
Function Show-ADSyncADObjectPermissions
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$True,Position=0)] 
        [string] $ADobjectDN,

        [System.Management.Automation.PSCredential] $TargetForestCredential = $null
    )

    # Function init
    [string] $functionMsg = "Get-ADSyncADObjectPermissions:"

    # See more on dsacls.exe here: https://ss64.com/nt/dsacls.html
    $cmd = "dsacls.exe `"$ADobjectDN`""
    Write-Verbose "$functionMsg Executing command : $cmd"

    If ($TargetForestCredential)
    {
        $networkCredential = $TargetForestCredential.GetNetworkCredential()

        $domain = $networkCredential.Domain
        $user = $networkCredential.UserName
        $passwd = $networkCredential.Password

        $passwd = ReplaceReservedCharcters -PreReplace $passwd

        $result = dsacls.exe "`"$ADobjectDN`"" /domain:"`"$domain"`" /user:"`"$user"`" /passwd:"`"$passwd`""
    }
    Else
    {
        $result = dsacls.exe "`"$ADobjectDN`""
    }

    If ($lastexitcode -eq 0)
    {
        $result
    }
    Else
    {
        Throw "$functionMsg $result"
    }
}

<#
.Synopsis
   Gets the account name and domain that is configured in each AD Connector
.DESCRIPTION
   This function uses the 'Get-ADSyncConnector' cmdlet that is present in AAD Connect to retrieve from Connectivity Parameters a table showing the AD Connector(s) account.
.EXAMPLE
   Get-ADSyncADConnectorAccount
#>
Function Get-ADSyncADConnectorAccount
{
    [CmdletBinding()]
    $cmdlet = 'Get-ADSyncConnector'
    Try
    {
        Get-Command $cmdlet -ErrorAction Stop | Out-Null
    }
    Catch
    {
        Write-Error "Failure calling '$cmdlet' cmdlet. This function can only be executed with AAD Connect installed."
        Return $null
    }

    $adConnectors = Get-ADSyncConnector | where {$_.ConnectorTypeName -eq 'AD'}
    $adSyncADConnectorAccount = @()
    ForEach ($connector in $adConnectors)
    {
        $connectorAccount = "" | Select ADConnectorName, ADConnectorForest, ADConnectorAccountName, ADConnectorAccountDomain
        $connectorAccount.ADConnectorName = $connector.Name
        $connectorAccount.ADConnectorForest = ($connector.ConnectivityParameters | Where {$_.Name -eq 'forest-name'}).Value
        $connectorAccount.ADConnectorAccountName = ($connector.ConnectivityParameters | Where {$_.Name -eq 'forest-login-user'}).Value
        $connectorAccount.ADConnectorAccountDomain = ($connector.ConnectivityParameters | Where {$_.Name -eq 'forest-login-domain'}).Value
        $adSyncADConnectorAccount += $connectorAccount
    }
    $adSyncADConnectorAccount

}


# Gets an object from Active Directory based on its DN
Function Get-ADSyncADObject
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$True,Position=0)] 
        [string] $ADobjectDN,

        [Parameter(Mandatory=$True,Position=1)] 
        [string] $ErrorMsg
    )

    # Get target AD Object
    Try
    {
        Get-ADObject -SearchBase $ADobjectDN -SearchScope Base -Filter * -ErrorAction Stop
    }
    Catch [Microsoft.ActiveDirectory.Management.ADReferralException]
    {
        $ErrorMsg += "Try logging in with a Domain Administrator account in the same domain as the target object or use TargetForest/TargetForestCredential parameters. "
        Throw $ErrorMsg += "Error Details: $($_.Exception.Message)"
    }
    Catch
    {
        Throw $ErrorMsg += "Error Details: $($_.Exception.Message)"
    }

}

# Grants permissions to specified ObjectDN
Function GrantAcls
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$True,Position=0)] 
        [string] $ObjectDN,

        [Parameter(Mandatory=$True,Position=1)] 
        [string[]] $ACLs,

        [Parameter(Mandatory=$True,Position=2)] 
        [char] $InheritFlag,

        [System.Management.Automation.PSCredential] $TargetForestCredential
    )

    # See more on dsacls.exe here: https://ss64.com/nt/dsacls.html
    If ($TargetForestCredential)
    {
        $networkCredential = $TargetForestCredential.GetNetworkCredential()

        $domain = $networkCredential.Domain
        $user = $networkCredential.UserName
        $passwd = $networkCredential.Password

		If (!$domain) 
        {
            Write-Error "You must enter your Administrator credentials in a domain.com\username format."
            return
        }

        $passwd = ReplaceReservedCharcters -PreReplace $passwd
        
		$cmd = "dsacls.exe `"$ObjectDN`" /G $ACLs /I:$InheritFlag /domain:`"$domain`" /user:`"$user`""
		$cmdExecute = $cmd + " /passwd:`"$passwd`""
		$cmdTrace = $cmd + " /passwd:`"********`""
		Write-Verbose "Grant ACLs : Executing command : $cmdTrace"

        $result = Invoke-Expression $cmdExecute
    }
    Else
    {
		$cmd = "dsacls.exe `"$ObjectDN`" /G $ACLs /I:$InheritFlag"
		Write-Verbose "Grant ACLs : Executing command : $cmd"

        $result = Invoke-Expression $cmd
    }

    If ($lastexitcode -eq 0)
    {
        $result
        Write-Warning "You will need to perform a full import to include any objects that may have come in scope as a result of this operation."
    }
    Else
    {
        $noExchangeShemaError = $result | Where {$_ -like "*No GUID Found for publicFolder*"}
        If (($noExchangeShemaError | Measure-Object).Count -gt 0)
        {
            Write-Error "AD Schema for Exchange not present : $result"
        }
        Else
        {
            Write-Error "$result"
        }
    }
}

# Grants permissions to specified ObjectDN
Function GrantAclsNoInheritance
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$True,Position=0)] 
        [string] $ObjectDN,

        [Parameter(Mandatory=$True,Position=1)] 
        [string[]] $ACLs,

        [System.Management.Automation.PSCredential] $TargetForestCredential
    )

    # See more on dsacls.exe here: https://ss64.com/nt/dsacls.html
    If ($TargetForestCredential)
    {
        $networkCredential = $TargetForestCredential.GetNetworkCredential()

        $domain = $networkCredential.Domain
        $user = $networkCredential.UserName
        $passwd = $networkCredential.Password

		If (!$domain) 
        {
            Write-Error "You must enter your Administrator credentials in a domain.com\username format."
            return
        }

        $passwd = ReplaceReservedCharcters -PreReplace $passwd

		$cmd = "dsacls.exe `"$ObjectDN`" /G $ACLs /domain:`"$domain`" /user:`"$user`""
		$cmdExecute = $cmd + " /passwd:`"$passwd`""
		$cmdTrace = $cmd + " /passwd:`"********`""
		Write-Verbose "Grant ACLs without Inheritance : Executing command : $cmdTrace"

        $result = Invoke-Expression $cmdExecute
    }
    Else
    {
		$cmd = "dsacls.exe `"$ObjectDN`" /G $ACLs"
		Write-Verbose "Grant ACLs without Inheritance : Executing command : $cmd"

        $result = Invoke-Expression $cmd
    }

    If ($lastexitcode -eq 0)
    {
        $result
        Write-Warning "You will need to perform a full import to include any objects that may have come in scope as a result of this operation."
    }
    Else
    {
        Write-Error "$result"
    }

}

# Converts a FQDN to domain DistinguishedName
Function ConvertFQDNtoDN
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$True,Position=0)] 
        [String] 
        $FQDN
    )

    # Init of variable is required to prevent use of a session variable.
    $dn = ""

    # Convert each period separated domain name into a DistinguishedName
    ForEach ($domain in $($FQDN.Split($periodSeparator)))
    {
        $dn = $dn + $connector + "DC=" + $domain
        $connector = $commaSeparator
    }
    Return $dn
}

# Converts a domain DistinguishedName to FQDN
Function ConvertDNtoFQDN
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$True,Position=0)] 
        [String] 
        $DN
    )

    # Init of variable is required to prevent use of a session variable.
    $fqdn = ""

    # Convert each commma separated domain into a FQDN
    ForEach ($domain in $($DN  -split $commaSeparator))
    {
        $fqdn += "$($domain.Substring(3))."
    }
    
    # Remove the last dot
    $fqdn = $fqdn.Substring(0,$fqdn.Length -1)
    
    Return $fqdn
}

# Get list of Domains in the Forest
Function GetADDomains
{
    [CmdletBinding()]
    Param(
        [String] $TargetForest,

        [System.Management.Automation.PSCredential] $TargetForestCredential
    )

    # Function init
    [string] $functionMsg = "Get AD Domains:"
    
    Try
    {
        If ($TargetForestCredential)
        {
            Write-Verbose "$functionMsg Retrieving list of Domains in Forest '$TargetForest'..."
            $forest = Get-ADForest -Identity $TargetForest -Credential $TargetForestCredential -ErrorAction Stop
        }
        Else
        {
            Write-Verbose "$functionMsg Retrieving list of Domains in the Forest..."
            $forest = Get-ADForest -ErrorAction Stop
        }
    }
    Catch
    {
        Throw "$functionMsg Unable to get list of Domains in the Forest. Exception Details: $($_.Exception.Message)"
    }

    Return $($forest.Domains)
}


Function ResolveADobject
{
    [CmdletBinding()]
    Param
    (
        [string] $IdentityName,

        [string] $IdentityDomain,

        [string] $IdentityDN,

        [string] $IdentityParameterSet,

        [switch] $ReturnADobject,

        [string] $TargetForest,

        [System.Management.Automation.PSCredential] $TargetForestCredential
    )
    
    # Check if AD PowerShell Module is installed
    ImportADmodule

    # Init
    [string] $functionMsg = "Resolve AD object:"
    Write-Verbose "ParameterSetName: $IdentityParameterSet"

    switch ($IdentityParameterSet)
    {
        {($_ -eq 'UserDomain') -or ($_ -eq 'UserDomainWithCredential')}
        {
            # Search for AD object using object name and target domain
            Write-Verbose "$functionMsg Resolving AD object '$IdentityName' in Domain '$IdentityDomain'..."
            Try
            {   
                If ($TargetForestCredential)
                {
                    $targetDomain = Get-ADDomain -Identity $IdentityDomain -Credential $TargetForestCredential -ErrorAction Stop
                }
                Else
                {
                    $targetDomain = Get-ADDomain -Identity $IdentityDomain -ErrorAction Stop
                }
            }
            Catch
            {
                Throw "$functionMsg Unable to find Domain '$IdentityDomain' in AD Forest. Exception Details: $($_.Exception.Message)"
            }

            $ldapFilter = "(|(Name=$IdentityName)(sAMAccountName=$IdentityName))"
            $targetDomainDNSname = $targetDomain.DNSRoot
            Write-Verbose "$functionMsg LDAP Filter to search object: $ldapFilter"
            Write-Verbose "$functionMsg Target Domain to search object: $targetDomainDNSname"

            Try
            {
                If ($TargetForestCredential)
                {
                    $adObject = Get-ADObject -LDAPFilter $ldapFilter -Server $targetDomainDNSname -Properties $defaultADobjProperties -Credential $TargetForestCredential -ErrorAction Stop
                }
                Else
                {
                    $adObject = Get-ADObject -LDAPFilter $ldapFilter -Server $targetDomainDNSname -Properties $defaultADobjProperties -ErrorAction Stop
                }
            }
            Catch
            {
                Throw "$functionMsg Unable to get object '$IdentityName' in AD Forest. Exception Details: $($_.Exception.Message)"
            }
        }
        {($_ -eq 'DistinguishedName') -or ($_ -eq 'DistinguishedNameWithCredential')}
        {
            # Search for AD object using DistinguishedName against an AD Global Catalog (AD Forest wide search)
            Write-Verbose "$functionMsg Resolving AD object DN $IdentityDN..."
            # Encode reserved characters to Hex values
            $IdentityDN = Convert-DNtoHex $IdentityDN
            If ($IdentityDN -match $distinguishedNameRegex)
            {
                Write-Verbose "$functionMsg Matches in DistinguishedName input: $($Matches.Values | %{"$_;"})"
                $IdentityDomainDN = $Matches.domain
                $IdentityName = $Matches.name

                Try
                {
                    # Get an array of Domain Controllers running Global Catalog service 
                    $globalCatalogSrv = @(Get-ADDomainController -Discover -DomainName $TargetForest -Service GlobalCatalog -ErrorAction Stop)
                }
                Catch
                {
                    Throw "$functionMsg Unable to find a Global Catalog DC in AD. Exception Details: $($_.Exception.Message)"
                }
    
                If (($globalCatalogSrv | Measure-Object).Count -gt 0)
                {
                    # Pick the first DC in the array and add the GC port
                    $globalCatalogHost = [string] $globalCatalogSrv[0].HostName[0].ToString() + ":3268"
                    Write-Verbose "$functionMsg Target Global Catalog Server to search object: $globalCatalogHost"
                }
                Else
                {
                    Throw "$functionMsg Could not find any available Global Catalog DC in AD."
                }

                Try
                {
                    # Get the AD object based on the DistinguishedName from a GC server in AD
                    If ($TargetForestCredential)
                    {
                        $adObject = Get-ADObject -Identity $IdentityDN -Server $globalCatalogHost -Properties $defaultADobjProperties -Credential $TargetForestCredential -ErrorAction Stop
                    }
                    Else
                    {
                        $adObject = Get-ADObject -Identity $IdentityDN -Server $globalCatalogHost -Properties $defaultADobjProperties -ErrorAction Stop
                    }
                }
                Catch
                {
                    Throw "$functionMsg Unable to get object '$IdentityDN' in AD Forest. Exception Details: $($_.Exception.Message)"
                }

                # If going to return Domain\Username, need to get the AD Domain object
                If (-not $ReturnADobject)
                {
                    $IdentityDomain = ConvertDNtoFQDN $IdentityDomainDN

                    Try
                    {
                        Write-Verbose "$functionMsg Resolving AD Domain '$IdentityDomain'..."

                        If ($TargetForestCredential)
                        {
                            $targetDomain = Get-ADDomain -Identity $IdentityDomain -Credential $TargetForestCredential -ErrorAction Stop
                        }
                        Else
                        {
                            $targetDomain = Get-ADDomain -Identity $IdentityDomain -ErrorAction Stop
                        }
                    }
                    Catch
                    {
                        Throw "$functionMsg Unable to find Domain '$IdentityDomain' in AD Forest. Exception Details: $($_.Exception.Message)"
                    }
                }
            }
            Else
            {
                Throw "$functionMsg Cannot validate argument on parameter 'ADConnectorAccountDN'. The argument '$IdentityDN' does not match a DistinguishedName format."
            }
        }
    }

    # If found, return the identity
    If ($adObject -ne $null)
    {
        If ($ReturnADobject) 
        {
            # Return AD object
            Write-Verbose "$functionMsg Returning AD object: $($adObject.Name)"
            Return $adObject
        }
        Else
        {
            # Get the domain NetBIOS name and return Domain\Username
            $targetDomainNetBIOS = $targetDomain.NetBIOSName
            $targetUsername = $adObject.sAMAccountName
            Write-Verbose "$functionMsg Returning NetBIOS Domain name: $targetDomainNetBIOS"
            Write-Verbose "$functionMsg Returning Username: $targetUsername"
            $identity = [String] $targetDomainNetBIOS + "\" + $targetUsername
            Return $identity
        }
    }
    Else
    {
        Throw "$functionMsg Unable to find '$IdentityName' in AD Forest."
    }
}

# Sets permissions on a target AD object
Function GrantADPermissionsOnADobject
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="high")]
    Param
    (
        # AD permission ACEs to set
        [Parameter(Mandatory=$True)] 
        [ValidateNotNullOrEmpty()] 
        [String] $ACL,

        # DistinguishedName of the target AD object to set permissions
        [Parameter(Mandatory=$True)]
        [ValidateNotNullOrEmpty()] 
        [String] $ADobjectDN,

        # Permissions description message for console output
        [String] $Message = "Grant Active Directory Permissions",

        # Set permission Inheritance for AD objects - Defaults to 'This object and subobjects'
        [String] $InheritanceType = $inheritanceThisAndSubObjects,

        [String] $TargetForest,

        [System.Management.Automation.PSCredential] $TargetForestCredential
    )

    # Function init
    ImportADmodule
    [string] $functionMsg = "Grant permissions on AD object:"
    Write-Verbose "$functionMsg AD permissions ACEs to add: $ACL"

    # Search for AD object using DistinguishedName
    $targetADObj = ResolveADobject -IdentityDN $ADobjectDN -IdentityParameterSet 'DistinguishedName' -ReturnADobject -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential
    $targetADObjClass = $targetADObj.ObjectClass
    Write-Verbose "$functionMsg Target AD Object Class: $targetADObjClass"

    # Set inheritance type
    $Inheritance = $inheritanceType

    If ($targetADObjClass -eq 'organizationalUnit' -or $targetADObjClass -eq 'container' -or $targetADObjClass -eq 'domainDNS')
    {
        # Set permissions for standard object types
        $finalACL = $ACL
    }
    Else
    {
        # Adapt ACL to target the specific AD object
        $ACEarray = $ACL -split $aclSeparator
        $targetADObjACL = @()

        # For each ACE, check if applies to an ObjectClass and if the ObjectClass matches the target AD object
        ForEach ($ace in $ACEarray)
        {
            $indexOfObjClass = $ace.LastIndexOf(";")
            If ($indexOfObjClass -lt 0)
            {
                # No ObjectClass defined in ACE - applies to all objects
                $targetADObjACL += $ace
            }
            Else
            {
                # Specific ObjectClass defined in ACE - applies only if the same as the target object
                $aceTargetClass = $ace.Substring($indexOfObjClass)
                If ($aceTargetClass.Contains($targetADObjClass))
                {
                    # Take this ACE but remove the InheritedObjectType since we will apply ACL to a non-container object
                    $targetADObjACL += $ace -replace ";$targetADObjClass", ""
                }
            }
        }

        # Finalize the filtered ACEs for the target AD object
        If (($targetADObjACL | Measure-Object).Count -eq 0)
        {
             Throw "$functionMsg Permissions are not applicable to AD ObjectClass '$targetADObjClass': $ACL"
        }
        Else
        {
            # Glue all the ACEs in a string back again separated by $aclSeparator
            $finalACL = $null
            for ($i = 0; $i -lt $targetADObjACL.Count-1; $i++)
            { 
                $finalACL += [String] $targetADObjACL[$i]+ $aclSeparator
            }
            $finalACL += [String] $targetADObjACL[$targetADObjACL.Count-1]
        }
        
        # Enclose all the ACEs in double quotes
        If ($finalACL[0] -ne '"') 
        {
            $finalACL =  '"' + $finalACL
        }
        If ($finalACL[$finalACL.Length-1] -ne '"') 
        {
            $finalACL =  $finalACL + '"'
        }
        Write-Verbose  "$functionMsg AD permissions ACEs for target AD object: $finalACL"
    }

    # Set AD Permissions on a target AD object
    If ($PSCmdlet.ShouldProcess($targetADObj.Name, $Message)) 
    {
        Write-Output "$functionMsg Setting permissions on AD object '$($targetADObj.DistinguishedName)'..."
        GrantAcls $targetADObj.DistinguishedName $finalACL $Inheritance -TargetForestCredential $TargetForestCredential
    }
    Else
    {
        Write-Verbose "$functionMsg Operation canceled."
    }
}

# Sets permissions on all Domains in the Forest
Function GrantADPermissionsOnAllDomains
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="high")]
    Param
    (
        # AD permission ACEs to set
        [Parameter(Mandatory=$True)] 
        [ValidateNotNullOrEmpty()] 
        [String] $ACL,

        # Update permissions on the AdminSdHolders container
        [Switch] $IncludeAdminSDHolders,

        # Permission Inheritance
        [String] $Inheritance = $inheritanceSubObjectsOnly,

        # Permissions description message for console output
        [String] $Message = "Grant Active Directory Permissions",

        [String] $TargetForest,

        [System.Management.Automation.PSCredential] $TargetForestCredential
    )

    # Function init
    ImportADmodule
    [string] $functionMsg = "Grant permissions on all Domains:"
    Write-Verbose "$functionMsg AD permissions ACEs to add: $ACL"

    # Get list of all Domains in the Forest
    $domains = GetADDomains -TargetForest $TargetForest -TargetForestCredential $TargetForestCredential

    # Set root permissions for all Domains in the Forest
    ForEach($domain in $domains) 
    {
        If ($PSCmdlet.ShouldProcess($domain, $Message)) 
        {
            $domainDN = ConvertFQDNtoDN -FQDN $domain
            Write-Output "$functionMsg AD Domain '$domainDN'..."
            If ($Inheritance -eq $inheritanceNone)
            {
                GrantAclsNoInheritance $domainDN $ACL -TargetForestCredential $TargetForestCredential
            }
            Else
            {
                GrantAcls $domainDN $ACL $Inheritance -TargetForestCredential $TargetForestCredential
            }

            # Check if setting permissions on AdminSdHolder container
            If ($IncludeAdminSDHolders) 
            {
                Try 
                {
                    Write-Output "$functionMsg Setting permissions on AdminSDHolder container of '$domainDN'"

                    If ($TargetForestCredential)
                    {
                        $adminSDHolderDN = (Get-ADObject -Server $domain -Filter "Name -like 'adminsdholder'" -Credential $TargetForestCredential).DistinguishedName
                    }
                    Else
                    {
                        $adminSDHolderDN = (Get-ADObject -Server $domain -Filter "Name -like 'adminsdholder'").DistinguishedName
                    }
                }
                Catch 
                {
                    Throw "$functionMsg Unable to get AdminSDHolder container of '$domainDN'. Exception details: $($_.Exception)"
                }
                # Setting permissions on AdminSdHolder container
                GrantAcls $adminSDHolderDN $ACL $Inheritance -TargetForestCredential $TargetForestCredential
            }
        }
        Else
        {
            Write-Verbose "$functionMsg Operation canceled."
        }
    }
}

Function TestCredential
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)] 
        [System.Management.Automation.PSCredential] $Credential
    )

    # Function init
    [string] $functionMsg = "Test Credential:"
    $networkCredential = $Credential.GetNetworkCredential()

    If ($networkCredential.UserName.Contains("@") -or $networkCredential.Domain.ToString() -eq "")
    {
        Throw [System.ArgumentException] "$functionMsg Validating credential parameter failed. Credential should use the fully qualified domain name of the administrator account. Example: CONTOSO\admin"
    }
    
    Try
    {
        # $Credential.UserName == FQDN\Username, $networkCredential.UserName == just the Username portion.  We need to use the FQDN from here
        $dc = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext([System.DirectoryServices.ActiveDirectory.DirectoryContextType]::Domain, $networkCredential.Domain, $Credential.UserName, $networkCredential.Password) -ErrorAction Stop
    }
    Catch
    {
        Throw [System.ArgumentException] "$functionMsg Validating credential parameter failed. Unable to use credentials to access AD. Error Details: $($_.Exception.Message)"
    }

    Try
    {
        # Validating credential
        $credentialValid = $false
        $domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetDomain($dc)
        $enterpriseAdminsSid = GetEnterpriseAdminsSid $Credential
        $domainAdminsSid = GetDomainAdminsSid $Credential

        $domainDE = $domain.GetDirectoryEntry()
        $searchFilter = "(samAccountName=$($networkCredential.UserName))"
        $directorySearcher = New-Object System.DirectoryServices.DirectorySearcher($domainDE, $searchFilter)

        $searchResult = $directorySearcher.FindOne()
        If ($searchResult -eq $null)
        {
            Throw [System.ArgumentException] "$functionMsg Validating credential parameter failed. Admin account '$($Credential.UserName)' could not be found."
        }

        $adminDE = $searchResult.GetDirectoryEntry()

        [string[]] $propertyName = @("tokenGroups")
        $adminDE.RefreshCache($propertyName)
        ForEach ($resultBytes in $adminDE.Properties["tokenGroups"])
        {
            $sid = New-Object System.Security.Principal.SecurityIdentifier($resultBytes, 0)
            If ($sid.Equals($enterpriseAdminsSid) -or $sid.Equals($domainAdminsSid))
            {
                $credentialValid = $true
                Break
            }
        }

        If (!$credentialValid)
        {
            Throw [System.ArgumentException] "$functionMsg Validating credential parameter failed. Enterprise Admin or Domain Admin credential is required to restrict permissions on the account."
        }
    }
    Catch [Exception]
    {
        Throw "$functionMsg Validating credential parameter failed. Error Details: $($_.Exception.Message)"
    }
    Finally
    {
        # Clean up memory
        If ($domain -ne $null)
        {
            $domain.Dispose()
        }

        If ($domainDE -ne $null)
        {
            $domainDE.Dispose()
        }

        If ($directorySearcher -ne $null)
        {
            $directorySearcher.Dispose()
        }

        If ($adminDE -ne $null)
        {
            $adminDE.Dispose()
        }
    }
}

Function GetEnterpriseAdminsSid
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$True)] 
        [System.Management.Automation.PSCredential] $Credential
    )

    $networkCredential = $Credential.GetNetworkCredential()
    $dc = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext([System.DirectoryServices.ActiveDirectory.DirectoryContextType]::Domain, $networkCredential.Domain, $Credential.UserName, $networkCredential.Password)			

    try
    {
        $domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetDomain($dc)		
        try
        {
            $de = $domain.Forest.RootDomain.GetDirectoryEntry()
            $rootDomainSidInBytes = $de.Properties["ObjectSID"].Value
            $domainSid = New-Object System.Security.Principal.SecurityIdentifier($rootDomainSidInBytes, 0)
            $eaSid = New-Object System.Security.Principal.SecurityIdentifier([System.Security.Principal.WellKnownSidType]::AccountEnterpriseAdminsSid, $domainSid)
            return $eaSid
        }
        finally
        {
            if ($de -ne $null)
            {
                $de.Dispose()
            }
        }
    }
    finally
    {
        if ($domain -ne $null)
        {
            $domain.Dispose()
        }
    }
}

Function GetDomainAdminsSid
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$True)] 
        [System.Management.Automation.PSCredential] $Credential
    )

    $networkCredential = $Credential.GetNetworkCredential()
    $dc = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext([System.DirectoryServices.ActiveDirectory.DirectoryContextType]::Domain, $networkCredential.Domain, $Credential.UserName, $networkCredential.Password)

    try
    {
        $domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetDomain($dc)		
        try
        {
            $de = $domain.GetDirectoryEntry()
            $domainSidInBytes = $de.Properties["ObjectSID"].Value
            $domainSid = New-Object System.Security.Principal.SecurityIdentifier($domainSidInBytes, 0)
            $domainAdminsSid = New-Object System.Security.Principal.SecurityIdentifier([System.Security.Principal.WellKnownSidType]::AccountDomainAdminsSid, $domainSid)
            return $domainAdminsSid
        }
        finally
        {
            if ($de -ne $null)
            {
                $de.Dispose()
            }
        }
    }
    finally
    {
        if ($domain -ne $null)
        {
            $domain.Dispose()
        }
    }
}

# Convert SIDs to readable names
Function ConvertSIDtoName
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$True,Position=0)] 
        [string] $SID
    )

    $ID = New-Object -TypeName System.Security.Principal.SecurityIdentifier -ArgumentList $sid
    $User = $ID.Translate([System.Security.Principal.NTAccount])
    $User.Value
}

# Confirm if ActiveDirectory PowerShell Module is present and load it
Function ImportADmodule
{
    [CmdletBinding()]
    Param()

    If (-not (Get-Module ActiveDirectory))
    {
        Try
        {
            # Load ActiveDirectory module
            Import-Module ActiveDirectory -ErrorAction Stop
        }
        Catch
        {

            Throw "Import-Module : Unable to import ActiveDirectory PowerShell Module. Run 'Install-WindowsFeature RSAT-AD-Tools' to install Active Directory RSAT."
        }
    }
}

# Encode reserved characters in DistinguishedName to Hexadecimal values based on MSDN documentation:
# The following table lists reserved characters that cannot be used in an attribute value without being escaped.
# From: https://msdn.microsoft.com/en-us/windows/desktop/aa366101
Function Convert-DNtoHex
{
    [CmdletBinding()]
    Param 
    (
        [Parameter(Mandatory=$True,Position=0)] [String] $DN
    )

    $encodedDN = $DN -replace '\\#','\23' `
                    -replace '\\,','\2C' `
                    -replace '\\"','\22' `
                    -replace '\\<','\3C' `
                    -replace '\\>','\3E' `
                    -replace '\\;','\3B' `
                    -replace '\\=','\3D' `
                    -replace '\\/','\2F'
    return $encodedDN
}

# Replace reserved characters for command line arguments
Function ReplaceReservedCharcters
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$True,Position=0)] [String] $PreReplace
    )	

    $postReplace = $PreReplace -replace '\"','\"'

    return $postReplace
}


# Export ADSyncConfig Module Functions
Export-ModuleMember -Function Set-ADSyncRestrictedPermissions
Export-ModuleMember -Function Set-ADSyncPasswordHashSyncPermissions
Export-ModuleMember -Function Set-ADSyncExchangeHybridPermissions
Export-ModuleMember -Function Set-ADSyncMsDsConsistencyGuidPermissions
Export-ModuleMember -Function Set-ADSyncPasswordWritebackPermissions
Export-ModuleMember -Function Set-ADSyncUnifiedGroupWritebackPermissions
Export-ModuleMember -Function Set-ADSyncExchangeMailPublicFolderPermissions
Export-ModuleMember -Function Set-ADSyncBasicReadPermissions
Export-ModuleMember -Function Get-ADSyncObjectsWithInheritanceDisabled
Export-ModuleMember -Function Get-ADSyncADConnectorAccount
Export-ModuleMember -Function Show-ADSyncADObjectPermissions

# SIG # Begin signature block
# MIInnwYJKoZIhvcNAQcCoIInkDCCJ4wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC044O1QrO/mXzo
# vfAGyyj0C1vNPHfykaZ23vytrGQ046CCDYIwggYAMIID6KADAgECAhMzAAADXJXz
# SFtKBGrPAAAAAANcMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwNDA2MTgyOTIyWhcNMjQwNDAyMTgyOTIyWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDijA1UCC84R0x+9Vr/vQhPNbfvIOBFfymE+kuP+nho3ixnjyv6vdnUpgmm6RT/
# pL9cXL27zmgVMw7ivmLjR5dIm6qlovdrc5QRrkewnuQHnvhVnLm+pLyIiWp6Tow3
# ZrkoiVdip47m+pOBYlw/vrkb8Pju4XdA48U8okWmqTId2CbZTd8yZbwdHb8lPviE
# NMKzQ2bAjytWVEp3y74xc8E4P6hdBRynKGF6vvS6sGB9tBrvu4n9mn7M99rp//7k
# ku5t/q3bbMjg/6L6mDePok6Ipb22+9Fzpq5sy+CkJmvCNGPo9U8fA152JPrt14uJ
# ffVvbY5i9jrGQTfV+UAQ8ncPAgMBAAGjggF/MIIBezArBgNVHSUEJDAiBgorBgEE
# AYI3TBMBBgorBgEEAYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUXgIsrR+tkOQ8
# 10ekOnvvfQDgTHAwRQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEWMBQGA1UEBRMNMjMzMTEwKzUwMDg2ODAfBgNVHSMEGDAWgBRI
# bmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEt
# MDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBABIm
# T2UTYlls5t6i5kWaqI7sEfIKgNquF8Ex9yMEz+QMmc2FjaIF/HQQdpJZaEtDM1Xm
# 07VD4JvNJEplZ91A4SIxjHzqgLegfkyc384P7Nn+SJL3XK2FK+VAFxdvZNXcrkt2
# WoAtKo0PclJOmHheHImWSqfCxRispYkKT9w7J/84fidQxSj83NPqoCfUmcy3bWKY
# jRZ6PPDXlXERRvl825dXOfmCKGYJXHKyOEcU8/6djs7TDyK0eH9ss4G9mjPnVZzq
# Gi/qxxtbddZtkREDd0Acdj947/BTwsYLuQPz7SNNUAmlZOvWALPU7OOVQlEZzO8u
# Ec+QH24nep/yhKvFYp4sHtxUKm1ZPV4xdArhzxJGo48Be74kxL7q2AlTyValLV98
# u3FY07rNo4Xg9PMHC6sEAb0tSplojOHFtGtNb0r+sioSttvd8IyaMSfCPwhUxp+B
# Td0exzQ1KnRSBOZpxZ8h0HmOlMJOInwFqrCvn5IjrSdjxKa/PzOTFPIYAfMZ4hJn
# uKu15EUuv/f0Tmgrlfw+cC0HCz/5WnpWiFso2IPHZyfdbbOXO2EZ9gzB1wmNkbBz
# hj8hFyImnycY+94Eo2GLavVTtgBiCcG1ILyQabKDbL7Vh/OearAxcRAmcuVAha07
# WiQx2aLghOSaZzKFOx44LmwUxRuaJ4vO/PRZ7EzAMIIHejCCBWKgAwIBAgIKYQ6Q
# 0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5
# WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQD
# Ex9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4
# BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe
# 0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato
# 88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v
# ++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDst
# rjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN
# 91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4ji
# JV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmh
# D+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbi
# wZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8Hh
# hUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaI
# jAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTl
# UAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNV
# HQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQF
# TuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29m
# dC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNf
# MjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNf
# MjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnlj
# cHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5
# AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oal
# mOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0ep
# o/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1
# HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtY
# SWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInW
# H8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZ
# iWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMd
# YzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7f
# QccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKf
# enoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOpp
# O6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZO
# SEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGXMwghlvAgEBMIGVMH4xCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jv
# c29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAANclfNIW0oEas8AAAAAA1ww
# DQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIAFyjRNa
# Uuer/IdwgUM0E4BPCsbTs1Fj/Q2o3nJ+3CT4MEIGCisGAQQBgjcCAQwxNDAyoBSA
# EgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20w
# DQYJKoZIhvcNAQEBBQAEggEA4ni9wzbV6x8AUh0aK9CgY0WAYyIMwbIIC2JCreG/
# X8EaKeRdWMpVijYeaogiSlAjGTxxKYCk/4VR6UVTac+b4GDwcDBBSHmYkM6l3NQW
# b8N7l693M4tT4Amf6gfAToXsI751/YrgHCCtF119FpRnw+kQ6jRLa55WLuMc7Egp
# Mnx+ET9pXvQ8ojvXTdxF6Red7P99AWKq1xf4KO/VSvd3eVX1nz5igdHyP5iCW+dv
# h31e0cjFoG9gIi70qApF4kk2KdBEcM6XK0S7qiHsYa89e2jFZtIZhrOJZVm/C+Kk
# RkvkJNbjAafYdr84I6IWydJVxly3xBPkQ8QoM7RSSWLcsqGCFv0wghb5BgorBgEE
# AYI3AwMBMYIW6TCCFuUGCSqGSIb3DQEHAqCCFtYwghbSAgEDMQ8wDQYJYIZIAWUD
# BAIBBQAwggFRBgsqhkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoD
# ATAxMA0GCWCGSAFlAwQCAQUABCAI1KRBgZUxufVn6MOORJO5evQNpYgebuRyT22x
# I7XLyAIGZF0DIUktGBMyMDIzMDUxNzIyNTUzMS44MDZaMASAAgH0oIHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjoxMkJDLUUzQUUtNzRFQjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaCCEVQwggcMMIIE9KADAgECAhMzAAAByk/Cs+0DDRhsAAEAAAHK
# MA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4X
# DTIyMTEwNDE5MDE0MFoXDTI0MDIwMjE5MDE0MFowgcoxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNh
# IE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjEyQkMtRTNBRS03
# NEVCMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjAN
# BgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAwwGcq9j50rWEkcLSlGZLweUVfxXR
# aUjiPsyaNVxPdMRs3CVe58siu/EkaVt7t7PNTPko/s8lNtusAeLEnzki44yxk2c9
# ekm8E1SQ2YV9b8/LOxfKapZ8tVlPyxw6DmFzNFQjifVm8EiZ7lFRoY448vpcbBD1
# 8qjYNF/2Z3SQchcsdV1N9Y6V2WGl55VmLqFRX5+dptdjreBXzi3WW9TsoCEWcYCB
# K5wYgS9tT2SSSTzae3jmdw40g+LOIyrVPF2DozkStv6JBDPvwahXWpKGpO7rHrKF
# +o7ECN/ViQFMZyp/vxePiUABDNqzEUI8s7klYmeHXvjeQOq/CM3C/Y8bj3fJObnZ
# H7eAXvRDnxT8R6W/uD1mGUJvv9M9BMu3nhKpKmSxzzO5LtcMEh2tMXxhMGGNMUP3
# DOEK3X+2/LD1Z03usJTk5pHNoH/gDIvbp787Cw40tsApiAvtrHYwub0TqIv8Zy62
# l8n8s/Mv/P764CTqrxcXzalBHh+Xy4XPjmadnPkZJycp3Kczbkg9QbvJp0H/0Fsw
# HS+efFofpDNJwLh1hs/aMi1K/ozEv7/WLIPsDgK16fU/axybqMKk0NOxgelUjAYK
# l4wU0Y6Q4q9N/9PwAS0csifQhY1ooQfAI0iDCCSEATslD8bTO0tRtqdcIdavOReq
# zoPdvAv3Dr1XXQ8CAwEAAaOCATYwggEyMB0GA1UdDgQWBBT6x/6lS4ESQ8KZhd0R
# gU7RYXM8fzAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8E
# WDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9N
# aWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYB
# BQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEw
# KDEpLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqG
# SIb3DQEBCwUAA4ICAQDY0HkqCS3KuKefFX8/rm/dtD9066dKEleNqriwZqsM4Ym8
# Ew4QiqOqO7mWoYYY4K5y8eXSOHKNXOfpO6RbaYj8jCOcJAB5tqLl5hiMgaMbAVLr
# l1hlix9sloO45LON0JphKva3D6AVKA7P78mA9iRHZYUVrRiyfvQjWxmUnxhis8fo
# m92+/RHcEZ1Dh5+p4gzeeL84Yl00Wyq9EcgBKKfgq0lCjWNSq1AUG1sELlgXOSvK
# Z4/lXXH+MfhcHe91WLIaZkS/Hu9wdTT6I14BC97yhDsZWXAl0IJ801I6UtEFpCsT
# eOyZBJ7CF0rf5lxJ8tE9ojNsyqXJKuwVn0ewCMkZqz/cEwv9FEx8QmsZ0ZNodTts
# l+V9dZm+eUrMKZk6PKsKArtQ+jHkfVsHgKODloelpOmHqgX7UbO0NVnIlpP55gQT
# qV76vU7wRXpUfz7KhE3BZXNgwG05dRnCXDwrhhYz+Itbzs1K1R8I4YMDJjW90ASC
# g9Jf+xygRKZGKHjo2Bs2XyaKuN1P6FFCIVXN7KgHl/bZiakGq7k5TQ4OXK5xkhCH
# hjdgHuxj3hK5AaOy+GXxO/jbyqGRqeSxf+TTPuWhDWurIo33RMDGe5DbImjcbcj6
# dVhQevqHClR1OHSfr+8m1hWRJGlC1atcOWKajArwOURqJSVlThwVgIyzGNmjzjCC
# B3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAw
# gYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMT
# KU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIx
# MDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57Ry
# IQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VT
# cVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhx
# XFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQ
# HJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1
# KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s
# 4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUg
# fX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3
# Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je
# 1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUY
# hEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUY
# P3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGC
# NxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4w
# HQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYB
# BAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcD
# CDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0T
# AQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNV
# HR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9w
# cm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEE
# TjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOC
# AgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/a
# ZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp
# 4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq
# 95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qB
# woEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG
# +jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3B
# FARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77
# IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJ
# fn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K
# 6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDx
# yKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLLMIICNAIBATCB
# +KGB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEl
# MCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMd
# VGhhbGVzIFRTUyBFU046MTJCQy1FM0FFLTc0RUIxJTAjBgNVBAMTHE1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAKOO55cMT4syPP6n
# Clg2IWfajMqkoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAw
# DQYJKoZIhvcNAQEFBQACBQDoD2ncMCIYDzIwMjMwNTE3MjI1NzMyWhgPMjAyMzA1
# MTgyMjU3MzJaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIFAOgPadwCAQAwBwIBAAIC
# GN4wBwIBAAICEcYwCgIFAOgQu1wCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYB
# BAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOB
# gQAqT3CR3fIyNjapo1/yvoJR+OxeQImhFqisKmwnmK++t/DrXx/4AQ7di+fWwiwc
# Pc0jDeAH4MQGvbSETZ0TqzwBzrbvuwGd8mTzW+d2e84lwWX8IDoZEKf/M5Y6oWOW
# 9DtZ4RbVBPkm9qFhI7LkUJN/pC5IdIdY2dQcsqDIMm0XlzGCBA0wggQJAgEBMIGT
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAByk/Cs+0DDRhsAAEA
# AAHKMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQ
# AQQwLwYJKoZIhvcNAQkEMSIEICyXlG/Ag5PwGWdeyL4Q/s33Yk+WoUoEsYtqBibo
# f+5iMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgEz0b85vrVU2slZAk4jt1
# SDEk6IzZAwVCoWwF3KzcGuAwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAcpPwrPtAw0YbAABAAAByjAiBCCKjJw5tG2StmWHZLxZbBpG
# c9pnljPVNsmyUK5eqygI4zANBgkqhkiG9w0BAQsFAASCAgBa0uLpA4Bf+I2NyY5R
# RCOMPlLC9fTGwhmPxngfytXZb7fMbQR3Wq6rl94zWM70gNUtFJK8ThDAqhPUKGSG
# xka6TWiVG9jNGX6TZdmn7UyCovgSfUxR1Q02JvdnJWQA++Wmr5M2nYoT5MYBeSRD
# mlLBHiixEPOmk4lECOq/qgtBy4q19NkbjCb/aqzpdZnt5yN1H35V4OXIX2c6MEVo
# PTYW5b99gqGh4xIqIphCtPobtE6v/ehRFTk0h6fRKCKDbDoO2ff+k62fhgjCGm6z
# ykmn4BPTL0hx+YVuhpkTEl4MhFWGPhjcDFLDL6ztUsq4hLdQHnz4DEJFKwnPIfvz
# DSoMQOdX3baXdsVhkPPxuuXJFJPpOjULIFTjFqq7HzWEMK46kfWbJgCU7xMPdZi6
# qYm5Od+LyZXq+26oAkan6QDAcuFiyJf9VMqSd791pG2KLL5rqxnteMy2QV0mGGl4
# edJh7dsJiZSiCHiuv6LP7z4QTBLMiWE4LCHnsAvLFXWq0ZZfB9H6GiItDWJnbqzX
# 8TyAy1r8l6pwK3neuHx+TivV3bpPEmzYrdnYgPHbuNQ6eg6HfsXwWn0qt5ZArgcT
# V3g1lZu605AYNg/IfLCZs9bVNVbw3jddiDiNFjznl17FevXfL004yiHdpckZJZAu
# tCOyBWt+ddAX8V2Dj62A8CW3+Q==
# SIG # End signature block
