<#
Disclaimer: The scripts are not supported under any Microsoft standard support program or service. 
The scripts are provided AS IS without warranty of any kind. Microsoft further disclaims all implied 
warranties including, without limitation, any implied warranties of merchantability or of fitness for a 
particular purpose. The entire risk arising out of the use or performance of the scripts and 
documentation remains with you. In no event shall Microsoft, its authors, or anyone else involved in the 
creation, production, or delivery of the scripts be liable for any damages whatsoever (including, without 
limitation, damages for loss of business profits, business interruption, loss of business information, or 
other pecuniary loss) arising out of the use of or inability to use the scripts or documentation, 
even if Microsoft has been advised of the possibility of such damages. 
#>

#-------------------------------------------------------------------------------------------------------------------------------------
#  
# Copyright � 2021 Microsoft Corporation.  All rights reserved.
#  
#-------------------------------------------------------------------------------------------------------------------------------------
# 
# NAME:     Azure AD Connect ADSyncTools PowerShell Module
# 
# 
# VERSION:  1.7.1
#
#-------------------------------------------------------------------------------------------------------------------------------------


#=======================================================================================
#region Internal Variables
#=======================================================================================

$defaultADobjProperties = @('UserPrincipalName','ObjectGUID','ObjectSID','mS-DS-ConsistencyGuid','sAMAccountName')
$upnRegex = [Regex] "^[a-zA-Z0-9.!�#$%&'^_`{}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$"
$distinguishedNameRegex = [Regex] '^(?:(?<cn>CN=(?<name>[^,]*)),)?(?:(?<path>(?:(?:CN|OU)=[^,]+,?)+),)?(?<domain>(?:DC=[^,]+,?)+)$'

#endregion
#=======================================================================================

#=======================================================================================
#region class definitions
#=======================================================================================

class DuplicateUserSourceAnchorInfo
{
    [string] $UserName

    [string] $DistinguishedName

	[string] $ADDomainName

    [Byte[]] $CurrentMsDsConsistencyGuid

    [Byte[]] $ExpectedMsDsConsistencyGuid
}

#=======================================================================================
#endregion class definitions
#=======================================================================================

#=======================================================================================
#region Internal Functions
#=======================================================================================

<#
.SYNOPSIS
    Checks if ActiveDirectory PowerShell Module is present and imports it
#>
Function Import-ADSyncToolsActiveDirectoryModule
{
    [CmdletBinding()]
    Param ()
    
    If (-not (Get-Module ActiveDirectory))
    {
        Try
        {
            # Load ActiveDirectory module
            Import-Module ActiveDirectory -ErrorAction Stop
        }
        Catch
        {

            Throw "Unable to import ActiveDirectory PowerShell Module. Run 'Install-WindowsFeature RSAT-AD-Tools' to install Active Directory RSAT. Error Details: $($_.Exception.Message)"
        }
    }
}


<#
.SYNOPSIS
    Checks if AADConnector PowerShell Module is present and imports it
#>
Function Import-ADSyncToolsAADConnectorBinaries
{
    [CmdletBinding()]
    Param ()

    $binariesPath = Get-ADSyncToolsADsyncFolder
    
    If ($binariesPath -eq '')
    {
        Write-Warning "Azure AD Connect installation was not found, some functionality may be unavailable. Using current directory '$PSScriptRoot'."
        Try
        {
            Add-Type -Path $(Join-Path -Path $PSScriptRoot -ChildPath "Microsoft.MetadirectoryServicesEx.dll")
            Add-Type -Path $(Join-Path -Path $PSScriptRoot -ChildPath "Microsoft.MetadirectoryServices.PasswordHashSynchronization.Types.dll")
            Add-Type -Path $(Join-Path -Path $PSScriptRoot -ChildPath "Microsoft.Azure.ActiveDirectory.Connector.dll")
        }
        Catch
        {
            Throw  "Unable to import AADConnector binaries. Error Details: $($_.Exception.Message)"
        }
    }
    Else
    {
        Write-Verbose "Importing binaries from '$binariesPath'..."
        Try
        {
            Import-Module  $(Join-Path -Path $binariesPath -ChildPath "Bin\ADSync\ADSync.psd1")
            Add-Type -Path $(Join-Path -Path $binariesPath -ChildPath "Bin\Assemblies\Microsoft.MetadirectoryServicesEx.dll")
            Add-Type -Path $(Join-Path -Path $binariesPath -ChildPath "Bin\Microsoft.MetadirectoryServices.PasswordHashSynchronization.Types.dll")
            Add-Type -Path $(Join-Path -Path $binariesPath -ChildPath "Extensions\Microsoft.Azure.ActiveDirectory.Connector.dll")
        }
        Catch
        {
            Throw  "Unable to import AADConnector binaries. Error Details: $($_.Exception.Message)"
        }
    }
}


<#
.SYNOPSIS
    Gets Azure AD Connect installed folder location from the registry 
#>
Function Get-ADSyncToolsADsyncFolder
{
    [CmdletBinding()]
    Param ()

    $path = ''
    $paramsRegKey = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\ADSync\Parameters\'
    Try
    {
        Write-verbose "Reading AADConnect config from registry..."
        $adSyncReg = Get-ItemProperty -Path Registry::$paramsRegKey -ErrorAction Stop
    }
    Catch
    {
        Write-Warning "Azure AD Connect path not found. Error Details: $($_.Exception.Message)"
    }

    If ($adSyncReg -ne $null)
    {
        $path = $adSyncReg.Path
    }

    Return $path
}


<#
.SYNOPSIS
    Helper routine to get which Azure environment the user belongs.

.DESCRIPTION
    The GetTenantAzureEnvironment Function will call Oauth discovery endpoint to get 
    CloudInstance and tenant_region_scope to determine the Azure environment.
    https://login.microsoftonline.com/{tenant}/.well-known/openid-configuration

    cloud_instance_name    azure_environment
    ===================    =================
    microsoftonline.de     AzureGermanyCloud
    chinacloudapi.cn       AzureChinaCloud
    microsoftonline.com    AzureCloud/USGovernment

    tenant_region_scope    azure_environment
    ===================    =================
    USG                    USGovernment

    TODO: We are only using tenant_region_scope for Fairfax because ESTS public instance 
    covers both Public and Fairfax clouds. Once ESTS stands up a Fairfax instance, then 
    we should switch to use cloud_instance_name == microsoftonline.us for Fairfax.

.PARAMETER credential
    The user's credential object.

.RETURN the Azure environment (string)
#>
Function Get-ADSyncToolsTenantAzureEnvironment
{
    [CmdletBinding()]
	Param(
		[Parameter(Mandatory=$True, Position=0)] 
		[System.Management.Automation.PSCredential] $credential
	)

    # Set default Azure environment to public
    $environment = "AzureCloud"

    # Get tenant name from user's upn suffix
    $upn = $credential.UserName
    $tenant = $upn.Split('@')[1]
    if ([string]::IsNullOrEmpty($tenant))
    {
        Write-Output "[ERROR]`t AzureADCredentials doesn't contain a valid user name. You need to provide the user name in the user principal name (UPN) format (user@example.com)."
        # Break will stop all script execution if not used in a loop or switch statement
        break
    }

    # Oauth discovery endpoint
    $url = "https://login.microsoftonline.com/$tenant/.well-known/openid-configuration"

    # Get CloudInstance from Oauth discovery endpoint
    try
    {
        $response = Invoke-RestMethod -Uri $url -Method Get
    }
    catch [Exception]
    {
        # We failed, but that is possible if the tenant is in PPE.  So check against PPE before failing.
        try
        {
            # Oauth discovery endpoint for PPE
            $url = "https://login.windows-ppe.net/$tenant/.well-known/openid-configuration"

            $response = Invoke-RestMethod -Uri $url -Method Get
        }
        catch [Exception]
        {
            Write-Output "$_.Exception.Message"
            Write-Output "[ERROR]`t OAuth2 discovery failed. Please contact system administrator for more information."
            break
        }
    }

    # Determine AzureEnvironment from tenant_region_scope and cloud_instance_name
    if ($response.tenant_region_scope.ToLower().equals("usg"))
    {
        $environment = "USGovernment"
    }
    elseif ($response.cloud_instance_name.ToLower().equals("chinacloudapi.cn"))
    {
        $environment = "AzureChinaCloud"
    }
    elseif ($response.cloud_instance_name.ToLower().equals("microsoftonline.de"))
    {
        $environment = "AzureGermanyCloud"
    }
    elseif ($response.cloud_instance_name.ToLower().equals("windows-ppe.net"))
    {
        $environment = "AzurePPE"
    }

    return $environment
}


<#
.SYNOPSIS
    Encodes reserved characters in DistinguishedName to Hexadecimal values based on MSDN documentation:
    The following table lists reserved characters that cannot be used in an attribute value without being escaped.
    From: https://msdn.microsoft.com/en-us/windows/desktop/aa366101
#>
Function Format-ADSyncToolsDistinguishedName
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$True,
                   Position=0)] 
        [String] 
        $DistinguishedName
    )

    $escapedDN = $DistinguishedName -replace '\\#','\23' `
                                    -replace '\\,','\2C' `
                                    -replace '\\"','\22' `
                                    -replace '\\<','\3C' `
                                    -replace '\\>','\3E' `
                                    -replace '\\;','\3B' `
                                    -replace '\\=','\3D' `
                                    -replace '\\/','\2F'
    Return $escapedDN
}


<#
.Synopsis
   Gets a domain controller in the Forest for a given DistinguishedName.
.DESCRIPTION
   Returns one target Domain Controller
#>
Function Get-ADSyncToolsADtargetDC
{
    [CmdletBinding()]
    Param 
    (
        # Domain Controller type
        [Parameter(Mandatory = $true, Position = 0)]
        [ValidateSet('GlobalCatalog', 'Readable', 'Writable')]
        $Service,
                
        # Target AD Domain
        [Parameter(Mandatory=$false, Position=1)]
        [ValidateNotNullOrEmpty()]
        $DomainName
    )
    
    If ($Service -ne 'GlobalCatalog' -and ($DomainName -eq "" -or $DomainName -eq $null))
    {
        Throw "A DomainName in FQDN format must be provided to get a $Service Domain Controller"
    }

    Import-ADSyncToolsActiveDirectoryModule

    switch ($Service)
    {
        'GlobalCatalog' 
        {
            # Find a target Global Catalog Domain Controller
            Try
            {
                [string] $domainCtrlName = (Get-ADDomainController -Discover -Service GlobalCatalog -ErrorAction Stop).HostName | select -First 1
                Write-Verbose "Target DC (Global Catalog): $domainCtrlName"
            }
            Catch
            {
                Throw "Cannot find a $Service Domain Controller: $($_.Exception.Message)"
            }
        }
        'Readable' 
        {
            # Find a target Readable Domain Controller for AD domain
            Try
            {
                [string] $domainCtrlName = (Get-ADDomainController -Discover -DomainName $DomainName -ErrorAction Stop).HostName | select -First 1
                Write-Verbose "Target DC for Domain '$DomainName': $domainCtrlName"
            }
            Catch
            {
                Throw "Cannot find a $Service Domain Controller: $($_.Exception.Message)"
            }            
        }
        'Writable' 
        {
            # Find a target Writable Domain Controller for AD domain
            Try
            {
                [string] $domainCtrlName = (Get-ADDomainController -Discover -DomainName $DomainName -Writable -ErrorAction Stop).HostName | select -First 1
                Write-Verbose "Target DC for Domain '$DomainName': $domainCtrlName"
            }
            Catch
            {
                Throw "Cannot find a $Service Domain Controller: $($_.Exception.Message)"
            }            
        }
    }

    If ($domainCtrlName -eq "" -or $domainCtrlName -eq $null)
    {
        Throw "Unable to find a Domain Controller."
    }

    Return $domainCtrlName
}


<#
.Synopsis
   Get AD Domain DistinguishedName
.DESCRIPTION
   Returns the DistinguishedName of the AD Domain for a given AD object.
#>
Function Get-ADSyncToolsDomainDN
{
    [CmdletBinding()]
    Param 
    (
        # Target User in AD to set ConsistencyGuid
        [Parameter(Mandatory = $true, Position = 0)]
        [ValidateNotNullOrEmpty()]
        $DistinguishedName
    )

    # Get the Domain portion of the object's DN
    Try
    {
        $domainDN =  $DistinguishedName.Substring($DistinguishedName.IndexOf('DC='))
        Write-Verbose "Object's Domain DN: $domainDN"
    }
    Catch
    {
        Throw "DistinguishedName '$DistinguishedName' is invalid."
    }

    Return $domainDN
}


<#
.Synopsis
   Get AD Domain FQDN from DistinguishedName
.DESCRIPTION
   Returns the respective FQDN of the AD Domain for a given AD object.
#>
Function Get-ADSyncToolsDomainDns
{
    [CmdletBinding()]
    Param 
    (
        # Target User in AD to set ConsistencyGuid
        [Parameter(Mandatory = $true, Position = 0)]
        [ValidateNotNullOrEmpty()]
        $DistinguishedName
    )

    Import-ADSyncToolsActiveDirectoryModule
    
    $domainDN = Get-ADSyncToolsDomainDN $DistinguishedName

    # Get the Domains in the Forest
    $domains = @((Get-ADForest).Domains | %{Get-ADDomain -Identity $_})
    Write-Verbose "Domains in AD Forest: $($domains | Select -ExpandProperty DistinguishedName)"

    # Select the object's domain
    $domain = $domains | Where-Object {$_.DistinguishedName -eq $domainDN}
    Write-Verbose "Domain FQDN: $($domain.DNSRoot)"
    If ($domain -eq $null)
    {
        Throw "Cannot find Domain for object '$DistinguishedName'."
    }

    Return $domain.DNSRoot
}


<#
.Synopsis
   Find an AD object in the Forest by its DistinguishedName.
.DESCRIPTION
   Supports multi-domain queries and returns all the required properties including mS-DS-ConsistencyGuid.
   DistinguishedName value must be validated by the caller
#>
Function Search-ADSyncToolsADobjectByDN
{
    [CmdletBinding()]
    Param 
    (
        # Target DistinguishedName to search
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        $DistinguishedName
    )

    Import-ADSyncToolsActiveDirectoryModule

    $domainDNS = Get-ADSyncToolsDomainDns -DistinguishedName $DistinguishedName
    $targetDC = Get-ADSyncToolsADtargetDC -Service Readable -DomainName $domainDNS
    $domainDN = Get-ADSyncToolsDomainDN -DistinguishedName $DistinguishedName

    # Get the AD object from target DC
    Write-Verbose "Executing: Get-ADObject -Filter `"distinguishedName -eq '$DistinguishedName'`" -Properties $defaultADobjProperties -SearchBase $domainDN -SearchScope Subtree -Server $targetDC"           
    Try
    {
        $seachResult = Get-ADObject -Filter "distinguishedName -eq '$DistinguishedName'" -Properties $defaultADobjProperties -SearchBase $domainDN -SearchScope Subtree -Server $targetDC  -ErrorAction Stop
    }
    Catch
    {
        Throw "Cannot find user '$DistinguishedName': $($_.Exception.Message)"
    }

    Return $seachResult
}


<#
.Synopsis
   Find an AD object in the Forest by its UserPrincipalName.
.DESCRIPTION
   Supports multi-domain queries and returns all the required properties including mS-DS-ConsistencyGuid.
#>
Function Search-ADSyncToolsADobjectByUPN
{
    [CmdletBinding()]
    Param 
    (
        # Target UserPrincipalName to search
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        $UserPrincipalName
    )

    Import-ADSyncToolsActiveDirectoryModule

    $targetDC = Get-ADSyncToolsADtargetDC -Service GlobalCatalog
    
    # Get the AD object from target DC
    Write-Verbose "Executing: Get-ADObject -Filter `"UserPrincipalName -eq '$UserPrincipalName'`" -Server `"$($targetDC):3268`""
    Try
    {
        $globalCatalogObj = Get-ADObject -Filter "UserPrincipalName -eq '$UserPrincipalName'" -Server "$($targetDC):3268" -ErrorAction Stop
    }
    Catch
    {
        Throw "Cannot find user '$UserPrincipalName': $($_.Exception.Message)"
    }

    # Get all the required properties of the object including mS-DS-ConsistencyGuid
    If ($globalCatalogObj)
    {
        $seachResult = Search-ADSyncToolsADobjectByDN $globalCatalogObj.DistinguishedName
    }    

    Return $seachResult
}

#endregion
#=======================================================================================


#=======================================================================================
#region Troubleshooting Functions
#=======================================================================================

<#
.Synopsis
   Search an AD object in Active Directory Forest by its UserPrincipalName, sAMAccountName or DistinguishedName
.DESCRIPTION
   Supports multi-domain queries and returns all the required properties including mS-DS-ConsistencyGuid.
.EXAMPLE
   Search-ADSyncToolsADobject 'CN=user1,OU=Sync,DC=Contoso,DC=com'
.EXAMPLE
   Search-ADSyncToolsADobject -Identity "user1@Contoso.com"
.EXAMPLE
   Get-ADUser 'CN=user1,OU=Sync,DC=Contoso,DC=com' | Search-ADSyncToolsADobject
#>
Function Search-ADSyncToolsADobject
{
    [CmdletBinding()]
    Param 
    (
        # Target User in AD to set ConsistencyGuid
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        $Identity
    )

    Import-ADSyncToolsActiveDirectoryModule

    Try
    {
        
        if ($Identity.GetType()  -like "Microsoft.ActiveDirectory.Management*")
        {
            # User input is AD object, but it might not contain mS-DS-ConsistencyGuid property
            Write-Verbose "Identity input is an AD object - Getting AD user '$Identity' with required properties"
            $seachResult = Search-ADSyncToolsADobjectByDN $Identity.DistinguishedName
        }
        Else
        {
            If ($Identity -match $upnRegex)
            {
                # User input is in UPN format
                Write-Verbose "Identity input is an UserPrincipalName - Getting AD user '$Identity' with required properties"
                
                $seachResult = Search-ADSyncToolsADobjectByUPN -UserPrincipalName $Identity
            }
            Else
            {
                $escapedDN = Format-ADSyncToolsDistinguishedName -DistinguishedName $Identity
                If ($escapedDN -match $distinguishedNameRegex)
                {
                    # User input is in DistinguishedName format
                    Write-Verbose "Identity input is an DistinguishedName - Getting AD user '$Identity' with required properties"

                    $seachResult = Search-ADSyncToolsADobjectByDN -DistinguishedName $Identity
                }
                Else
                {
                    # Unknown format, try to seach on sAMAccountName on local domain
                    Write-Verbose "Identity input is a string - Searching for sAMAccountName '$Identity' on current AD Domain only"
                    $seachResult = Get-ADObject -Filter 'sAMAccountName -eq $Identity' -Properties $defaultADobjProperties -ErrorAction Stop
                    Write-Warning "Searching for sAMAccountName '$Identity' is limited the current AD Domain only. Please use a DistinguishedName or UserPrincipalName to search for objects across the entire AD Forest."
                }
            }
        }
    }
    Catch
    {
        Throw "Unable to search in Active Directory: $($_.Exception.Message)"
    }

    If ($seachResult)
    {
        # Create Custom Object to hold all the required properties
        $result = "" | Select Name, ObjectClass, DistinguishedName, ObjectGUID, mS-DS-ConsistencyGuid, ObjectSID, sAMAccountName, UserPrincipalName
        
        $result.Name = $seachResult.Name
        $result.ObjectClass = $seachResult.ObjectClass
        $result.DistinguishedName = $seachResult.DistinguishedName
        $result.ObjectGUID = $seachResult.ObjectGUID
        $result.ObjectSID = $seachResult.ObjectSID
        $result.sAMAccountName = $seachResult.sAMAccountName
        $result.UserPrincipalName = $seachResult.UserPrincipalName

        # Add mS-DS-ConsistencyGuid in Guid-string format
        If ($seachResult.'mS-DS-ConsistencyGuid' -ne $null)
        {
            Try
            {
                $result.'mS-DS-ConsistencyGuid' = [Guid] $seachResult.'mS-DS-ConsistencyGuid'
            }
            Catch
            {
                Write-Error "Unable to convert mS-DS-ConsistencyGuid to GUID: $($_.Exception.Message)"
            }
        }
        Else
        {
            Write-Verbose "Object '$($result.Name)' does not have a mS-DS-ConsistencyGuid value"
        }
    }
    Else
    {
        Throw "Unable to find object in Active Directory."
    }
    Return $result
}



<#
.Synopsis
   Get an Active Directory object ms-ds-ConsistencyGuid
.DESCRIPTION
   Returns the value in mS-DS-ConsistencyGuid attribute of the target Active Directory object in GUID format. 
   Supports Active Directory objects in multi-domain forests.
.EXAMPLE
   Get-ADSyncToolsMsDsConsistencyGuid -Identity 'CN=User1,OU=Sync,DC=Contoso,DC=com'
.EXAMPLE
   Get-ADSyncToolsMsDsConsistencyGuid -Identity 'User1@Contoso.com'
.EXAMPLE
   'User1@Contoso.com' | Get-ADSyncToolsMsDsConsistencyGuid
#>
Function Get-ADSyncToolsMsDsConsistencyGuid
{
    [CmdletBinding()]
    Param 
    (
        # Target object in AD to get
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        $Identity
    )
    
    # Get object from AD
    $adObject = Search-ADSyncToolsADobject -Identity $Identity

    # Get mS-DS-ConsistencyGuid value
    Write-Verbose "Object '$($adObject.Name)' | mS-DS-ConsistencyGuid: $($adObject.'mS-DS-ConsistencyGuid')"

    Return $adObject.'mS-DS-ConsistencyGuid'
}



<#
.Synopsis
   Set an Active Directory object ms-ds-ConsistencyGuid
.DESCRIPTION
   Sets a value in mS-DS-ConsistencyGuid attribute for the target Active Directory user.
   Supports Active Directory objects in multi-domain forests.
.EXAMPLE
   Set-ADSyncToolsMsDsConsistencyGuid -Identity 'CN=User1,OU=Sync,DC=Contoso,DC=com' -Value '88666888-0101-1111-bbbb-1234567890ab'
.EXAMPLE
   Set-ADSyncToolsMsDsConsistencyGuid -Identity 'CN=User1,OU=Sync,DC=Contoso,DC=com' -Value 'GGhsjYwBEU+buBsE4sqhtg=='
.EXAMPLE
   Set-ADSyncToolsMsDsConsistencyGuid 'User1@Contoso.com' '8d6c6818-018c-4f11-9bb8-1b04e2caa1b6'
.EXAMPLE
   Set-ADSyncToolsMsDsConsistencyGuid 'User1@Contoso.com' 'GGhsjYwBEU+buBsE4sqhtg=='   
.EXAMPLE
   '88666888-0101-1111-bbbb-1234567890ab' | Set-ADSyncToolsMsDsConsistencyGuid -Identity User1
.EXAMPLE
   'GGhsjYwBEU+buBsE4sqhtg==' | Set-ADSyncToolsMsDsConsistencyGuid User1

#>
Function Set-ADSyncToolsMsDsConsistencyGuid
{
    [CmdletBinding()]
    Param 
    (
        # Target object in AD to set mS-DS-ConsistencyGuid
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        $Identity,

        # Value to set (ImmutableId, Byte array, GUID, GUID string or Base64 string)
        [Parameter(Mandatory=$true,
                   Position=1,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        $Value
    )
    
    # Parse ConsistencyGuid value to set
    Switch ($Value.GetType().Name)
    {
        'Guid'     # Value is a GUID
        {
            $keepTrying = $false
            $targetValue = $Value
        }
        'String'   # Value is a string, either a GUID string or a Based64 encoded GUID
        {   
            $keepTrying = $false
            Try
            {
                # Try to decode from Base64
                $targetValueDecoded = [system.convert]::FromBase64String($Value)
                Write-Verbose "Value converted from Base64 string"
            }
            Catch
            {
                # Could not convert from Base64
                $keepTrying = $true
                Write-Verbose "Value cannot be converted from Base64 string"
            }

            if (-not $keepTrying)
            {
                # Value decoded from Base64 successfully
                Try
                {
                    # Try to convert to GUID
                    $targetValue = [GUID] $targetValueDecoded
                    Write-Verbose "Value converted from decoded Base64 string"
                }
                Catch
                {
                    # Fatal, could not convert Base64 to GUID
                    Throw "$Value is not recognized as a valid GUID value: $($_.Exception.Message)"
                }
            }
        }
        Default 
        {
            $keepTrying = $true
        }
    }
    
    # Continue parsing ConsistencyGuid value
    If ($keepTrying)
    {
        # Still not a GUID value
        Write-Verbose "Still trying to convert Value to GUID. - Value Type = $($Value.getType())"
        Try
        {
            # Try to convert to GUID directy
            $targetValue = [GUID] $Value
            Write-Verbose "Converted mS-DS-ConsistencyGuid value successfully: $targetValue"
        }
        Catch
        {
            # Fatal, could not convert from Base64
            Throw "'$Value' is not recognized as a valid GUID: $($_.Exception.Message)"
        }
    }

    # Get the target object from AD
    $adObject = Search-ADSyncToolsADobject -Identity $Identity
    Write-Verbose "Found Object '$($adObject.Name)' | mS-DS-ConsistencyGuid: $($adObject.'mS-DS-ConsistencyGuid')"

    # Get the target Writable DC
    $domainDNS = Get-ADSyncToolsDomainDns -DistinguishedName $adObject.DistinguishedName
    $targetDC = Get-ADSyncToolsADtargetDC -Service Writable -DomainName $domainDNS

    Try
    {
        # Set the target mS-DS-ConsistencyGuid
        Set-ADObject -Identity $adObject.DistinguishedName -Replace @{'mS-DS-ConsistencyGuid'=$targetValue} -Server $targetDC
        Write-Verbose "New mS-DS-ConsistencyGuid set: $targetValue"
    }
    Catch
    {
        # Fatal, could not set user
        Throw "Unable to set mS-DS-ConsistencyGuid on '$($adObject.Name)': $($_.Exception.Message)"
    }
}


<#
.Synopsis
   Clear an Active Directory object mS-DS-ConsistencyGuid
.DESCRIPTION
   Clears the value in mS-DS-ConsistencyGuid for the target Active Directory object.
   Supports Active Directory objects in multi-domain forests.
.EXAMPLE
   Clear-ADSyncToolsMsDsConsistencyGuid -Identity 'CN=User1,OU=Sync,DC=Contoso,DC=com'
.EXAMPLE
   Clear-ADSyncToolsMsDsConsistencyGuid -Identity 'User1@Contoso.com'
.EXAMPLE
   'User1@Contoso.com' | Clear-ADSyncToolsMsDsConsistencyGuid
#>
Function Clear-ADSyncToolsMsDsConsistencyGuid
{
    [CmdletBinding()]
    Param 
    (
        # Target object in AD to clear mS-DS-ConsistencyGuid
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        $Identity
    )
    
    # Get target object from AD
    $adObject = Search-ADSyncToolsADobject -Identity $Identity
    Write-Verbose "Found Object '$($adObject.Name)' | mS-DS-ConsistencyGuid: $($adObject.'mS-DS-ConsistencyGuid')"

    # Get the target Writable DC
    $domainDNS = Get-ADSyncToolsDomainDns -DistinguishedName $adObject.DistinguishedName
    $targetDC = Get-ADSyncToolsADtargetDC -Service Writable -DomainName $domainDNS

    If ($adObject)
    {
        Set-ADObject -Identity $adObject.DistinguishedName -Clear 'mS-DS-ConsistencyGuid' -Server $targetDC
    }
}



<#
.Synopsis
   Convert Base64 ImmutableId (SourceAnchor) to GUID value
.DESCRIPTION
   Converts value of the ImmutableID from Base64 string and returns a GUID value
   In case Base64 string cannot be converted to GUID, returns a Byte Array.
.EXAMPLE
   ConvertFrom-ADSyncToolsImmutableID 'iGhmiAEBERG7uxI0VniQqw=='
.EXAMPLE
   'iGhmiAEBERG7uxI0VniQqw==' | ConvertFrom-ADSyncToolsImmutableID 
#>
Function ConvertFrom-ADSyncToolsImmutableID
{
    [CmdletBinding()]
    Param 
    (
        # ImmutableId in Base64 format
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Value
    )

    Try
    {
        # Try to decode from Base64
        $targetValueFromB64 = [system.convert]::FromBase64String($Value)
        Write-Verbose "Value converted from Base64 string."
    }
    Catch
    {
        # Could not convert from Base64
        Throw "Value '$Value' is not a valid Base64 string."
    }

    If ($targetValueFromB64 -ne $null)
    {
        Try
        {
            # Try to convert to GUID
            $targetValue = [GUID] $targetValueFromB64
            Write-Verbose "Value converted from Base64 string to Guid."
        }
        Catch
        {
            # Could not convert Base64 to GUID
            Write-Error "$Value cannot be converted to a GUID value: $($_.Exception.Message)"
            Write-Warning "Returning result as a byte array:"
            $targetValue = $targetValueFromB64
        }
    }    
    Return $targetValue
}


<#
.Synopsis
   Convert GUID (ObjectGUID / ms-Ds-Consistency-Guid) to a Base64 string 
.DESCRIPTION
   Converts a value in GUID, GUID string or byte array format to a Base64 string
.EXAMPLE
   ConvertTo-ADSyncToolsImmutableID '88888888-0101-3333-cccc-1234567890cd'
.EXAMPLE
   '88888888-0101-3333-cccc-1234567890cd' | ConvertTo-ADSyncToolsImmutableID
#>
Function ConvertTo-ADSyncToolsImmutableID
{
    [CmdletBinding()]
    Param 
    (
        # GUID, GUID string or byte array
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        $Value
    )

    # Value ValidateNotNullOrEmpty
    If ($Value -eq $null -or $Value -eq "")
    {
        Throw "ConvertTo-ADSyncToolsImmutableID : Cannot validate argument on parameter 'Value'. The argument is null or empty. Provide an argument that is not null or empty, and then try the command again."
    }

    # Convert Value to Byte Array
    Switch ($Value.GetType().Name)
    {
        'Guid'     
        {
            # Value is a GUID
            Write-Verbose "Input value is a GUID object. Converting to byte array..."
            Try
            {            
                $valueByteArray = $Value.ToByteArray()
            }
            Catch
            {
                # Failed convertion to byte array
                Throw "$Value is not recognized as a valid GUID: $($_.Exception.Message)"
            }
        }
        'String'   
        {   
            # Value is a GUID string
            Write-Verbose "Input value is a GUID string. Converting to byte array..."
            Try
            {
                $valueByteArray = $([GUID] $Value).ToByteArray()
                
            }
            Catch
            {
                # Failed convertion to byte array
                Throw "$Value is not recognized as a valid GUID: $($_.Exception.Message)"
            }

        }
        'Byte[]' 
        {
            # Value is a Byte Array
            Write-Verbose "Input value is a byte array. Convertion is not required."
            $valueByteArray = $Value
        }
        Default  
        {
            # Unknown format
            Throw "$Value is not recognized as a valid GUID."
        }
    }
    Return [system.convert]::ToBase64String($valueByteArray)
}


<#
.Synopsis
   Export Azure AD Connect Objects to XML files
.DESCRIPTION
   Exports internal ADSync objects from Metaverse and associated connected objects from Connector Spaces
.EXAMPLE
   Export-ADSyncToolsObjects -ObjectId '9D220D58-0700-E911-80C8-000D3A3614C0' -Source Metaverse
.EXAMPLE
   Export-ADSyncToolsObjects -ObjectId '9e220d58-0700-e911-80c8-000d3a3614c0' -Source ConnectorSpace
.EXAMPLE
   Export-ADSyncToolsObjects -DistinguishedName 'CN=User1,OU=ADSync,DC=Contoso,DC=com' -ConnectorName 'Contoso.com'
#>
Function Export-ADSyncToolsObjects
{
    [CmdletBinding()]
    Param
    (
        # ObjectId is the unique identifier of the object in the respective connector space or metaverse
        [Parameter(ParameterSetName='ObjectId',
                    Mandatory=$true,
                    ValueFromPipelineByPropertyName=$true,
                    Position=0)]
        $ObjectId,

        # Source is the table where the object resides which can either ConnectorSpace or Metaverse
        [Parameter(ParameterSetName='ObjectId',
                    Mandatory=$true,
                    ValueFromPipelineByPropertyName=$true,
                    Position=1)]
        [ValidateSet('ConnectorSpace','Metaverse')]
        $Source,

        # DistinguishedName is the identifier of the object in the respective connector space
        [Parameter(ParameterSetName='DistinguishedName',
                    Mandatory=$true,
                    ValueFromPipelineByPropertyName=$true,
                    Position=0)]
        $DistinguishedName,

        # ConnectorName is the name of the connector space where the object resides
        [Parameter(ParameterSetName='DistinguishedName',
                    Mandatory=$true,
                    ValueFromPipelineByPropertyName=$true,
                    Position=1)]
        $ConnectorName,

        # ExportSerialized exports additional XML files
        [Parameter(Mandatory=$false,
                    Position=2)]
        [switch] 
        $ExportSerialized
    )

    # Function init
    [string] $functionMsg = "Export-ADSyncToolsObjects :"
    [string] $paramSetName = $PSCmdlet.ParameterSetName
    [string] $dateStr = '.\' + (Get-Date).toString('yyyyMMdd-HHmmss') + '_'

    Write-Verbose "$functionMsg ParameterSetName: $paramSetName"

    if ($Source -eq 'Metaverse')
    {
        # Export objects based on metaverse ObjectId
        Export-ADSyncMVObject -MVObjectId $ObjectId -Prefix $dateStr -ExportSerialized $ExportSerialized
    }
    Else
    {
        Switch ($paramSetName)
        {
            'ObjectId' 
            {        
                # Find object based on connector space ObjectId
                $csObject = Get-ADSyncToolsMVObjFromCSID -CSObjectId $ObjectId
            }
            'DistinguishedName' 
            {
                # Find object based on distinguished name and connector name
                $csObject = Get-ADSyncToolsMVObjFromCSDN -DistinguishedName $DistinguishedName -ConnectorName $ConnectorName
            }
        }

        If ($csObject.ConnectedMVObjectId -eq '00000000-0000-0000-0000-000000000000')
        {
            # Object is a disconnector - Export CS object only
            Write-Verbose "$functionMsg Object is not connected to the Metaverse (Disconnector)."
            Export-ADsyncCSObject -CSObjectId $csObject.ObjectId -Prefix $dateStr -ExportSerialized $ExportSerialized
        }
        Else
        {
            # Export objects based on metaverse ObjectId
            Export-ADSyncMVObject -MVObjectId $csObject.ConnectedMVObjectId -Prefix $dateStr -ExportSerialized $ExportSerialized
        }
    }
}



<#
.Synopsis
   Import Azure AD Connect Object from XML file
.DESCRIPTION
   Imports an internal ADSync object from XML file that was exported using Export-ADSyncToolsObjects
.EXAMPLE
   Import-ADSyncToolsObjects -Path .\20210224-003104_81275a23-0168-eb11-80de-00155d188c11_MV.xml
#>
Function Import-ADSyncToolsObjects
{
    [CmdletBinding()]
    Param
    (
        # Path for the XML file to import
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Path
    )

    If (Test-Path $Path)
    {
        Try
        {
            Import-Clixml $Path
        }
        Catch
        {
            Write-Error "Unable to import file '$Path'. Error Details: $($_.Exception.Message)"
        }
    }
    Else
    {
        Write-Error "File not found."
    }
}


<#
.SYNOPSIS
    Find object in Metaverse based on Connector Space ObjectId
#>
Function Get-ADSyncToolsMVObjFromCSID
{
    [CmdletBinding()]
    Param
    (
        # CSObjectId is the Id of the object in the respective Connector Space
        [Parameter(Mandatory=$true,
                   ValueFromPipelineByPropertyName=$true,
                   Position=0)]
        $CSObjectId
    )

    # Function init
    [string] $functionMsg = "Get-ADSyncToolsMVObjFromCSID :"

    Write-Verbose "$functionMsg Searching Connector Space object $CSObjectId ..."

    Try
    {
        # Read object from Connector Space
        $csObj = Get-ADSyncCSObject -Identifier $CSObjectId
    }
    Catch
    {
        Throw "$functionMsg Unable to find object in Connector Space. Error Details: $($_.Exception.Message)"
    }

    # Return result
    If ($csObj -ne $null)
    {
        Write-Verbose "$functionMsg Found Connector Space ObjectId $($csObj.ObjectId) connected to MV ObjectId $($csObj.ConnectedMVObjectId)."
        Return $csObj
    }
    Else
    {
        Throw "$functionMsg Unable to find object '$CSObjectId' in Connector Space."
    }

}


<#
.SYNOPSIS
    Find object in Metaverse based on Connector Space DN
#>
Function Get-ADSyncToolsMVObjFromCSDN
{
    [CmdletBinding()]
    Param
    (
        # DistinguishedName is the identifier of the object in the respective connector space
        [Parameter(Mandatory=$true,
                   ValueFromPipelineByPropertyName=$true,
                   Position=0)]
        $DistinguishedName,

        # ConnectorName is the name of the connector space where the object resides
        [Parameter(Mandatory=$true,
                   ValueFromPipelineByPropertyName=$true,
                   Position=1)]
        $ConnectorName
    )

    # Function init
    [string] $functionMsg = "Get-ADSyncToolsMVObjFromCSDN :"
    Write-Verbose "$functionMsg Searching for '$DistinguishedName' in '$ConnectorName' ..."

    Try
    {
        # Read object from Connector Space
        $csObj = Get-ADSyncCSObject -DistinguishedName $DistinguishedName -ConnectorName $ConnectorName
    }
    Catch
    {
        Throw "$functionMsg Unable to find object in Connector Space. Error Details: $($_.Exception.Message)"
    }

    # Return result
    If ($csObj -ne $null)
    {
        Write-Verbose "$functionMsg Found Connector Space ObjectId $($csObj.ObjectId) connected to MV ObjectId $($csObj.ConnectedMVObjectId)."
        Return $csObj
    }
    Else
    {
        Throw "$functionMsg Unable to find object '$DistinguishedName' in Connector Space $ConnectorName."
    }

}


<#
.SYNOPSIS
    Export an object from Connector Space
#>
Function Export-ADsyncCSObject
{
    [CmdletBinding()]
    Param
    (
        # CSObjectId is the Id of the object in the respective Connector Space
        [Parameter(Mandatory=$true,
                   ValueFromPipelineByPropertyName=$true,
                   Position=0)]
        $CSObjectId,

        # Prefix is a string value which will be used to prefix the filename (Optional)
        [Parameter(Mandatory=$false,
                   ValueFromPipelineByPropertyName=$true,
                   Position=1)]
        $Prefix,

        # ExportSerialized exports additional XML files
        [Parameter(Mandatory=$false,
                    Position=2)]
        [bool] 
        $ExportSerialized = $false
    )

    # Function init
    [string] $functionMsg = "Export-ADsyncCSObject :"

    Write-Verbose "$functionMsg Exporting Connector Space object $CSObjectId ..."

    Try
    {
        # Read object from Connector Space
        $csObj = Get-ADSyncCSObject -Identifier $CSObjectId
    }
    Catch
    {
        Throw "$functionMsg Unable to find object '$CSObjectId' in Connector Space. Error Details: $($_.Exception.Message)"
    }

    # If object found
    If ($csObj -ne $null)
    {
        If ($ExportSerialized)
        {
            # Export SerializedXml data
            $Filename = $Prefix + $CSObjectId + "_CS-Serialized.xml"
            $csObj.SerializedXml | Out-File $Filename
        }

        # Export all properties
        $Filename = $Prefix + $CSObjectId + "_CS.xml"
        $csObj | Select ObjectId,`
                        ConnectorId,`
                        ConnectorName,`
                        ConnectorType,`
                        PartitionId,`
                        DistinguishedName,`
                        AnchorValue,`
                        ObjectType,`
                        IsConnector,`
                        HasSyncError,`
                        HasExportError,`
                        ConnectedMVObjectId,`
                        Lineage,`
                        Attributes | Export-Clixml $Filename

        Write-Verbose "$functionMsg Exported Connector Space object to file '$Filename'."
    }
    Else
    {
        Throw "$functionMsg Unable to find object in Connector Space."
    }

}

<#
.SYNOPSIS
    Export object from Metaverse
#>
Function Export-ADSyncMVObject
{
    [CmdletBinding()]
    Param
    (
        # MVObjectId is the Id of the object in the Metaverse
        [Parameter(Mandatory=$true,
                   ValueFromPipelineByPropertyName=$true,
                   Position=0)]
        $MVObjectId,

        # Prefix is a string value which will be used to prefix the filename (Optional)
        [Parameter(Mandatory=$false,
                   ValueFromPipelineByPropertyName=$true,
                   Position=1)]
        $Prefix,

        # ExportSerialized exports additional XML files
        [Parameter(Mandatory=$false,
                    Position=2)]
        [bool] 
        $ExportSerialized = $false

    )

    # Function init
    [string] $functionMsg = "Export-ADSyncMVObject :"

    Write-Verbose "$functionMsg Exporting MV object $MVObjectId ..."

    Try
    {
        # Read object from Metaverse
        $mvObj = Get-ADSyncMVObject -Identifier $MVObjectId
    }
    Catch
    {
        Throw "$functionMsg Unable to find object in Metaverse. Error Details: $($_.Exception.Message)"
    }

    # If object found
    If ($mvObj -ne $null)
    {
        If ($ExportSerialized)
        {
            # Export SerializedXml data
            $Filename = $Prefix + $MVObjectId + "_MV-Serialized.xml"
            $mvObj.SerializedXml | Out-File $Filename
        }

        # Export Lineage data
        $Filename = $Prefix + $MVObjectId + "_MV.xml"
        $mvObj | Select ObjectId, Lineage, Attributes | Export-Clixml $Filename

        Write-Verbose "$functionMsg Exported MV object to file '$Filename'."

        # Export all Connected objects from the respective Connector Spaces
        ForEach ($connector in $mvObj.Lineage)
        {
            Export-ADsyncCSObject -CsObjectId $connector.ConnectedCsObjectId -Prefix $Prefix -ExportSerialized $ExportSerialized
        }
    }
    Else
    {
        Throw "$functionMsg Unable to find object '$MVObjectId' in Metaverse."
    }
}


<#
.Synopsis
   Convert AAD Connector DistinguishedName to ImmutableId
.DESCRIPTION
   Takes an AAD Connector DistinguishedName like CN={514635484D4B376E38307176645973555049486139513D3D}
   and converts to the respective base64 ImmutableID value, e.g. QF5HMK7n80qvdYsUPIHa9Q==
.EXAMPLE
   ConvertFrom-ADSyncToolsAadDistinguishedName 'CN={514635484D4B376E38307176645973555049486139513D3D}' 
#>
Function ConvertFrom-ADSyncToolsAadDistinguishedName
{
    Param
    (
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [string] $DistinguishedName
    )

    Import-ADSyncToolsAADConnectorBinaries

    Try
    {
        $result = [Microsoft.Online.DirSync.Extension.Utilities.DNEncoding]::SafeRdnToString($DistinguishedName);
    }
    Catch
    {
        Throw "Unable to convert DistinguishedName to ImmutableId (SourceAnchor). Error Details: $($_.Exception.Message)"
    }
    $result
}


<#
.Synopsis
   Convert ImmutableId to AAD Connector DistinguishedName
.DESCRIPTION
   Takes an Immutable (SourceAnchor) like QF5HMK7n80qvdYsUPIHa9Q== and converts to the respective
   AAD Connector DistinguishedName value, e.g. CN={514635484D4B376E38307176645973555049486139513D3D}
.EXAMPLE
   ConvertTo-ADSyncToolsAadDistinguishedName 'QF5HMK7n80qvdYsUPIHa9Q=='
#>
Function ConvertTo-ADSyncToolsAadDistinguishedName
{
    Param
    (
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [string] $ImmutableId
    )

    Import-ADSyncToolsAADConnectorBinaries

    Try
    {
        $result = [Microsoft.Online.DirSync.Extension.Utilities.DNEncoding]::StringToSafeRdn($ImmutableId);
    }
    Catch
    {
        Throw "Unable to convert ImmutableId (SourceAnchor) to AAD Connector DistinguishedName. Error Details: $($_.Exception.Message)"
    }  
    $result
}


<#
.Synopsis
   Convert Base64 Anchor to CloudAnchor
.DESCRIPTION
   Takes a Base64 Anchor like VAAAAFUAcwBlAHIAXwBjADcAMgA5ADAAMwBlAGQALQA3ADgAMQA2AC0ANAAxAGMAZAAtADkAMAA2ADYALQBlAGEAYwAzADMAZAAxADcAMQBkADcANwAAAA==
   and converts to the respective CloudAnchor value, e.g. User_abc12345-1234-abcd-9876-ab0123456789
.EXAMPLE
   ConvertTo-ADSyncToolsCloudAnchor "VAAAAFUAcwBlAHIAXwBjADcAMgA5ADAAMwBlAGQALQA3ADgAMQA2AC0ANAAxAGMAZAAtADkAMAA2ADYALQBlAGEAYwAzADMAZAAxADcAMQBkADcANwAAAA==" 
.EXAMPLE
   "VAAAAFUAcwBlAHIAXwBjADcAMgA5ADAAMwBlAGQALQA3ADgAMQA2AC0ANAAxAGMAZAAtADkAMAA2ADYALQBlAGEAYwAzADMAZAAxADcAMQBkADcANwAAAA==" | ConvertTo-ADSyncToolsCloudAnchor
#>
Function ConvertTo-ADSyncToolsCloudAnchor
{
    Param
    (
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [string] $Anchor
    )

    $encodedRawAnchor =  [System.Convert]::FromBase64String($Anchor);
    $rawAnchor = $encodedRawAnchor[4..($encodedRawAnchor.Length - 3)]
    $cloudAnchor = [System.Text.Encoding]::Unicode.GetString($rawAnchor)
    $cloudAnchor
}



<#
.Synopsis
   Export Azure AD Disconnector objects
.DESCRIPTION
   Executes CSExport tool to export all Disconnectors to XML and then takes this XML output and converts it to a CSV file
   with: UserPrincipalName, Mail, SourceAnchor, DistinguishedName, CsObjectId, ObjectType, ConnectorId, CloudAnchor
.EXAMPLE
   Export-ADSyncToolsDisconnectors -SyncObjectType 'PublicFolder'
   Exports to CSV all PublicFolder Disconnector objects
.EXAMPLE
   Export-ADSyncToolsDisconnectors
   Exports to CSV all Disconnector objects
.INPUTS
   Use ObjectType argument in case you want to export Disconnectors for a given object type only
.OUTPUTS
   Exports a CSV file with Disconnector objects containing: 
   UserPrincipalName, Mail, SourceAnchor, DistinguishedName, CsObjectId, ObjectType, ConnectorId and CloudAnchor
#>
Function Export-ADSyncToolsAadDisconnectors
{
    [CmdletBinding()]
    Param
    (
        # ObjectType to include in output
        [Parameter(Mandatory=$false,
                   Position=0,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("User", "Group", "Contact", "PublicFolder", "Device")]
        $SyncObjectType
    )

    # Get Azure AD Connector name
    Try
    {
        $aadConnectorName = (Get-ADSyncConnector | Where-Object {$_.Identifier -eq 'b891884f-051e-4a83-95af-2544101c9083'}).Name
    }
    Catch
    {
        Throw "Error: Unable to retrieve Azure AD Connector name. Make sure ADSync service is running. `nDetails: $($_.Exception.Message)"
    }

    # Export Disconnectors to XML with CSExport tool
    $targetFilename = [string] "$(Get-Date -Format yyyyMMdd-HHmmss)_Disconnectors"
    $cmd = Join-Path -Path $(Get-ADSyncToolsADsyncFolder) -ChildPath 'Bin\csexport.exe'
    Write-Verbose "Executing command : $cmd"
    $result = & $cmd $($aadConnectorName) $($targetFilename + '.xml') '/f:s /o:h'
    If ($lastexitcode -eq 0)
    {
        $result
    }
    Else
    {
        Throw "Error: Unable to retrieve Disconnector objects with CSExport tool. `nDetails:  $result"
    }

    # Process Disconnector objects from XML output
    Try
    {
        [xml] $disconnectors = Get-Content $($targetFilename + '.xml')
    }
    Catch
    {
            Throw "Error: Unable to read Disconnector XML file. Error Details: $($_.Exception.Message)"
    }

    # Filter out ObjectType
    If ($SyncObjectType -eq $null)
    {
        $disconnectorObjs = $disconnectors.'cs-objects'.'cs-object'
        Write-Host "Exporting $($disconnectorObjs.Count) Disconnector objects..." 
    }
    Else
    {
        $disconnectorObjs = $disconnectors.'cs-objects'.'cs-object' | Where-Object {$_.'object-type' -eq $SyncObjectType}
        Write-Host "Exporting $($disconnectorObjs.Count) Disconnector ($SyncObjectType) objects..." 
        
    }

    # Export to CSV file
    $results = @()
    ForEach ($obj in $disconnectorObjs)
    {
        $row = "" | select UserPrincipalName, Mail, SourceAnchor, DistinguishedName, CsObjectId, ObjectType, ConnectorId, CloudAnchor
        $row.UserPrincipalName =  ($obj.'pending-import-hologram'.entry.attr | Where-Object {$_.name -eq 'userPrincipalName'}).Value
        $row.Mail = ($obj.'pending-import-hologram'.entry.attr | Where-Object {$_.name -eq 'mail'}).Value
        $row.SourceAnchor = ($obj.'pending-import-hologram'.entry.attr | where {$_.name -eq 'sourceAnchor'}).Value
        $row.DistinguishedName = $obj.'cs-dn'
        $row.CsObjectId = $obj.id
        $row.ObjectType = $obj.'object-type'
        $row.ConnectorId = $obj.'ma-id'
        $row.CloudAnchor = ($obj.'pending-import-hologram'.entry.attr | Where-Object {$_.name -eq 'cloudAnchor'}).Value
        $results += $row

    }
    $results | Export-Csv -Path $($targetFilename + '.csv') -NoTypeInformation
}


<#
.Synopsis
   Get synced objects for a given SyncObjectType
.DESCRIPTION
   Reads from Azure AD all synced objects for a given object class (SyncObjectType). 
.EXAMPLE
   Get-ADSyncToolsAadObject -SyncObjectType 'publicFolder' -Credentials $(Get-Credential) 
.OUTPUTS
   This cmdlet returns the "Shadow" properties that are synchronized by the sync client, 
   which might be different than the actual value stored in the respective property of Azure AD.
   For instante, a user's UPN that is synchronized with a non-verified domain suffix 'user@nonverified.domain',
   will have the UPN suffix in Azure AD converted to the tenant's default domain, 'user@tenantname.onmicrosoft.com'
   In this case, Get-ADSyncToolsAadObject will return the "Shadow" value of 'user@nonverified.domain',
   and not the actual value in Azure AD 'user@tenantname.onmicrosoft.com'
#>
Function Get-ADSyncToolsAadObject
{
    [CmdletBinding()]
    Param
    (
        # Object Type
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("User", "Group", "Contact", "PublicFolder", "Device")]
        $SyncObjectType,

        # Azure AD Global Admin Credentials
        [Parameter(Mandatory=$true, 
                   Position=1,
                   ValueFromPipelineByPropertyName=$true)]
        [PSCredential] 
        $Credentials
    )

    # BEGIN
    Import-ADSyncToolsAADConnectorBinaries
    Try
    {
        $enumerator = [Microsoft.Azure.ActiveDirectory.Connector.Diagnostics.DiagnosticsFactory]::CreateChangeEnumerator(`
            $Credentials.UserName, `
            $Credentials.Password, `
            $SyncObjectType, `
            $null, `
            'Full', `
            2)
    }
    Catch
    {
        Throw "There was a problem initiating Enumerator component. Error Details: $($_.Exception.Message)"
    }

    # PROCESS
    $results = @()
    Do
    {
        Try
        {
            $batch = $enumerator.EnumerateNextBatch()
        }
        Catch
        {
            Throw "There was a problem with the Enumerator component. Error Details: $($_.Exception.Message)"
        }

        If ($batch.AadBatch.ResultObjects.Count -gt 0)
        {
            ForEach($entry in $batch.AadBatch.ResultObjects)
            {
                # Skip deleted objects
                If ($entry.SyncOperation -ne 'Delete')
                {
                    $r = "" | select ObjectClass, ObjectId, CloudAnchor

                    $r.CloudAnchor = $entry.PropertyValues.CloudAnchor
                    $cloudAnchoraSplit = $r.CloudAnchor -split '_'
                    $r.ObjectClass = $cloudAnchoraSplit[0]
                    $r.ObjectId = $cloudAnchoraSplit[1]

                    # Add all non-null properties as a string value
                    $properties = $entry.PropertyValues
                    # Also Supports CloudLegacyExchangeDN an CloudMSExchRecipientDisplayType properties
                    $propertyKeys = @('SourceAnchor','DisplayName','Mail')
                    ForEach ($propKey in $propertyKeys)
                    {
                        $propValue = $properties[$propKey]
                        if ($propValue -ne $null)
                        {
                            $propValue = $propValue.ToString()
                        }
                        Else
                        {
                            $propValue = ""
                        }
                        Add-Member -InputObject $r -MemberType NoteProperty -Name $propKey -Value $propValue -Force
                    }
                    
                    # Add ProxyAddresses as an array
                    $proxyAddresses = @()
                    If ($($properties['ProxyAddresses']).Count -gt 0)
                    {
                        ForEach ($address in $properties['ProxyAddresses'])
                        {
                            $proxyAddresses += $address.ToString()
                        }

                    }
                    Add-Member -InputObject $r -MemberType NoteProperty -Name ProxyAddresses -Value $proxyAddresses -Force
                    
                    # Add UserPrincipalName
                    If ($SyncObjectType -eq 'User')
                    {
                        $propKey = 'UserPrincipalName'
                        $propValue = $properties[$propKey]
                        if ($propValue -ne $null)
                        {
                            $propValue = $propValue.ToString()
                        }
                        Else
                        {
                            $propValue = ""
                        }
                        Add-Member -InputObject $r -MemberType NoteProperty -Name $propKey -Value $propValue -Force
                    }
                    $results += $r
                }
            }
        }
    }
    Until ($batch.AadBatch.MoreToRead -eq $false)

    #END
    $enumerator.Dispose()
    $results
}



<#
.Synopsis
   Remove orphaned synced object from Azure AD
.DESCRIPTION
   Deletes from Azure AD a synced object(s) based on SourceAnchor and ObjecType in batches of 10 objects
   The CSV file can be generated using Export-ADSyncToolsAadDisconnectors
.EXAMPLE
   Remove-ADSyncToolsAadObject -InputCsvFilename .\DeleteObjects.csv -Credentials (Get-Credential)
.EXAMPLE
   Remove-ADSyncToolsAadObject -SourceAnchor '2epFRNMCPUqhysJL3SWL1A==' -SyncObjectType 'publicFolder' -Credentials (Get-Credential)
.INPUTS
   InputCsvFilename must point to a CSV file with at least 2 columns: SourceAnchor, SyncObjectType
.OUTPUTS
   Shows results from ExportDeletions operation
.NOTES
   DISCLAIMER: Other than User objects that have a Recycle Bin, any other object types DELETED with this function cannot be RECOVERED!
#>
Function Remove-ADSyncToolsAadObject
{
    [CmdletBinding(SupportsShouldProcess=$true, 
                   PositionalBinding=$false,
                   ConfirmImpact='High')]
    Param
    (
        # Azure AD Global Admin Credentials
        [Parameter(Mandatory=$true, 
                   Position=0,
                   ValueFromPipelineByPropertyName=$true)]
        [PSCredential] 
        $Credentials,


        # CSV Input filename
        [Parameter(ParameterSetName='CsvInput',
                   Mandatory=$true,
                   Position=1,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        $InputCsvFilename,
        
        # Object SourceAnchor
        [Parameter(ParameterSetName='ObjectInput',
                   Mandatory=$true,
                   Position=1,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        $SourceAnchor,

        # Object Type
        [Parameter(ParameterSetName='ObjectInput',
                   Mandatory=$true,
                   Position=2,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("User", "Group", "Contact", "PublicFolder")]
        $SyncObjectType

    )

    # BEGIN
    Import-ADSyncToolsAADConnectorBinaries
    Write-Verbose "ParameterSetName: $($PSCmdlet.ParameterSetName)"

    Try
    {
        $exporter = `
        [Microsoft.Azure.ActiveDirectory.Connector.Diagnostics.DiagnosticsFactory]::CreateDirectoryChangeExporter( `
            $Credentials.UserName, `
            $Credentials.Password)
    }
    Catch
    {
        Throw "There was a problem initiating Exporter component. Error Details: $($_.Exception.Message)"
    }

    If ($($PSCmdlet.ParameterSetName) -eq 'CsvInput')
    {
        Try
        {
            $objects = @(Import-Csv $InputCsvFilename)
            Write-Verbose "CsvInput: $InputCsvFilename | ObjectCount = $($objects.Count)"
        }
        Catch
        {
            Throw "There was a problem importing and processing CSV input file. Error Details: $($_.Exception.Message)"
        }
    }
    Else
    {
        $object = "" | Select SyncObjectType,SourceAnchor
        $object.SyncObjectType = $SyncObjectType
        $object.SourceAnchor = $SourceAnchor
        Write-Verbose "ObjectInput: $($object.SyncObjectType) | $($object.SourceAnchor)"
        $objects = @($object)
    }

    Try
    {
        $entries = @()
        ForEach ($obj in $objects)
        {
            # Lower 1st char
            [string] $syncObjectTypeLowerCase = $($obj.SyncObjectType[0].ToString().ToLower()) + $obj.SyncObjectType.Substring(1)
            Write-Verbose "Processing: DeleteEntry = $syncObjectTypeLowerCase | $($obj.SourceAnchor)"
            # Add DeleteEntry
            $entries += [Microsoft.Azure.ActiveDirectory.Connector.Diagnostics.DeletionEntry]::FromSourceAnchor($syncObjectTypeLowerCase, $obj.SourceAnchor)
        }
    }
    Catch
    {
        Throw "There was a problem creating DeletionEntry list. Error Details: $($_.Exception.Message)"
    }

    $objsCount = $objects.Count
    $objsProcessed = 0
    $batchSize = 10
    $nextBatch = @()

    # PROCESS
    Try 
    {
        While ($objsProcessed -lt $objsCount) 
        {
            # Progress bar
            $percent = [math]::Round($(($objsProcessed * 100) / $objsCount), 1)
            Write-Progress -Activity "Deleting objects from Azure AD" -Status "$($percent)% Complete:" -PercentComplete $percent;
            
            # Process batch
            $nextBatch = $entries | Select-Object -First $batchSize
            $entries = $entries | Select-Object -Skip $batchSize

            $nextBatch | Out-String

            if ($pscmdlet.ShouldProcess("$($nextBatch.Count) objects", "Delete from Azure AD"))
            {
                $results = $exporter.ExportDeletions([Microsoft.Azure.ActiveDirectory.Connector.Diagnostics.DeletionEntry[]]$nextBatch)
                Write-Output $results | FT ResultCode, ResultErrorDescription, ObjectType, SourceAnchor
            }
            else
            {
                Write-Output "SKIPPED: Operation canceled. `n`n"
            }
            $objsProcessed += $nextBatch.Count
        }
    }
    Catch
    {
        Throw "There was a problem processing the batch. Error Details: $($_.Exception.Message)"
    }
    #END 
    $exporter.Dispose()
}


<#
.Synopsis
   Get Azure AD Connnect Run History
.DESCRIPTION
   Function that returns the AAD Connnect Run History in XML format
.EXAMPLE
   Get-ADSyncToolsRunHistory 
.EXAMPLE
   Get-ADSyncToolsRunHistory -Days 3
#>
Function Get-ADSyncToolsRunHistory 
{
    Param
    (
        [int]
        [Parameter(Mandatory=$false)]
        $Days = 1
    )
    $errorStr = "Azure AD Connect Powershell cmdlet 'Get-ADSyncRunProfileResult'"
    $cmdlets = @(Get-Command Get-ADSyncRunProfileResult -Module ADSync)
    if ($cmdlets.Count -gt  0)
    {
        # Read Run Profile
        Try  
        {
            If ($Days -eq 0)
            {
                $runProfile = Get-ADSyncRunProfileResult
            }
            Else
            {
                $startDate = (Get-Date).AddDays(-$Days).ToUniversalTime()
                $runProfile = Get-ADSyncRunProfileResult | where {$_.StartDate -gt $startDate}
            }
        }
        Catch  
        {
            Throw "There was a problem calling $($errorStr): $($_.Exception.Message)"
        }
    }
    Else
    {
        Throw "This function requires $errorStr. Please update Azure AD Connect to use this function."
    }

    $runProfile | select ConnectorName, RunProfileName, Result, StartDate, EndDate, CurrentStepNumber, RunStepResults, RunHistoryId
}


<#
.Synopsis
   Export Azure AD Connnect Run History
.DESCRIPTION
   Function to export Azure AD Connect Run Profile and Run Step results to CSV and XML format respectively.
   The resulting Run Profile CSV file can be imported into a spreadsheet and the Run Step XML file can be imported with Import-Clixml
.EXAMPLE
   Export-ADSyncToolsRunHistory -TargetName MyADSyncHistory
#>
Function Export-ADSyncToolsRunHistory 
{
    Param
    (
        # Name of the output file
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [String] $TargetName
    )
    $errorStr = "Azure AD Connect Powershell cmdlets 'Get-ADSyncRunProfileResult' and 'Get-ADSyncRunStepResult'"
    $cmdlets = @(Get-Command Get-AdSyncRun*Result -Module ADSync)
    if ($cmdlets.Count -gt  1)
    {
        # Read Run Profile and Run Step results
        Try  
        {
            $runProfile = Get-ADSyncRunProfileResult
            $runSteps = Get-ADSyncRunStepResult
        }
        Catch  
        {
            Throw "There was a problem calling $($errorStr): $($_.Exception.Message)"
        }

        # Export Run Profile results
        Try  
        {
            $runProfile | 
                Where-Object {$_.IsRunComplete -eq 'True'} | 
                    select ConnectorName, RunProfileName, Result, StartDate, EndDate, CurrentStepNumber, RunStepResults, RunHistoryId | 
                        Export-Csv ".\$TargetName-RunProfile.csv" -NoTypeInformation
        }
        Catch  
        {
            Throw "There was a problem exporting Run Profile results: $($_.Exception.Message)"
        }

        # Export Run Step results
        Try  
        {
            $runSteps | 
                Export-Clixml ".\$TargetName-RunStep.xml"
        }
        Catch  
        {
            Throw "There was a problem exporting Run Step results: $($_.Exception.Message)"
        }
    }
    Else
    {
        Throw "This function requires $errorStr. Please update Azure AD Connect to use this function."
    }
}


<#
.Synopsis
   Import Azure AD Connnect Run History
.DESCRIPTION
   Function to Import Azure AD Connect Run Step results from XML created using Export-ADSyncToolsRunHistory
.EXAMPLE
   Export-ADSyncToolsRunHistory -Path .\RunHistory-RunStep.xml
#>
Function Import-ADSyncToolsRunHistory 
{
    [CmdletBinding()]
    Param
    (
        # Path for the XML file to import
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $Path
    )

    If (Test-Path $Path)
    {
        Try
        {
            Import-Clixml $Path
        }
        Catch
        {
            Write-Error "Unable to import file '$Path'. Error Details: $($_.Exception.Message)"
        }
    }
    Else
    {
        Write-Error "File not found."
    }
}


<#
.Synopsis
   Get AAD Connnect Run History for older versions of AADConnect (WMI)
.DESCRIPTION
   Function that returns the AAD Connnect Run History in XML format
.EXAMPLE
   Get-ADSyncToolsRunHistory 
.EXAMPLE
   Get-ADSyncToolsRunHistory -Days 3
#>
Function Get-ADSyncToolsRunHistoryLegacyWmi
{
    Param
    (
        [int]
        [Parameter(Mandatory=$false)]
        $Days = 1
    )
     
    $runStartDate=(Get-Date (Get-Date).AddDays(-$Days) -Format yyyy-MM-dd) 
    $getRunStartTime="RunStartTime >'"+$runStartDate+"'"
    $namespace = 'root\MicrosoftIdentityintegrationServer'

    Try  
    {
        $miis_RunHistory = Get-WmiObject -class "MIIS_RunHistory" -namespace $namespace -Filter $getRunStartTime -ErrorAction Stop
    }
    Catch  
    {
        $errorMsg = "There was a problem calling WMI Namespace '$namespace': $($_.Exception.Message)"
        Write-Error $errorMsg
        return @($errorMsg)
    }

    If ($miis_RunHistory -ne $null)   
    { 
        $xmlData = @()
    
        ForEach ($entry in $miis_RunHistory)   
        { 
            $xmlData += $entry.RunDetails()
        }
        Return $xmlData 
    }
}


<#
.Synopsis
   Script to Remove Expired Certificates from UserCertificate Attribute
.DESCRIPTION
    This script takes all the objects from a target Organizational Unit in your Active Directory domain - filtered by Object Class (User/Computer) 
    and deletes all expired certificates present in the UserCertificate attribute.
    By default (BackupOnly mode) it will only backup expired certificates to a file and not do any changes in AD.
    If you use -BackupOnly $false then any Expired Certificate present in UserCertificate attribute for these objects will be removed from AD after being copied to file.
    Each certificate will be backed up to a separated filename: ObjectClass_ObjectGUID_CertThumprint.cer
    The script will also create a log file in CSV format showing all the users with certificates that either are valid or expired including the actual action taken (Skipped/Exported/Deleted).
.EXAMPLE
   Check all users in target OU - Expired Certificates will be copied to separated files and no certificates will be removed
   Remove-ADSyncToolsExpiredCertificates -TargetOU "OU=Users,OU=Corp,DC=Contoso,DC=com" -ObjectClass user 
.EXAMPLE
   Delete Expired Certs from all Computer objects in target OU - Expired Certificates will be copied to files and removed from AD
   Remove-ADSyncToolsExpiredCertificates -TargetOU "OU=Computers,OU=Corp,DC=Contoso,DC=com" -ObjectClass computer -BackupOnly $false
#>
Function Remove-ADSyncToolsExpiredCertificates
{
    [CmdletBinding()]
    Param
    ( 
        # Target OU to lookup for AD objects
        [Parameter(Mandatory=$True)]
        [string]$TargetOU,

        # BackupOnly will not delete any certificates from AD
        [Bool]$BackupOnly = $True,

        # Object Class filter
        [Parameter(Mandatory=$True)]
        [ValidateSet('user','computer')] 
        [String] 
        $ObjectClass
    )

    $today = Get-Date

    # Query AD object class = $ObjectClass that contain UserCerts in OU = $TargetOU
    $ldapFilter = [string] "(objectClass=$ObjectClass)"
    $adObjectsInOU = @(Get-ADObject -LDAPFilter $ldapFilter -SearchBase $TargetOU -Properties userCertificate | where {$_.userCertificate -ne $null})
    Write-Output "Processing $($adObjectsInOU.Count) AD objects with UserCertificate..."

    # Backup removed certificates to a file
    [bool] $BackupCertificates = $True

    # For each user and each cert check validity, backup to a file (if $BackupCertificates = $True) and remove cert it if Expired
    $resultsTable = @()
    foreach ($adObject in $adObjectsInOU)  {
    
        $objCerts = @($adObject.UserCertificate)

        Write-Output "Checking AD Object: $($adObject.Name) | Total Certs: $($objCerts.Count)"
        $certIndex = 0 

        foreach ($cert in $objCerts) {
            $row = "" | select ADobjectDN,CertificateIndex,CertificateName,CertificateTemplate,CertificateIssuingDate,CertificateExpireDate,CertificateStatus,Export-Action-Reason
            $certObj = [System.Security.Cryptography.X509Certificates.X509Certificate2] $cert
        
            $certName = $certObj.GetName()
            $certTemplate = $certObj.Extensions| foreach {
                $_.Format($false) |  Select-String "Template="
            }
            Write-Debug $certObj
            $templateName = @($($certTemplate -split ','))[0]
            if ($templateName -eq $null)  {
                $templateName = "N/A"
            }

    
            if ($certObj.NotAfter -lt $($today))  {
                $certStatus = "Expired"
                $deleteCert = $true

                if ($BackupCertificates)  {

                    $filename = [string] ".\$($ObjectClass)_$($adObject.ObjectGUID)_$($certObj.Thumbprint).cer"
                    Try {
                        $exportResult = Export-Certificate -Cert $certObj -FilePath $filename
                        $row.'Export-Action-Reason' = "Exported"
                        Write-Output "Expired Certificate exported to file: $($exportResult.Name)"
                    }
                    Catch {
                        $row.'Export-Action-Reason' = "ExportFailed-NotRemoved-Error"
                        $deleteCert = $false
                    }
                }
            }
            else {
                $certStatus = "Valid"
                $deleteCert = $false
                $row.'Export-Action-Reason' += "Skipped-NotRemoved-ValidCert)"
            }
        
            if ($deleteCert)  {
                Try  {
                    if (!$BackupOnly) {
                
                        Set-ADObject -Identity $adObject.DistinguishedName -Remove @{UserCertificate=$certObj}
                        $row.'Export-Action-Reason' += "-Removed-Expired"
                    }
                    else  {
                        $row.'Export-Action-Reason' += "-ToBeRemoved-BackupOnly"
                    }
                }
                Catch {
                    $row.'Export-Action-Reason' += "-NotRemoved-Error"
                }
            }

            $row.ADobjectDN =             [string] $adObject.DistinguishedName.ToString()
            $row.CertificateIndex =       [string] $certIndex.ToString()
            $row.CertificateName =        [string] $certObj.GetName()
            $row.CertificateTemplate =    [string] $templateName.ToString()
            $row.CertificateIssuingDate = [string] $certObj.NotBefore.ToString()
            $row.CertificateExpireDate =  [string] $certObj.NotAfter.ToString()
            $row.CertificateStatus =      [string] $certStatus.ToString()
        
            Write-Verbose $row
            $resultsTable += $row | Select *
            $certIndex++
        } 
    }

    # Export results to a file
    $date = [string] $(Get-Date -Format yyyyMMddHHmmss)
    $filename = [string] ".\ExpiredCertsResults-$date.txt"
    $resultsTable | Export-Csv -Path $filename -Delimiter "`t" -NoTypeInformation

}


<#
.Synopsis
   Creates a trace file from and AD Import Step
.DESCRIPTION
   Traces all ldap queries of an AAD Connect AD Import run from a given AD watermark checkpoint (aka. partition cookie). 
   Creates a trace file '.\ADimportTrace_yyyyMMddHHmmss.log' on the current folder.
   To use -ADConnectorXML, go to the Synchronization Service Manager, right-click your AD Connector and select "Export Connector..."
.EXAMPLE
   Trace AD Import for user objects by providing an AD Connector XML file
   Trace-ADSyncToolsADImport -DC 'DC1.contoso.com' -RootDN 'DC=Contoso,DC=com' -Filter '(&(objectClass=user))' -ADConnectorXML .\ADConnector.xml 
.EXAMPLE
   Trace AD Import for all objects by providing the AD watermark (cookie) and AD credentials
   $creds = Get-Credential
   Trace-ADSyncToolsADImport -DC 'DC1.contoso.com' -RootDN 'DC=Contoso,DC=com' -Credentials $creds -ADwatermark "TVNEUwMAAAAXyK9ir1zSAQAAAAAAAAAA(...)"
#>
Function Trace-ADSyncToolsADImport
{
    [CmdletBinding()]
    Param
    (
        # Target Domain Controller
        [Parameter( Mandatory=$True, 
                    Position=0)]
        [string] $DC,

        # Forest Root DN
        [Parameter( Mandatory=$True, 
                    Position=1)]
        [string] $RootDN,

        # AD objects type to trace. Use '(&(objectClass=*))' for all object types
        [Parameter( Mandatory=$False, 
                    Position=2)]
        [string] $Filter = '(&(objectClass=*))',

        # Provide the credentials to run LDAP query against AD
        [Parameter( Mandatory=$false, 
                    Position=3)]
        [PSCredential] $Credentials,

        # SSL Connection
        [Parameter( Mandatory=$false, 
                    Position=4)]
        [switch] $SSL = $false,

        # AD Connector Export XML file - Right-click AD Connector and select "Export Connector..."
        [Parameter( Mandatory=$True, 
                    Position=5,
                    ParameterSetName = "ADConnectorXML")]
        [string] $ADConnectorXML,
        
        # Manual input of watermark, instead of XML file e.g. $ADwatermark = "TVNEUwMAAAAXyK9ir1zSAQAAAAAAAAAA(...)" 
        [Parameter( Mandatory=$True, 
                    Position=5,
                    ParameterSetName = "ADwatermarkInput")]
        [string] $ADwatermark
    )

    # Read AD watermark value
    If ($ADwatermark -eq "" -or $ADwatermark -eq $null)  
    {
        # Read AD Connector XMl file
        If ($ADConnectorXML -notlike "" -and (Test-Path $ADConnectorXML))  
        {
            # Parse the Cookie (AD watermark) from the XML data
            Try  
            {
                $adcsXMLdata = [xml] (Get-Content $ADConnectorXML)
                $maPartitionDataList = @($adcsXMLdata.'saved-ma-configuration'.'ma-data'.'ma-partition-data'.partition)
                $maPartitionData = $maPartitionDataList | Where-Object {$_.Name -like $RootDN}
                $ADwatermark = $maPartitionData.'custom-data'.'adma-partition-data'.cookie
                Write-Verbose "AD watermark from AD Connector XML file '$ADConnectorXML': `n$ADwatermark `n"
            }
            Catch  
            {
                Throw "Error reading AD Connector XML export file: $($_.Exception.Message)"
            }
        }
        Else    
        {
            Throw "Please provide a valid AD Connector XML export file."
        }
    }


    # Parse AD watermark value
    Write-Host "`Parsing AD watermark for '$RootDN' partition: `n$ADwatermark `n"    
    Try
    {
        [byte[]] $dirSyncCookie = [System.Convert]::FromBase64String($ADwatermark)
    }
    Catch
    {
        Throw "Error parsing AD watermark: $($_.Exception.Message)"
    }
    
    # Importing from AD
    Write-Host "`nImporting from AD ..."
    Try
    {
        [void] ([System.Reflection.Assembly]::LoadWithPartialName('System.DirectoryServices.Protocols'))
    }
    Catch
    {
        Throw "Error loading assemblies: $($_.Exception.Message)"
    }

    
    If (($SSL) -and ($DC -notlike '*:636')) 
    { 
        $DC = '{0}:636' -f $DC 
    }

    If ($Credentials -eq $null)
    {
        Write-Verbose "Credentials not passed in - Using security context of the current logged-on user."
        # Use Current Logged on User credentials
        [DirectoryServices.Protocols.LdapConnection] $ldapConn = New-Object DirectoryServices.Protocols.LdapConnection($DC)
    }
    Else  
    {
        # Use provided Credentials
        Write-Verbose "Credentials passed in - Using provided credentials"
        Try
        {
            [DirectoryServices.Protocols.LdapConnection] $ldapConn = New-Object DirectoryServices.Protocols.LdapConnection($DC, $Credentials.GetNetworkCredential())    
        }
        Catch
        {
            Throw "LDAP connection failure: $($_.Exception.Message)"
        }
    }

    # Generate AD Import trace file
    $d = "`t" # Delimiter
    $logfilename = [string] ".\ADimportTrace_$(Get-Date -Format yyyyMMddHHmmss).log"
    $header = [string] "Timestamp" + $d + "ldapResult" + $d + "ldapCount" + $d + "AttributeCount" + $d + "DistinguishedName" + $d + "Attributes(ValuesCount)"
    Out-File -FilePath $logfilename -InputObject $header

    # Setup LDAP request
    If (-not $SSL) 
    {
        $ldapConn.SessionOptions.Sealing = $true
    } 
    Else 
    {
        $ldapConn.SessionOptions.SecureSocketLayer = $true
    }

    [string[]] $attributesToFetch = $null
    $ldapConn.AuthType = [DirectoryServices.Protocols.AuthType]::Kerberos
    [DirectoryServices.Protocols.SearchRequest] $ldapRequest = New-Object DirectoryServices.Protocols.SearchRequest($RootDN, $Filter, 'SubTree', $attributesToFetch)
    [DirectoryServices.Protocols.DirSyncRequestControl] $dirSyncCtr = New-Object DirectoryServices.Protocols.DirSyncRequestControl($dirSyncCookie, [DirectoryServices.Protocols.DirectorySynchronizationOptions]::None, [Int32]::MaxValue)
    [void] $ldapRequest.Controls.Add($dirSyncCtr)
    [bool] $hasMore = $false

    # Process LDAP Request/Response
    Do 
    {
        [DirectoryServices.Protocols.SearchResponse] $ldapResponse = $null
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Try  
        {
            $ldapResponse = $ldapConn.SendRequest($ldapRequest)
        }
        Catch    
        {
            Throw "Problem sending LDAP request. Try without SSL or by providing the Cookie value from the XML file with -ADwatermark: $($_.Exception.Message)"
        }

        # Show/ Log LDAP Response
        Write-Host ('Search response code: {0}, Result Count {1}' -f $ldapResponse.ResultCode, $ldapResponse.Entries.Count)
        $logldapResponse = [string] $timestamp + $d + $($ldapResponse.ResultCode) + $d + $($ldapResponse.Entries.Count)
    
        ForEach ($entry in $ldapResponse.Entries)  
        {
            # Show/ Log Entry from LDAP Response
            Write-Host ('Entry: {0} | Attribute Count = {1}' -f $entry.DistinguishedName, $entry.Attributes.Count)
            $logdata = [string] $logldapResponse + $d + $($entry.Attributes.Count) + $d + $($entry.DistinguishedName)
            $attributeData = ""
        
            foreach ($attributeName in $entry.Attributes.AttributeNames)
            {
                $attributeData += $attributeName + "(" + $($entry.Attributes[$attributeName].Count) + ")" + ","
                Write-Host ("Attribute {0}, ValueCount {1}" -f $attributeName, $entry.Attributes[$attributeName].Count)
            }
            Write-Host
            $logdata += $d + $attributeData.Substring(0, $attributeData.Length -1)
            Out-File -FilePath $logfilename -InputObject $logdata -Append
        }

        $hasMore = $false
        If (-not ([object]::Equals($ldapResponse, $null))) 
        {
            ForEach ($oneLdapResponseControl in $ldapResponse.Controls) 
            {
                If ($oneLdapResponseControl -is [DirectoryServices.Protocols.DirSyncResponseControl]) 
                {
                    [DirectoryServices.Protocols.DirSyncResponseControl] $dirSyncCtrResponse = [DirectoryServices.Protocols.DirSyncResponseControl] $oneLdapResponseControl
                    $dirSyncCtr.Cookie = $dirSyncCtrResponse.Cookie
                    $hasMore = $dirSyncCtrResponse.MoreData
                    Break
                }
            }
        }
    }
    While ($hasMore)
}



<#
.Synopsis
   Trace LDAP queries
.EXAMPLE
   Trace-ADSyncToolsLdapQuery -RootDN "DC=Contoso,DC=com" -Credentials $Credentials
#>
Function Trace-ADSyncToolsLdapQuery
{
    [CmdletBinding()]
    Param
    (
        # Forest/Domain DistinguishedName
        [Parameter(Mandatory=$true,
                   Position=0,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [String] $RootDN,

        # AD Credentials
        [Parameter(Mandatory=$true,
                   Position=1,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [pscredential] $Credentials,

        # Domain Controller Name (optional)
        [Parameter(Mandatory=$false,
                   Position=2,
                   ValueFromPipelineByPropertyName=$true)]
        [String] $Server,

        # Domain Controller port (default: 389)
        [Parameter(Mandatory=$false,
                   Position=2,
                   ValueFromPipelineByPropertyName=$true)]
        [Int] $Port = 389,

        # LDAP filter (default: objectClass=*)
        [Parameter(Mandatory=$false)]
        [String]
        $Filter = "(objectClass=*)"
    )

    [Reflection.Assembly]::LoadWithPartialName("System.Directoryservices.Protocols")
    [Reflection.Assembly]::LoadWithPartialName("System.Directoryservices")

    $ldapDirectoryId = New-Object System.DirectoryServices.Protocols.LdapDirectoryIdentifier($Server, $Port)
    $ldapConnection = New-Object System.DirectoryServices.Protocols.LdapConnection($ldapDirectoryId, $Credentials.GetNetworkCredential())

    $rootDSEReq = New-Object System.DirectoryServices.Protocols.SearchRequest
    $rootDSEReq.DistinguishedName = $RootDN
    $rootDSEReq.Filter = $Filter
    $rootDSEReq.Scope = [System.DirectoryServices.Protocols.SearchScope]("Base")
    $rootDSEReq.SizeLimit = 1
    $rootDSEReq.TimeLimit = [System.Timespan]::FromMinutes(2)
    $rootDSEReq.Attributes.Add("SubschemaSubentry") | Out-Null

    $searchResponse = [System.DirectoryServices.Protocols.SearchResponse]$ldapConnection.SendRequest($rootDSEReq)

    $subentryDN = $searchResponse.Entries[0].Attributes["SubschemaSubentry"][0]
    Write-Host "Sub entry DN '$subentryDN' from '$($($searchResponse.Entries[0]).DistinguishedName)'" -ForegroundColor Cyan

    $seReq = New-Object System.DirectoryServices.Protocols.SearchRequest
    $seReq.DistinguishedName = $subentryDN
    $seReq.Filter = $Filter
    $seReq.Scope = [System.DirectoryServices.Protocols.SearchScope]("Base")
    $seReq.SizeLimit = 1
    $seReq.TimeLimit = [System.Timespan]::FromMinutes(2)
    $seReq.Attributes.Add("extendedAttributeInfo") | Out-Null
    $seReq.Attributes.Add("attributeTypes") | Out-Null
    $seReq.Attributes.Add("objectClasses") | Out-Null
    $seReq.Attributes.Add("dITContentRules") | Out-Null

    $searchResponse = [System.DirectoryServices.Protocols.SearchResponse]$ldapConnection.SendRequest($seReq)

    $logfilenamePrefix = [string] ".\LdapTrace_$(Get-Date -Format yyyyMMddHHmmss)"

    Write-Host "Exporting data to '$logfilenamePrefix*' files..." -ForegroundColor Cyan

    $logfilename = $logfilenamePrefix + "-extendedAttributeInfo.txt"
    for ($i = 0; $i -lt $searchResponse.Entries[0].Attributes["extendedAttributeInfo"].Count; $i++)
    {
      Add-Content -Path $logfilename -Value $searchResponse.Entries[0].Attributes["extendedAttributeInfo"][$i]
    }

    $logfilename = $logfilenamePrefix + "-attributeTypes.txt"
    for ($i = 0; $i -lt $searchResponse.Entries[0].Attributes["attributeTypes"].Count; $i++)
    {
      Add-Content -Path $logfilename -Value $searchResponse.Entries[0].Attributes["attributeTypes"][$i]
    }

    $logfilename = $logfilenamePrefix + "-objectClasses.txt"
    for ($i = 0; $i -lt $searchResponse.Entries[0].Attributes["objectClasses"].Count; $i++)
    {
      Add-Content -Path $logfilename -Value $searchResponse.Entries[0].Attributes["objectClasses"][$i]
    }

    $logfilename = $logfilenamePrefix + "-dITContentRules.txt"
    for ($i = 0; $i -lt $searchResponse.Entries[0].Attributes["dITContentRules"].Count; $i++)
    {
      Add-Content -Path $logfilename -Value $searchResponse.Entries[0].Attributes["dITContentRules"][$i]
    }
}


#endregion
#=======================================================================================


#=======================================================================================
#region Migration / Disaster Recovery Functions
#=======================================================================================

<#
.Synopsis
   Import ImmutableID from AAD
.DESCRIPTION
   Generates a file with all Azure AD Synchronized users containing the ImmutableID value in GUID format
   Requirements: MSOnline PowerShell Module
.EXAMPLE
   Import-ADSyncToolsSourceAnchor -OutputFile '.\AllSyncUsers.csv'
.EXAMPLE
   Another example of how to use this cmdlet
#>
Function Import-ADSyncToolsSourceAnchor
{
    [CmdletBinding()]
    Param
    (
        # Output CSV file 
        [Parameter(Mandatory=$true)]
        [String] $Output,

        # Get Synchronized Users from Azure AD Recycle Bin
        [Parameter(Mandatory=$false)]
        [switch] $IncludeSyncUsersFromRecycleBin = $false        
    )
    Try
    {
        $creds = Get-Credential
        # TODO : Support for AAD PowerShell v2
        # TODO : Function to connect - Control connected state
		$tenantAzureEnvironment = Get-ADSyncToolsTenantAzureEnvironment $creds
        Connect-MsolService -Credential $creds -AzureEnvironment $tenantAzureEnvironment

    }
    Catch
    {
        Throw "Unable to Connect to Azure AD: $($_.Exception.Message)"
    }

    # Start Importing 
    $results = @()
    $allSyncUsers = @()
    $userProperties = @('UserPrincipalName', 'ImmutableID', 'ObjectId', 'LastDirSyncTime', 'IsLicensed', 'SoftDeletionTimestamp')

    Write-Host "Reading Synchronized Users from Azure AD ..."
    $allSyncUsers = Get-MsolUser -Synchronized -All | Where-Object {$_.ImmutableID -ne $null} | select $userProperties

    If ($IncludeSyncUsersFromRecycleBin)
    {
        $allSyncUsers += Get-MsolUser -Synchronized -All -ReturnDeletedUsers | Where-Object {$_.ImmutableID -ne $null} | select $userProperties
    }

    # Start Processing
    #Write-Host "Found $($allSyncUsers.Count) Synchronized Users in Azure AD ..."

    Foreach ($user in $allSyncUsers) 
    {
        # Convert ImmutableID to GUID for each user
        Try
        {
            $immutableIdGuid = [GUID] ([System.Convert]::FromBase64String($user.ImmutableID))
        }
        Catch
        {
            # Failure to convert to GUID value - Skip to the next loop
            Write-Error "Failure to convert ImmutableID to a GUID string: $($_.Exception.Message)"
            Continue 

        }
        
        # Instantiate custom Object with all the properties in $userProperties
        $aadUser = New-Object -TypeName PSObject
        $aadUser | Add-Member -MemberType NoteProperty -Name UserPrincipalName -Value $($user.UserPrincipalName)
        $aadUser | Add-Member -MemberType NoteProperty -Name ImmutableID -Value $($user.ImmutableID)
        $aadUser | Add-Member -MemberType NoteProperty -Name ImmutableIdGuid -Value $immutableIdGuid
        $aadUser | Add-Member -MemberType NoteProperty -Name LastDirSyncTime -Value $($user.LastDirSyncTime)
        $aadUser | Add-Member -MemberType NoteProperty -Name IsLicensed -Value $($user.IsLicensed)
        $aadUser | Add-Member -MemberType NoteProperty -Name SoftDeletionTimestamp -Value $($user.SoftDeletionTimestamp)
        $aadUser | Select UserPrincipalName, ImmutableID, ImmutableIdGuid
        $results += $aadUser
    }

    # Exporting data
    Write-Host "`n`nExporting $($results.count) Synchronized Users in Azure AD ..."
    $results | Export-Csv "$Output.csv" -NoTypeInformation
}


<#
.Synopsis
   Export ms-ds-Consistency-Guid Report
.DESCRIPTION
   Generates a ms-ds-Consistency-Guid report based on an import CSV file from Import-ADSyncToolsSourceAnchor
.EXAMPLE
   Import-Csv .\AllSyncUsers.csv | Export-ADSyncToolsSourceAnchorReport -Output ".\AllSyncUsers-Report"
.EXAMPLE
   Another example of how to use this cmdlet
#>
Function Export-ADSyncToolsSourceAnchorReport
{
    [CmdletBinding()]
    Param
    (
        # Use Alternative Login ID (mail)
        [Parameter(Mandatory=$false)]
        [switch] $AlternativeLoginId = $false,
        
        # UserPrincipalName
        [Parameter(Mandatory=$true,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [String] $UserPrincipalName,

        # ImmutableIdGUID
        [Parameter(Mandatory=$true,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [String] $ImmutableIdGUID,

        # Output filename for CSV and LOG files
        [Parameter(Mandatory=$true)]
        [String] $Output
    )

    Begin
    {
        If (-not (Import-ADSyncToolsActiveDirectoryModule))
        {
            Return $false
        }
    
        # Check/Remove output files
        $currentFolder = (Get-Location).Path
        
        Remove-Item "$currentFolder\$Output.csv" -ErrorAction SilentlyContinue -Confirm
        If (Test-Path "$currentFolder\$Output.csv")
        {
            Write-Error "File $currentFolder\$Output.csv already exists. Exiting."
            Exit
        }
        Remove-Item "$currentFolder\$Output.log" -ErrorAction SilentlyContinue -Confirm

        # Set the signInAttribute
        If ($AlternativeLoginId)
        {
            $signInAttribute = 'mail'
        }
        Else
        {
            $signInAttribute = 'UserPrincipalName'
        }

        $usersFound = $usersNotFound = 0
        $defaultProperties = @('UserPrincipalName','ObjectGUID','mS-DS-ConsistencyGuid','distinguishedName')
    }
    Process
    {
        #$objectResult = $msgResult = $seachResult = $null
        $logMessage = "AD user with $UserPrincipalName in $signInAttribute" + "`t" + "ImmutableId: $ImmutableIdGUID"
        $seachResult = $null

        # Initiate custom object
        $objectResult = New-Object �TypeName PSObject
        $objectResult | Add-Member �MemberType NoteProperty �Name UserPrincipalName �Value $UserPrincipalName
        $objectResult | Add-Member �MemberType NoteProperty �Name ImmutableIdGUID �Value $ImmutableIdGUID
        $objectResult | Add-Member �MemberType NoteProperty �Name OnPremisesUPN �Value $null
        $objectResult | Add-Member �MemberType NoteProperty �Name ObjectGUID �Value $null
        $objectResult | Add-Member �MemberType NoteProperty �Name ConsistencyGuid �Value $null
        $objectResult | Add-Member �MemberType NoteProperty �Name SearchResult �Value $null
        $objectResult | Add-Member �MemberType NoteProperty �Name Action �Value $null
        $objectResult | Add-Member �MemberType NoteProperty �Name Description �Value $null
        $objectResult | Add-Member �MemberType NoteProperty �Name DistinguishedName �Value $null

        Write-Verbose "UserPrincipalName : $UserPrincipalName | ImmutableIdGUID : $ImmutableIdGUID"

        # Search for User in AD
        Try
        {
            $user = Get-ADObject -Filter '$signInAttribute -eq $UserPrincipalName' -Properties $defaultProperties  -ErrorAction Stop
        }
        Catch
        {
            Write-Error "Unable to search in ActiveDirectory: $($_.Exception.Message)"
            return
        }

        # User not found searching for the UserPrincipalName
        If ($user -eq $null)
        {
            $seachResult = "UserPrincipalName does not exist in AD"
            $objectResult.OnPremisesUPN = "N/A"
            $objectResult.ObjectGUID = "N/A"
            $objectResult.ConsistencyGuid = "N/A"
            $objectResult.SearchResult = $seachResult
            $objectResult.Action = "Skip"
            $objectResult.Description = "AD User cannot be found"
            $objectResult.DistinguishedName = "N/A"
            $usersNotFound ++

            # Try to search for the UPN prefix in sAMAccountName, if not using Alternative LoginId
            If (-not $AlternativeLoginId)
            {
                # Get the UPN prefix
                Try
                {
                    $upnPrefix = $UserPrincipalName.Substring(0, $UserPrincipalName.IndexOf('@'))
                }
                Catch
                {
                    Write-Error "Invalid UserPrincipalName format: $($_.Exception.Message)"
                }

                # Search for UPN prefix on AD sAMAccountName 
                If ($upnPrefix -notlike "")
                {
                    Try
                    {   
                        $user = Get-ADObject -Filter 'sAMAccountName -eq $upnPrefix' -Properties $defaultProperties -ErrorAction Stop
                    }
                    Catch
                    {
                        Write-Error "Unable to search in ActiveDirectory: $($_.Exception.Message)"
                        return
                    }
                    
                    # User Found in AD based on the UPN prefix equal to AD sAMAccountName
                    If ($user -ne $null)
                    {
                        $seachResult = "UserPrincipalName prefix present in AD sAMAccountName"
                        $objectResult.OnPremisesUPN = $user.UserPrincipalName
                        $objectResult.ObjectGUID = $user.ObjectGUID
                        $objectResult.ConsistencyGuid = Get-ADSyncToolsMsDsConsistencyGuid($user)
                        $objectResult.SearchResult = $seachResult
                        $objectResult.Action = ""
                        $objectResult.Description = ""
                        $objectResult.DistinguishedName = $user.distinguishedName
                        $usersFound ++
                        $usersNotFound --
                    }
                }
            }
            $logMessage += "`t" + "Result: $seachResult"
        }
        Else
        {
            # User Found in AD
            $seachResult = "UserPrincipalName is present in AD"
            $objectResult.OnPremisesUPN = $user.UserPrincipalName
            $objectResult.ObjectGUID = $user.ObjectGUID
            $objectResult.ConsistencyGuid = Get-ADSyncToolsMsDsConsistencyGuid($user)
            $objectResult.SearchResult = $seachResult
            $objectResult.DistinguishedName = $user.distinguishedName
            $logMessage += "`t" + "Result: $seachResult"
            $usersFound ++
            $userFound = $true
        }

        # Calculate Action + Action Result
        If ($user -ne $null)
        {
            If ($objectResult.ConsistencyGuid -eq $null)
            {
                # Target AD User does not have a ConsistencyGuid value yet
                $objectResult.Action = "Add"
                $objectResult.Description = "AD User does not have 'mS-DS-ConsistencyGuid' value"

            }
            Else
            {
                # Compare AAD ImmutableId with AD 'mS-DS-ConsistencyGuid' values
                $AdObject = $objectResult | Select ImmutableIdGUID, ConsistencyGuid
                $sourceConsistencyGuid = [GUID] $AdObject.ImmutableIdGUID
                $targetConsistencyGuid = [GUID] $AdObject.ConsistencyGuid
                Write-Verbose "sourceConsistencyGuid : $sourceConsistencyGuid | targetConsistencyGuid : $targetConsistencyGuid"

                If ($sourceConsistencyGuid -eq $targetConsistencyGuid)
                {
                    $objectResult.Action = "Skip"
                    $objectResult.Description = "AD User already have the correct 'mS-DS-ConsistencyGuid'"
                }
                Else
                {
                    $objectResult.Action = "Update"
                    $objectResult.Description = "AD User requires an update of 'mS-DS-ConsistencyGuid'"
                }
            }
        }

        #$objectResult | Select UserPrincipalName, ImmutableIdGUID, ConsistencyGuid, SearchResult, Action, Description
        $objectResult | Select UserPrincipalName, SearchResult, Action, Description
        $objectResult | Export-Csv "$currentFolder\$Output.csv" -NoTypeInformation -Append -Delimiter "`t"
        $logMessage + "`n" | Out-File "$currentFolder\$Output.log" -Append
    }
    End
    {
        Write-Host "`n`nProcessed a total of $($usersFound + $usersNotFound) users | $usersFound Users found + $usersNotFound Users not found"
        Write-Host "Report file: $currentFolder\$Output.csv"
        Write-Host "Log file: $currentFolder\$Output.log"
    }
}


<#
.Synopsis
   Updates users with the new ConsistencyGuid (ImmutableId)
.DESCRIPTION
   Updates users with the new ConsistencyGuid (ImmutableId) value taken from the ConsistencyGuid Report 
   This function supports the WhatIf switch
   Note: ConsistencyGuid Report must be imported with Tab Demiliter
.EXAMPLE
   Import-Csv .\AllSyncUsersTEST-Report.csv -Delimiter "`t"| Update-ADSyncToolsSourceAnchor -Output .\AllSyncUsersTEST-Result2 -WhatIf
.EXAMPLE
   Import-Csv .\AllSyncUsersTEST-Report.csv -Delimiter "`t"| Update-ADSyncToolsSourceAnchor -Output .\AllSyncUsersTEST-Result2
#>
Function Update-ADSyncToolsSourceAnchor
{
    [CmdletBinding(SupportsShouldProcess)]
    Param
    (
        # DistinguishedName
        [Parameter(Mandatory=$false,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [String] $DistinguishedName = $false,

        # ImmutableIdGUID
        [Parameter(Mandatory=$true,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [String] $ImmutableIdGUID,
        
        # Action
        [Parameter(Mandatory=$true,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [String] $Action,

        # Output filename for LOG files
        [Parameter(Mandatory=$true)]
        [String] $Output
    )

    Begin
    {
        If(-not (Import-ADSyncToolsActiveDirectoryModule))
        {
            Return $false
        }
        
        # Check/Remove output files
        $currentFolder = (Get-Location).Path
        
        Remove-Item "$currentFolder\$Output.log" -ErrorAction SilentlyContinue -Confirm
        Write-Verbose "WhatIfPreference: $WhatIfPreference"
    }
    Process
    {
        # Process each user with Add or Update action
        Write-Verbose "$Action | Value:$ImmutableIdGUID | User:$DistinguishedName"
        If ($Action -eq 'Add' -or $Action -eq 'Update')
        {
            $logMessage = "$Action | Value:$ImmutableIdGUID | User:$DistinguishedName"
            Write-Host $logMessage

            $adObject = Search-ADSyncToolsADobject -User $DistinguishedName

            If ($adObject)
            {
                Try
                {
                    if ($PSCmdlet.ShouldProcess($adObject, $Action))
                    {
                        $newValue = [GUID] $ImmutableIdGUID
                        Set-ADObject -Identity $adObject -Replace @{'mS-DS-ConsistencyGuid'=$newValue}
                        $logMessage += " | Result: Success"
                        $usersUpdated ++
                    }
                    
                }
                Catch
                {
                    # Could not set user
                    Write-Error "Unable to set user $adObject in Active Directory: $($_.Exception.Message)"
                    $logMessage += " | Result: Failed"
                    $usersFailed ++
                }
            }

            $logMessage + "`n" | Out-File "$currentFolder\$Output.log" -Append
        }
    }
    End
    {
        Write-Host "`n`nProcessed a total of $($usersUpdated + $usersFailed) users | $usersUpdated Users Updated + $usersFailed Users Failed"
        Write-Host "Log file: $currentFolder\$Output.log"
    }
}

#endregion
#=======================================================================================


#=======================================================================================
#region Mitigation Functions
#=======================================================================================


<#
.Synopsis
   Repair Azure AD Connect AutoUpgrade State
#>
Function Repair-ADSyncToolsAutoUpgradeState
{
    # Checking UpdateCheckEnabled Registry key
    $regkey = 'HKLM:\SOFTWARE\Microsoft\ADHealthAgent\Sync'
    $name = 'UpdateCheckEnabled'
    Try
    {
        $val = Get-ItemProperty -Path $regkey -Name $name -ErrorAction Stop
        Write-Host 'UpdateCheckEnabled: ' $val.UpdateCheckEnabled
    }
    Catch [System.Security.SecurityException]
    {
        Write-Error "Please execute this cmdlet in Windows PowerShell with 'Run As Administrator': $($_.Exception.Message)"
        Return
    }

    # Checking ADSync AutoUpgrade Status
    Try
    {
        $autoUpgradeState = Get-ADSyncAutoUpgrade -ErrorAction Stop
        Write-Host 'ADSyncAutoUpgrade: ' $autoUpgradeState
    }
    Catch
    {
        Write-Error "Error retrieving ADSync AutoUpgrade status: $($_.Exception.Message)"
        Return
    }    

    # Checking AutoUpgrade State Fix
    $isAgentDisabled = $val.UpdateCheckEnabled -eq 0
    $isAutoUpgradeAllowed = $autoUpgradeState -ne 'disabled'
    If($isAutoUpgradeAllowed -and $isAgentDisabled) 
    {
        # Applying AutoUpgrade Fix
        Write-Host 'Fixing AutoUpgrade status and restarting AutoUpgrade service...'
        Set-ItemProperty -path $regkey -name $name -value 1
        Restart-Service 'AzureADConnectHealthSyncMonitor'
        Write-Host 'Result: AutoUpgrade has been fixed successfully.'
    }
    Else
    {
        # Skipping AutoUpgrade Fix
        Write-Host 'Result: AutoUpgrade fix is not required.'
    }

    # Checking HUS ADSync AutoUpgrade Status
    Try
    {
        $agentRegkey = 'HKLM:\SOFTWARE\Microsoft\Azure AD Connect Agents\AzureADConnect'
        $msolRegkey = 'HKLM:\SOFTWARE\Microsoft\MSOLCoExistence\CurrentVersion'
        $versionName = 'Version'
        $version = $null
        
        If((Get-Item $agentRegkey).Property -contains $versionName)
        {
            $val = Get-ItemProperty -Path $agentRegkey -Name $versionName -ErrorAction Stop
            $version = $val.version
        }
        
        $isHusEnabled = -not [string]::IsNullOrEmpty($version)

        If($isAutoUpgradeAllowed -and -not $isHusEnabled)
        {
          # Enable HUS AutoUpgrade
          If((Get-Item $msolRegkey).Property -contains $versionName)
          {
              Write-Host 'HUS AutoUpgrade is disabled, enabling....'
              $val = Get-ItemProperty -Path $msolRegkey -Name $versionName -ErrorAction Stop
              $version = $val.version
              Set-ItemProperty -path $agentRegkey -name $versionName -value $version
              Write-Host 'HusResult: HUS AutoUpgrade has been enabled successfully. Product version = ' $version
          }
          Else
          {
              Write-Error "HusResult: HUS AutoUpgrade fix failed. Registry value doesn't exist, " $path
              Return
          }
        }
        ElseIf(-not $isAutoUpgradeAllowed -and $isHusEnabled)
        {
          # Disable HUS AutoUpgrade
          Write-Host 'HUS AutoUpgrade is enabled, disabling....'
          Remove-ItemProperty -Path $agentRegkey -Name $versionName -ErrorAction Stop
          Write-Host 'HusResult: HUS AutoUpgrade has been disabled successfully.'
        }
        Else
        {
          # Skipping HUS AutoUpgrade Fix
          Write-Host 'HusResult: HUS AutoUpgrade fix is not required.'
        }
    }
    Catch
    {
        Write-Error "HusResult: HUS AutoUpgrade fix failed. Exception: $($_.Exception.Message)"
        Return
    }
}

Function Get-ADSyncToolsTls12RegValue
{
    [CmdletBinding()]
    Param
    (
        # Registry Path
        [Parameter(Mandatory=$true,
                   Position=0)]
        [string]
        $RegPath,

        # Registry Name
        [Parameter(Mandatory=$true,
                   Position=1)]
        [string]
        $RegName
    )

    $regItem = Get-ItemProperty -Path $RegPath -Name $RegName -ErrorAction Ignore

    $output = "" | select Path,Name,Value
    $output.Path = $RegPath
    $output.Name = $RegName

    If ($regItem -eq $null)
    {
        $output.Value = "Not Found"
    }
    Else
    {
        $output.Value = $regItem.$RegName
    }

    $output
}

<#
.Synopsis
   Gets Client\Server TLS 1.2 settings for .NET Framework
.DESCRIPTION
   Reads information from the Registry regarding TLS 1.2 for .NET Framework:

    Path                                                                                       Name
    ----                                                                                       ----
    HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319                              SystemDefaultTlsVersions
    HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319                              SchUseStrongCrypto
    HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319                                          SystemDefaultTlsVersions
    HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319                                          SchUseStrongCrypto
    HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server Enabled
    HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server DisabledByDefault
    HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client Enabled
    HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client DisabledByDefault

   More Information:    
    TLS 1.2 enforcement for Azure AD Connect
    https://docs.microsoft.com/en-us/azure/active-directory/hybrid/reference-connect-tls-enforcement

.EXAMPLE
   Get-ADSyncToolsTls12
#>
Function Get-ADSyncToolsTls12
{
    [CmdletBinding()]
    Param
    ()

    $regSettings = @()
    $regKey = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319'
    $regSettings += Get-ADSyncToolsTls12RegValue $regKey 'SystemDefaultTlsVersions'
    $regSettings += Get-ADSyncToolsTls12RegValue $regKey 'SchUseStrongCrypto'

    $regKey = 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319'
    $regSettings += Get-ADSyncToolsTls12RegValue $regKey 'SystemDefaultTlsVersions'
    $regSettings += Get-ADSyncToolsTls12RegValue $regKey 'SchUseStrongCrypto'

    $regKey = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server'
    $regSettings += Get-ADSyncToolsTls12RegValue $regKey 'Enabled'
    $regSettings += Get-ADSyncToolsTls12RegValue $regKey 'DisabledByDefault'

    $regKey = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client'
    $regSettings += Get-ADSyncToolsTls12RegValue $regKey 'Enabled'
    $regSettings += Get-ADSyncToolsTls12RegValue $regKey 'DisabledByDefault'

    $regSettings
}

<#
.Synopsis
   Sets Client\Server TLS 1.2 settings for .NET Framework
.DESCRIPTION
   Sets the registry entries to enable/disable TLS 1.2 for .NET Framework:

    Path                                                                                       Name
    ----                                                                                       ----
    HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319                              SystemDefaultTlsVersions
    HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319                              SchUseStrongCrypto
    HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319                                          SystemDefaultTlsVersions
    HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319                                          SchUseStrongCrypto
    HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server Enabled
    HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server DisabledByDefault
    HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client Enabled
    HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client DisabledByDefault

   Running the cmdlet without any parameters will enable TLS 1.2 for .NET Framework

   More Information:    
    TLS 1.2 enforcement for Azure AD Connect
    https://docs.microsoft.com/en-us/azure/active-directory/hybrid/reference-connect-tls-enforcement

.EXAMPLE
   Set-ADSyncToolsTls12
.EXAMPLE
   Set-ADSyncToolsTls12 -Enabled $true
#>
Function Set-ADSyncToolsTls12
{
    [CmdletBinding()]
    Param
    (
        # TLS 1.2 Enabled
        [Parameter(Mandatory=$false,
                   ValueFromPipelineByPropertyName=$true,
                   ValueFromPipeline=$true,
                   Position=0)]
        [bool]
        $Enabled = $true
    )

    $ErrorActionPreference = 'Stop'

    Write-Warning 'Modifying TLS settings may affect other services on the Server.' -WarningAction Inquire

    If ($Enabled)
    {
        $regValueEnabled = '1'
        $regValueDisabled = '0'
        $message = 'TLS 1.2 has been enabled. You must restart the Windows Server for the changes to take affect.'
    }
    Else
    {
        $regValueEnabled = '0'
        $regValueDisabled = '1'
        $message = 'TLS 1.2 has been disabled. You must restart the Windows Server for the changes to take affect.'
    }
    
    Try
    {
        If (-Not (Test-Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319'))
        {
            New-Item 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319' -Force | Out-Null
        }
        New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319' -Name 'SystemDefaultTlsVersions' -Value $regValueEnabled -PropertyType 'DWord' -Force | Out-Null
        New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value $regValueEnabled -PropertyType 'DWord' -Force | Out-Null

        If (-Not (Test-Path 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319'))
        {
            New-Item 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319' -Force | Out-Null
        }
        New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319' -Name 'SystemDefaultTlsVersions' -Value $regValueEnabled -PropertyType 'DWord' -Force | Out-Null
        New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value $regValueEnabled -PropertyType 'DWord' -Force | Out-Null

        If (-Not (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server'))
        {
            New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Force | Out-Null
        }
        New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Name 'Enabled' -Value $regValueEnabled -PropertyType 'DWord' -Force | Out-Null
        New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Name 'DisabledByDefault' -Value $regValueDisabled -PropertyType 'DWord' -Force | Out-Null

        If (-Not (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client'))
        {
            New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Force | Out-Null
        }
        New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Name 'Enabled' -Value $regValueEnabled -PropertyType 'DWord' -Force | Out-Null
        New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Name 'DisabledByDefault' -Value $regValueDisabled -PropertyType 'DWord' -Force | Out-Null
    }
    Catch [System.Security.SecurityException]
    {
        Throw "Please execute this cmdlet in Windows PowerShell with 'Run As Administrator': $($_.Exception.Message)"
    }
    Catch
    {
        Throw "Failed to set Registry settings. Error Details: $($_.Exception.Message)"
    }

    Write-Host $message -ForegroundColor Cyan
}

#endregion
#=======================================================================================


#=======================================================================================
#region SQL Functions
#=======================================================================================

function  BuildSqlConnection
{
   Param ([string] $Server,
          [string] $Instance,
          [string] $Database,
          [string] $Protocol,
          [string] $UserName,
          [string] $Password
          )

    $sqlBinding = New-Object System.Data.SqlClient.SqlConnectionStringBuilder
    $sqlBinding['Integrated Security'] = $true
    # $sqlBinding['Connect Timeout'] = 30

    if ($Protocol) 
    {
        $sqlBinding['Data Source'] = "${Protocol}:$Server\$Instance"
    }
    else
    {
        $sqlBinding['Data Source'] = "$Server\$Instance"
    }

    if ($Database) 
    {
        $sqlBinding['Initial Catalog'] = $Database
    }

    if ($UserName) 
    {
        $sqlBinding['User ID'] = $UserName
    }

    if ($Password) 
    {
        $sqlBinding['Password'] = $Password
    }

    return $sqlBinding
}

function GetInnerExceptionMessage($exception)
{
    $innerException = $exception.InnerException
    if ($innerException)
    {
        return $innerException.Message
    }

    return $null;
}

function SplitString([string] $Source, [string] $SplitCharacter, [switch] $RemoveDuplicates)
{
    if ($RemoveDuplicates)
    {
        $splitOption = [System.StringSplitOptions]::RemoveEmptyEntries
    }
    else
    {
        $splitOption = [System.StringSplitOptions]::None
    }

    $records = $Source.Split($SplitCharacter, $splitOption)
    return $records
}

function Get-ADSyncToolsSqlBrowserInstances([string] $hostName)
{
    $Port = 1434
    $ConnectionTimeout = 1000

    $UDPClient = new-Object system.Net.Sockets.Udpclient
    $UDPClient.client.ReceiveTimeout = $ConnectionTimeout
    $UDPClient.Client.Blocking = $True

    Write-Progress -Activity "Attempting to retrieve instance information for $hostName" -Status "Querying the SQL Server Browser service"
    try
    {
        $UDPClient.Connect($hostName, $Port)
    }
    catch
    {
        $innerExceptionMsg = GetInnerExceptionMessage($_.Exception)
        Write-Error -Category ConnectionError "Unable to connect to the SQL Server Browser service on $hostName port $Port (UDP).  $innerExceptionMsg."
        return $null
    }

    $rawResponse = "";
    try 
    {
        $UDPPacket = 0x02,0x00,0x00
        $UDPEndpoint = New-Object system.net.ipendpoint([system.net.ipaddress]::Any,0)
        [void]$UDPClient.Send($UDPPacket, $UDPPacket.length)
        $BytesRecived = $UDPClient.Receive([ref]$UDPEndpoint)

        $ToASCII = new-object system.text.asciiencoding
        $rawResponse = $ToASCII.GetString($BytesRecived)
        $socket = $null;
        $UDPClient.close()
    }
    catch 
    {
        Write-Progress -Activity "Attempting to retrieve instance information for $hostName" -Status "Failed" -Completed

        $innerExceptionMsg = GetInnerExceptionMessage($_.Exception)
        $message = "Unable to read the SQL Server Browser configuration. "
        $message += $innerExceptionMsg + ". "
        $message += "Ensure port $port (UDP) is open on $hostName and the SQL Server Browser service is running. "
        Write-Error -Category ConnectionError $message
        $UDPClient.Close()
        return $null
    }

    if ($rawResponse) 
    {
        $instances = @(ParseBrowserResponse($rawResponse))

        Write-Host "Verifying protocol bindings and port connectivity..."
        $step = 0
        foreach ($instance in $Instances)
        {
            $instanceName = $instance.InstanceName
            $port = $instance.tcp

            $step++
            $complete = ($step * 100) / $instances.Count
            if ($instance.tcp)
            {
                Write-Progress -Activity "Verifying SQL Browser Configuration" -Status "Instance: $instanceName - connecting to port $port" -PercentComplete $complete
                $isPortOpen = Test-ADSyncToolsSqlNetworkPort $hostName $instance.tcp
                if ($isPortOpen)
                {
                    $status = "Enabled - port $port is assigned and reachable through the firewall"
                    $instance | Add-Member -MemberType NoteProperty -Name TcpStatus -Value $status
                    Start-Sleep -Seconds 2
                }
                else
                {
                    $status = "Blocked - the inbound firewall rule for port $port is missing or disabled"
                    $instance | Add-Member -MemberType NoteProperty -Name TcpStatus -Value $status
                }
            }
            else
            {
                Write-Progress -Activity "Verifying SQL Browser Configuration" -Status "Instance: $instanceName - TCP/IP binding is disabled" -PercentComplete $complete
                $status = "Disabled - the TCP/IP binding for this instance is missing or disabled"
                $instance | Add-Member -MemberType NoteProperty -Name tcp -Value Disabled
                $instance | Add-Member -MemberType NoteProperty -Name TcpStatus -Value $status
                Start-Sleep -Seconds 2
            }

            $progressMsg = "{0,-15} : {1}" -f $instanceName,$status
            Write-Host $progressMsg
        }

        Write-Progress -Activity "Verifying SQL Firewall Configuration" -Status "Completed" -Completed
        return $Instances
    }

    return $null
}

function ParseBrowserResponse([string] $response)
{
    # A SQL Browser response looks like instance;;instance;;instance;; where each instance string
    # contains a list of parameter/value pairs encoded as: p1;v1;p2;v2;p3;v3;p4;v4;;
    $response = $response.Substring(3,$response.Length-3).Replace(";;","~")
    $instanceRecords = SplitString -Source $response -SplitCharacter "~" -RemoveDuplicates
    Write-Host SQL browser response contained $instanceRecords.Length instances.

    $Instances = @();
    foreach ($instance in $instanceRecords)
    {
        $sqlInstance = New-Object -TypeName PsObject
        $config = SplitString -Source $instance -SplitCharacter ";"
        $param = 0

        $sqlInstance | Add-Member -MemberType NoteProperty -Name BrowserRecord -Value $instance
        for ($param = 0; $param -lt $config.Count; $param + 2)
        {
            $keyword = $config[$param]
            $value = $config[$param + 1]
            $sqlInstance | Add-Member -MemberType NoteProperty -Name $keyword -Value $value 
            $param += 2
        }

        $instances += $sqlInstance
    }

    return $instances
}

function Test-ADSyncToolsSqlNetworkPort([string] $hostName, [string] $port)
{
    $tcpClient = new-object Net.Sockets.TcpClient
    try
    {
        $tcpClient.Connect($hostName, $port)
    }
    catch {}


    if($tcpClient.Connected)
    {
        $tcpClient.Close()
        return $true
    }

    return $false
}


function Resolve-ADSyncToolsSqlHostAddress([string] $hostName)
{
    try
    {
        Write-Host Resolving server address : $hostName
        $ipAddresses = [System.Net.Dns]::GetHostAddresses($hostName) | Select-Object -Property AddressFamily, IPAddressToString
        foreach ($address in $ipAddresses)
        {
            Write-Host "   " $address.AddressFamily: $address.IPAddressToString
        }
        Write-Host

        return $ipAddresses
    }
    catch
    {
        $innerExceptionMsg = GetInnerExceptionMessage($_.Exception)
        Write-Error -Category ObjectNotFound "Unable to resolve host address.  $innerExceptionMsg"
        return $null
    }
}

<# SQL Diagnostics related functions and utilities #>
function Connect-ADSyncToolsSqlDatabase
{
    Param (
        [Parameter(Mandatory=$true)]   
        [string] $Server,
        [string] $Instance,
        [string] $Database,
        [string] $UserName,
        [string] $Password)

    $sqlConfigMgr = "SQL Server Configuration Manager"

    # Bail immediately if we can't resolve the server name
    $ipAddresses = Resolve-ADSyncToolsSqlHostAddress $Server
    if (!$ipAddresses)
    {
        return
    }

    # Try connecting over TCP using the full instance name + optional port  ex: "MySqlInstance,1234"
    # If this succeeds return the connection object for use in SQL queries
    $tcpProtocolBinding = BuildSqlConnection $Server $Instance $Database "tcp" $UserName $Password
    $sqlTcpConnection = New-Object System.Data.SqlClient.sqlConnection($tcpProtocolBinding)
    try
    {
        if ($Instance)
        {
            Write-Host Attempting to connect to $Server\$Instance using a TCP binding.
        }
        else
        {
            Write-Host Attempting to connect to $Server using a TCP binding for the default instance.
        }

        Write-Host "   " $sqlTcpConnection.ConnectionString

        Write-Progress -Activity "Connecting to $Instance on $Server" -Status "Attempting TCP/IP connection"
        $sqlTcpConnection.Open()
        Write-Host "   Successfully connected."
        return $sqlTcpConnection
    }
    catch
    {
        $innerExceptionMsg = GetInnerExceptionMessage($_.Exception)
        Write-Error -Category ConnectionError "Unable to connect using a TCP binding.  $innerExceptionMsg"
        Write-Host
    }

    Write-Progress -Activity "Connecting to $Instance on $hostName" -Completed 


    # Parse out the SQL instance name and port as the latter only makes sense for TCP connections
    $instanceName = $Instance
    $port = $null
    if ($Instance)
    {
        $instanceParams = SplitString -Source $Instance -SplitCharacter "," -RemoveDuplicates
        if ($instanceParams.Count -eq 2)
        {
            $instanceName = $instanceParams[0]
            $port = $instanceParams[1]
        }
    }

    #
    # Fall thru to troubleshooting / diagnostic steps
    #

    Write-Host "TROUBLESHOOTING: Attempting to query the SQL Server Browser service configuration on $Server."
    $instances = Get-ADSyncToolsSqlBrowserInstances $Server
    Write-Host

    #
    # The SQL browser tells us all enabled protocols and ports.  Whip thru the list testing the
    # TCP ports to see if they can be successfully opened.  A failure here is most likely due to
    # a missing inbound firewall rule.
    #
    Write-Host
    Write-Host WHAT TO TRY NEXT:
    Write-Host
    if ($instances)
    {
        $sqlBrowserEnabled = $true
        Write-Host Each SQL instance must be bound to an explicit static TCP port and paired with an
        Write-Host inbound firewall rule on $Server to allow connection. Review the TcpStatus field
        Write-Host for each instance and take corrective action.

        $instances | Format-List -Property InstanceName,tcp,TcpStatus
    }

    #
    # The browser isn't running so the best we can do is give some advice and probe the port to see
    # if it can be successfully opened.  The user should use the SQL Server Configuration Manager to
    # verify the protocol bindings and/or start the SQL Server Browser service give this script more
    # information to further troubleshoot the issue.
    #
    else
    {
        $sqlBrowserEnabled = $false
        $message  = "Each SQL instance must be bound to an explicit static TCP port and paired with an inbound firewall rule on $Server to allow connection. "
        $message += "Enable the SQL Server Browser service temporarily on the SQL server and use Get-ADSyncToolsSqlBrowserInstances to further troubleshoot the issue. " 
        $message += "Alternatively use the $sqlConfigMgr on $Server to verify the instance name and TCP/IP port assignment manually. "
        Write-Host $message 
        Write-Host

        # If no instance was given we test the typical port for the DEFAULT SQL instance (TCP 1433).  If we can't
        # connect then most likely they are missing a firewall rule OR have tinkered with the default port.
        if (!$Instance)
        {
            $portRequired = $false

            Write-Host "Determining if the default SQL instance port (TCP 1433) is open on" $Server.
            $portOpen = Test-ADSyncToolsSqlNetworkPort $Server 1433
            if ($portOpen)
            {
                Write-Host "   " The port for the default SQL instance is open.
            }
            else
            {
                $message =  "The typical port for the DEFAULT SQL instance (TCP 1433) is not open.  Use the $sqlConfigMgr to verify "
                $message += "the SQL configuration and ensure an inbound firewall rule is opened on $Server."
                Write-Host $message
            }

            Write-Host
        }

        # For instances other than the default, both the name + port must be given in order to connect
        else
        {
            $portRequired = $true

            # With no browser, the SQL client won't be able to connect unless we specify the port number!
            if (!$port)
            {
                $message =  "You must specify both the instance name and the port to connect when the SQL Server Browser service is not running. "
                $message += "An inbound firewall rule on $Server is required for the associated port.`n"
                $message += "`tExample: 'MySQLInstance,1234' where 1234 has a matching firewall rule."
                Write-Host $message
            }

            # Test whether or not we can open the specified port.  If we can't then most likely the firewall rule is missing.
            else
            {
                Write-Host "To connect to the $instanceName instance, $Server must have an inbound firewall rule for port $port."
                Write-Progress -Activity "Verifying network connectivity" -Status "Instance: $instanceName - connecting to port $port" 
                Write-Host Verifying port $port on $Server is open.
                $portOpen = Test-ADSyncToolsSqlNetworkPort -hostName $Server -port $port
                if ($portOpen)
                {
                    Write-Host Successfully probed port.
                }
                else
                {
                    Write-Host Unable to open port $port.
                    Write-Host

                    $message = "Use the $sqlConfigMgr on $Server to verify the instance name and port assignment. "
                    $message += "Then verify an associated inbound firewall rule is opened on $Server."
                    Write-Host $message
                }

                Write-Progress -Activity "Verifying network connectivity" -Completed
            }
        }
    }
}


function Invoke-ADSyncToolsSqlQuery {
     param(
        [Parameter(Mandatory=$true)]   
        [System.Data.SqlClient.SqlConnection] $SqlConnection,

        [string] $Query = "SELECT name, database_id FROM sys.databases"
      )

    $command = new-object system.data.sqlclient.sqlcommand($Query, $SqlConnection)

    $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command
    $dataset = New-Object System.Data.DataSet

    try
    {
        $rows = $adapter.Fill($dataSet)
        write-host "Query returned $rows rows."
        return $dataSet.Tables
    }
    catch
    {
        Write-Error -Category InvalidOperation "Query failed.  $_.Exception.Message"
    }

    return $null
}

function Get-ADSyncToolsDuplicateUsersSourceAnchor
{
    [CmdletBinding()]
    Param
    (
        # AD connector name for which user source anchors needs to be repaired
        [Parameter(Mandatory=$true, 
                   ValueFromPipelineByPropertyName=$true)]
        $ADConnectorName
    )

    $title = "Get-ADSyncToolsDuplicateUsersSourceAnchor"
    Write-Host $title
    Write-Host "`r`n"

    #Import Modules
    Import-Module ActiveDirectory
    $aadConnectRegistryKey = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Azure AD Connect'
    $modulePath    = [System.IO.Path]::Combine($aadConnectRegistryKey.InstallationPath, "AADPowerShell\MSOnline.psd1")
    Import-Module $modulePath -ErrorAction Stop

    $exportFilePath = $env:temp + "\export.xml"
    $exportFilePathArgs = " " + $exportFilePath + " /f:i"
    $csExportFilePath = Join-Path -Path $(Get-ADSyncToolsADsyncFolder) -ChildPath 'Bin\csexport.exe'

    if (Test-Path $exportFilePath)
    {
        Remove-Item -Path $exportFilePath
    }
    Start-Process -FilePath $csExportFilePath -ArgumentList `"$ADConnectorName`",$exportFilePathArgs -Wait

    [xml]$content = Get-Content -Path $exportFilePath
    $exportErrorObjects=$content.SelectNodes("cs-objects/cs-object")
    $applyFixForAllObjects = $false
    foreach ($exportErrorObjectInfo in $exportErrorObjects)
    {
        $callStackInfo= $exportErrorObjectInfo.SelectSingleNode("import-errordetail/import-status/extension-error-info/call-stack").InnerText
        $exportErrorObject = $exportErrorObjectInfo.SelectSingleNode("synchronized-hologram/entry")
        $adDomainName = $exportErrorObjectInfo.SelectSingleNode("fully-qualified-domain-name").InnerText
        if ($callStackInfo -eq $null -or $exportErrorObject -eq $null -or $callStackInfo -NotMatch "SourceAnchor attribute has changed.")
        {
            Continue
        }

        $csObject = Get-ADSyncCSObject -DistinguishedName $exportErrorObject.dn -ConnectorName $ADConnectorName
        $mvObject = Get-ADSyncMVObject -Identifier $csObject.ConnectedMVObjectId

        If ($csObject -and $mvObject -and $adDomainName -and `
            $mvObject.Attributes['sourceAnchor'] -and $mvObject.Attributes['sourceAnchor'].Values[0])
        {
            $duplicateUserSourceAnchorInfo = [DuplicateUserSourceAnchorInfo]::new()
            $duplicateUserSourceAnchorInfo.UserName = $csObject.Attributes['displayName'].Values[0]
            $duplicateUserSourceAnchorInfo.DistinguishedName = $exportErrorObject.dn
            $duplicateUserSourceAnchorInfo.ADDomainName = $adDomainName

            Try
            {
                $duplicateUserSourceAnchorInfo.CurrentMsDsConsistencyGuid = [System.Convert]::FromBase64String($csObject.Attributes['mS-DS-ConsistencyGuid'].Values[0])
                $duplicateUserSourceAnchorInfo.ExpectedMsDsConsistencyGuid = [System.Convert]::FromBase64String($mvObject.Attributes['sourceAnchor'].Values[0])
            
                [pscustomobject]@{
                    DuplicateUserSourceAnchorInfo = $duplicateUserSourceAnchorInfo
                }
            }
            Catch
            {
                Write-Host "Unable to parse MsDsConsistencyGuid value for `"$($DuplicateUserSourceAnchorInfo.UserName)`""
            }
        }
    }

}

function Set-ADSyncToolsDuplicateUsersSourceAnchor
{
    [CmdletBinding()]
    Param
    (
        # User list for which the source anchor needs to be fixed
        [Parameter(Mandatory=$true, 
                   Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [DuplicateUserSourceAnchorInfo]
        $DuplicateUserSourceAnchorInfo,

        # AD EA/DA Admin Credentials, If not provided default credentials will be used
        [Parameter(Mandatory=$false)]
        [PSCredential] 
        $ActiveDirectoryCredential,

        [Parameter(Mandatory=$false)]
        [bool] 
        $OverridePrompt = $false
    )

    Begin 
    {
        $title = "Set-ADSyncToolsDuplicateUsersSourceAnchor"
        Write-Host $title
        Write-Host "`r`n"
    }

    Process
    {
        $decision = 0
        if ($OverridePrompt -eq $false)
        {
            $title = "Repairing SourceAnchor"
            $question = "`"$($DuplicateUserSourceAnchorInfo.UserName)`" mS-DS-ConsistencyGuid value will be updated from `"$($DuplicateUserSourceAnchorInfo.CurrentMsDsConsistencyGuid)`" to `"$($DuplicateUserSourceAnchorInfo.ExpectedMsDsConsistencyGuid)`". Are you sure?"
            $choices  = '&Yes', '&No'
            $decision = $Host.UI.PromptForChoice($title, $question, $choices, 1)
        }

        if ($decision -eq 0) 
        {
            Write-Host "Updating `"$($DuplicateUserSourceAnchorInfo.UserName)`" mS-DS-ConsistencyGuid from `"$($DuplicateUserSourceAnchorInfo.CurrentMsDsConsistencyGuid)`" to `"$($DuplicateUserSourceAnchorInfo.ExpectedMsDsConsistencyGuid)`""
            if ($ActiveDirectoryCredential)
            {
                Set-ADObject -Identity $DuplicateUserSourceAnchorInfo.DistinguishedName -Replace @{'mS-DS-ConsistencyGuid'=$DuplicateUserSourceAnchorInfo.ExpectedMsDsConsistencyGuid} -Credential $ActiveDirectoryCredential -Server $DuplicateUserSourceAnchorInfo.ADDomainName
            }
            else
            {
                Set-ADObject -Identity $DuplicateUserSourceAnchorInfo.DistinguishedName -Replace @{'mS-DS-ConsistencyGuid'=$DuplicateUserSourceAnchorInfo.ExpectedMsDsConsistencyGuid} -Server $DuplicateUserSourceAnchorInfo.ADDomainName
            }
            Write-Host "`r`n"
        }        
    }

    End
    {
        Write-Host "Set-ADSyncToolsDuplicateUsersSourceAnchor execution complete"
    }
}

#endregion
#=======================================================================================


Export-ModuleMember Search-ADSyncToolsADobject, `                   # Search an AD object in Active Directory Forest
                    Get-ADSyncToolsMsDsConsistencyGuid, `           # Get an AD object ms-ds-ConsistencyGuid
                    Set-ADSyncToolsMsDsConsistencyGuid, `           # Set an AD object ms-ds-ConsistencyGuid
                    Clear-ADSyncToolsMsDsConsistencyGuid, `         # Clear an AD object mS-DS-ConsistencyGuid
                    ConvertFrom-ADSyncToolsImmutableID, `           # Convert Base64 ImmutableId (SourceAnchor) to GUID value
                    ConvertTo-ADSyncToolsImmutableID, `             # Convert GUID (ObjectGUID / ms-Ds-Consistency-Guid) to a Base64 string
                    ConvertFrom-ADSyncToolsAadDistinguishedName, `  # Convert AAD Connector DistinguishedName to ImmutableId
                    ConvertTo-ADSyncToolsAadDistinguishedName, `    # Convert ImmutableId to AAD Connector DistinguishedName
                    ConvertTo-ADSyncToolsCloudAnchor, `             # Convert Base64 Anchor to CloudAnchor
                    Export-ADSyncToolsAadDisconnectors, `           # Export Azure AD Disconnector objects
                    Get-ADSyncToolsAadObject, `                     # Get synced objects for a given SyncObjectType
                    Remove-ADSyncToolsAadObject, `                  # Remove orphaned synced object from Azure AD
                    Get-ADSyncToolsRunHistory, `                    # Gets ADSync Run History
                    Export-ADSyncToolsRunHistory, `                 # Exports ADSync Run History
                    Import-ADSyncToolsRunHistory , `                # Imports ADSync Run History
                    Get-ADSyncToolsRunHistoryLegacyWmi, `           # Gets ADSync Run History for older versions of AAD Connect (WMI)
                    Remove-ADSyncToolsExpiredCertificates, `        # Removes Expired Certificates from a users in AD
                    Trace-ADSyncToolsADImport, `                    # Generates a trace file with AD Import step data
                    Trace-ADSyncToolsLdapQuery, `                   # Trace LDAP queries
                    Export-ADSyncToolsObjects, `                    # Dumps internal ADsync object(s) to XML file(s)
                    Import-ADSyncToolsObjects, `                    # Imports internal ADSync object from XML file
                    Import-ADSyncToolsSourceAnchor, `               # Imports ImmutableId values from Azure AD 
                    Export-ADSyncToolsSourceAnchorReport, `         # Exports a list of mS-DS-ConsistencyGuid values to update in local AD
                    Update-ADSyncToolsSourceAnchor, `               # Updates mS-DS-ConsistencyGuid values for users in local AD
                    Repair-ADSyncToolsAutoUpgradeState, `           # Fixes AutoUpgrade Suspended state
                    Get-ADSyncToolsTls12, `                         # Gets Client\Server TLS 1.2 settings for .NET Framework                    
                    Set-ADSyncToolsTls12, `                         # Sets Client\Server TLS 1.2 settings for .NET Framework
                    Connect-ADSyncToolsSqlDatabase, `               # SQL Diagnostics
                    Invoke-ADSyncToolsSqlQuery,`                    # SQL Diagnostics
                    Resolve-ADSyncToolsSqlHostAddress, `            # SQL Diagnostics
                    Test-ADSyncToolsSqlNetworkPort, `               # SQL Diagnostics
                    Get-ADSyncToolsSqlBrowserInstances, `           # SQL Diagnostics
                    Get-ADSyncToolsTenantAzureEnvironment, `        # Gets the tenant azure environment
                    Get-ADSyncToolsDuplicateUsersSourceAnchor,`     # Gets duplicate user details which contain 'Source Anchor has changed' error
                    Set-ADSyncToolsDuplicateUsersSourceAnchor `     # Sets correct source anchor(MsDsConsistencyGuid) values for duplicate users which contain 'Source Anchor has changed' error
# SIG # Begin signature block
# MIInogYJKoZIhvcNAQcCoIInkzCCJ48CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD2HpSc2VYln7NH
# /TyDSrSvsXcGorFsmv9rE9hmW7rj3aCCDYIwggYAMIID6KADAgECAhMzAAADXJXz
# SFtKBGrPAAAAAANcMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwNDA2MTgyOTIyWhcNMjQwNDAyMTgyOTIyWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDijA1UCC84R0x+9Vr/vQhPNbfvIOBFfymE+kuP+nho3ixnjyv6vdnUpgmm6RT/
# pL9cXL27zmgVMw7ivmLjR5dIm6qlovdrc5QRrkewnuQHnvhVnLm+pLyIiWp6Tow3
# ZrkoiVdip47m+pOBYlw/vrkb8Pju4XdA48U8okWmqTId2CbZTd8yZbwdHb8lPviE
# NMKzQ2bAjytWVEp3y74xc8E4P6hdBRynKGF6vvS6sGB9tBrvu4n9mn7M99rp//7k
# ku5t/q3bbMjg/6L6mDePok6Ipb22+9Fzpq5sy+CkJmvCNGPo9U8fA152JPrt14uJ
# ffVvbY5i9jrGQTfV+UAQ8ncPAgMBAAGjggF/MIIBezArBgNVHSUEJDAiBgorBgEE
# AYI3TBMBBgorBgEEAYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUXgIsrR+tkOQ8
# 10ekOnvvfQDgTHAwRQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEWMBQGA1UEBRMNMjMzMTEwKzUwMDg2ODAfBgNVHSMEGDAWgBRI
# bmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEt
# MDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBABIm
# T2UTYlls5t6i5kWaqI7sEfIKgNquF8Ex9yMEz+QMmc2FjaIF/HQQdpJZaEtDM1Xm
# 07VD4JvNJEplZ91A4SIxjHzqgLegfkyc384P7Nn+SJL3XK2FK+VAFxdvZNXcrkt2
# WoAtKo0PclJOmHheHImWSqfCxRispYkKT9w7J/84fidQxSj83NPqoCfUmcy3bWKY
# jRZ6PPDXlXERRvl825dXOfmCKGYJXHKyOEcU8/6djs7TDyK0eH9ss4G9mjPnVZzq
# Gi/qxxtbddZtkREDd0Acdj947/BTwsYLuQPz7SNNUAmlZOvWALPU7OOVQlEZzO8u
# Ec+QH24nep/yhKvFYp4sHtxUKm1ZPV4xdArhzxJGo48Be74kxL7q2AlTyValLV98
# u3FY07rNo4Xg9PMHC6sEAb0tSplojOHFtGtNb0r+sioSttvd8IyaMSfCPwhUxp+B
# Td0exzQ1KnRSBOZpxZ8h0HmOlMJOInwFqrCvn5IjrSdjxKa/PzOTFPIYAfMZ4hJn
# uKu15EUuv/f0Tmgrlfw+cC0HCz/5WnpWiFso2IPHZyfdbbOXO2EZ9gzB1wmNkbBz
# hj8hFyImnycY+94Eo2GLavVTtgBiCcG1ILyQabKDbL7Vh/OearAxcRAmcuVAha07
# WiQx2aLghOSaZzKFOx44LmwUxRuaJ4vO/PRZ7EzAMIIHejCCBWKgAwIBAgIKYQ6Q
# 0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5
# WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQD
# Ex9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4
# BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe
# 0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato
# 88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v
# ++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDst
# rjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN
# 91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4ji
# JV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmh
# D+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbi
# wZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8Hh
# hUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaI
# jAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTl
# UAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNV
# HQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQF
# TuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29m
# dC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNf
# MjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNf
# MjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnlj
# cHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5
# AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oal
# mOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0ep
# o/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1
# HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtY
# SWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInW
# H8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZ
# iWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMd
# YzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7f
# QccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKf
# enoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOpp
# O6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZO
# SEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGXYwghlyAgEBMIGVMH4xCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jv
# c29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAANclfNIW0oEas8AAAAAA1ww
# DQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJLu7QAU
# APcdnRCL/5r2u6oL/0KA8AcUlEvJKg1dqB20MEIGCisGAQQBgjcCAQwxNDAyoBSA
# EgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20w
# DQYJKoZIhvcNAQEBBQAEggEATvbRhssGTg3jf90lo8tYV/aN1xL5FBlqqpAwHyKv
# 8j1R2bnOQMZYrCUSh+a7z3PGHQoraLXgZRn4g9Z3YVsTQGES/7hpicKzdMzgHd8J
# rkng8g8OoGTFk1ywScNirMWBRm5inu1OquhIW5e3gzYy4Kj6/5vbDnjUGa/dvi8E
# FwrK0AC6jtTNGhfo7viymBYpwmZfHZMjzLU5l148u9Vp31vwUjUGxzq4GCwWUsBs
# 73fWJhU3qfrcbuSGDskyPn7vghLleRW1ptoUr3yq1M4fzbsnDOx1g1Uu4hD0v7Nf
# nEhvZhrYTY6QNAMhqPytQHHfSN1lfs3BJMSh2xtSS0hLcKGCFwAwghb8BgorBgEE
# AYI3AwMBMYIW7DCCFugGCSqGSIb3DQEHAqCCFtkwghbVAgEDMQ8wDQYJYIZIAWUD
# BAIBBQAwggFRBgsqhkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoD
# ATAxMA0GCWCGSAFlAwQCAQUABCD8CwVxArmKMTgJrOOsc0PQe2qZScDuhXgC91jA
# FAnHlQIGZFzvGDImGBMyMDIzMDUxNzIyNTUzMi4wNDRaMASAAgH0oIHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjo3QkYxLUUzRUEtQjgwODElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaCCEVcwggcMMIIE9KADAgECAhMzAAAByPmw7mft6mtGAAEAAAHI
# MA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4X
# DTIyMTEwNDE5MDEzN1oXDTI0MDIwMjE5MDEzN1owgcoxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNh
# IE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjdCRjEtRTNFQS1C
# ODA4MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjAN
# BgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAucudfihPgyRWwnnIuJCqc3TCtFk0
# XOimFcKjU9bS6WFng2l+FrIid0mPZ7KWs6Ewj21X+ZkGkM6x+ozHlmNtnHSQ48pj
# IFdlKXIoh7fSo41A4n0tQIlwhs8uIYIocp72xwDBHKSZxGaEa/0707iyOw+aXZXN
# cTxgNiREASb9thlLZM75mfJIgBVvUmdLZc+XOUYwz/8ul7IEztPNH4cn8Cn0tJhI
# Ffp2netr8GYNoiyIqxueG7+sSt2xXl7/igc5cHPZnWhfl9PaB4+SutrA8zAhzVHT
# nj4RffxA4R3k4BRbPdGowQfOf95ZeYxLTHf5awB0nqZxOY+yuGWhf6hp5RGRouc9
# beVZv98M1erYa55S1ahZgGDQJycVtEy82RlmKfTYY2uNmlPLWtnD7sDlpVkhYQGK
# uTWnuwQKq9ZTSE+0V2cH8JaWBYJQMIuWWM83vLPo3IT/S/5jT2oZOS9nsJgwwCwR
# UtYtwtq8/PJtvt1V6VoG4Wd2/MAifgEJOkHF7ARPqI9Xv28+riqJZ5mjLGz84dP2
# ryoe0lxYSz3PT5ErKoS0+zJpYNAcxbv2UXiTk3Wj/mZ3tulz6z4XnSl5gy0PLer+
# EVjz4G96GcZgK2d9G+uYylHWwBneIv9YFQj6yMdW/4sEpkEbrpiJNemcxUCmBipZ
# 7Sc35rv4utkJ4/UCAwEAAaOCATYwggEyMB0GA1UdDgQWBBS1XC9JgbrSwLDTiJJT
# 4iK7NUvk9TAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8E
# WDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9N
# aWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYB
# BQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEw
# KDEpLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqG
# SIb3DQEBCwUAA4ICAQDD1nJSyEPDqSgnfkFifIbteJb7NkZCbRj5yBGiT1f9fTGv
# Ub5CW7k3eSp3uxUqom9LWykcNfQa/Yfw0libEim9YRjUNcL42oIFqtp/7rl9gg61
# oiB8PB+6vLEmjXkYxUUR8WjKKC5Q5dx96B21faSco2MOmvjYxGUR7An+4529lQPP
# LqbEKRjcNQb+p+mkQH2XeMbsh5EQCkTuYAimFTgnui2ZPFLEuBpxBK5z2HnKneHU
# J9i4pcKWdCqF1AOVN8gXIH0R0FflMcCg5TW8v90Vwx/mP3aE2Ige1uE8M9YNBn57
# 76PxmA16Z+c2s+hYI+9sJZhhRA8aSYacrlLz7aU/56OvEYRERQZttuAFkrV+M/J+
# tCeGNv0Gd75Y4lKLMp5/0xoOviPBdB2rD5C/U+B8qt1bBqQLVZ1wHRy0/6HhJxbO
# i2IgGJaOCYLGX2zz0VAT6mZ2BTWrJmcK6SDv7rX7psgC+Cf1t0R1aWCkCHJtpYuy
# Kjf7UodRazevOf6V01XkrARHKrI7bQoHFL+sun2liJCBjN51mDWoEgUCEvwB3l+R
# FYAL0aIisc5cTaGX/T8F+iAbz+j2GGVum85gEQS9uLzSedoYPyEXxTblwewGdAxq
# IZaKozRBow49OnL+5CgooVMf3ZSqpxc2QC0E03l6c/vChkYyqMXq7Lwd4PnHqjCC
# B3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAw
# gYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMT
# KU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIx
# MDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57Ry
# IQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VT
# cVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhx
# XFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQ
# HJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1
# KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s
# 4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUg
# fX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3
# Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je
# 1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUY
# hEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUY
# P3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGC
# NxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4w
# HQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYB
# BAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcD
# CDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0T
# AQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNV
# HR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9w
# cm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEE
# TjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOC
# AgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/a
# ZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp
# 4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq
# 95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qB
# woEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG
# +jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3B
# FARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77
# IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJ
# fn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K
# 6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDx
# yKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLOMIICNwIBATCB
# +KGB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEl
# MCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMd
# VGhhbGVzIFRTUyBFU046N0JGMS1FM0VBLUI4MDgxJTAjBgNVBAMTHE1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAN/OE1C7xjU0ClID
# XQBiucAY7suyoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAw
# DQYJKoZIhvcNAQEFBQACBQDoD1Z1MCIYDzIwMjMwNTE3MjEzNDQ1WhgPMjAyMzA1
# MTgyMTM0NDVaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOgPVnUCAQAwCgIBAAIC
# C8sCAf8wBwIBAAICFBswCgIFAOgQp/UCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYK
# KwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUF
# AAOBgQCZ+wVHvtUgRgs4yZzaP8+EfMg/k2Qzg/z9T2IoeT3GHW9va/ZoPYB663wk
# clhsYStL/tVZdDYWyI7E1vEOiAD4nWoXpXiIg1CpKEq4Gafsk/ktVYND8o9EZv8R
# Y3b/BLuhlgC+npH3kEDwrO1tlmx4VoI3Hc+hEceHtsDVqcQRiDGCBA0wggQJAgEB
# MIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAByPmw7mft6mtG
# AAEAAAHIMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcN
# AQkQAQQwLwYJKoZIhvcNAQkEMSIEIEmxDGH//GSbH64Yc3j56WiP0Tz3rV/IoxRS
# ZTTR560RMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgYgCYz80/baMvxw6j
# cqSvL0FW4TdvA09nxHfsPhuEA2YwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFt
# cCBQQ0EgMjAxMAITMwAAAcj5sO5n7eprRgABAAAByDAiBCCYz2zh+m6XI7lMnMCW
# XJuCdCC1yLSSA61OtEJ8Tz/bhzANBgkqhkiG9w0BAQsFAASCAgBS86jWdbDWpKaO
# x5vyyM2l45Hzpdv0oypel2996WXTeoucarakQdewOyjfAYL0nS9tLVQ6+JBvBRKL
# PSg0pmxkvOmXmjI21ut9k2W+tRu4TIrwbG92SJAppUA5MhG2JuBWkxsVXyVu8vYJ
# 7lw0AKRsxJXMA2giPVYB1LIrlyz2W0WU0m3VfYIL1vhIoOMOxwWPpxlE8XeB5sbY
# eiFU1T02iecIzUZZhA3Vsxam/dHhST5VdHyoAyHOTZ5/DhWTBFhKOA+TDJYPgfKg
# 0VvimWLTz3H0JN61BVjQiiNevx0U6xdPGWYgKCfz+DFI3nbXfkUQsZkevPJbP6X7
# cByVEW+P6vLexNbsWllBse9EPpK0AJAmUiUfsFWtt5Klb9Jd24j8R371ON6KEZfB
# 3IyiK+K67Wir3k7rDC6jvfkx/VGNPoS6EhhoUanJIZk2esAOsFdUX5nwDZiW2we0
# 3SL7iT2AteH6UbJS/TY+DGNaO+Ry1ES27PcFtxHBqq+vsw7jeQEZ/CepP6CLVrAL
# BVirSWltonKWX2s5Ren8XoXBWP9aiJKRooNLkUUGlh2tPvl3586GAFfLcvbM+Dml
# Dba1ctcfUXJ+4zOTS3O24viZy6zlsS6sPXxAF5010KzG2Dq4ZZBHsIZpFuSFGHUI
# NZk2LblS+x8WPaGYrIJMhUf5UZFanA==
# SIG # End signature block
