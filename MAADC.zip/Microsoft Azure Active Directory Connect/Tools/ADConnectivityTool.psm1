<#

.SYNOPSIS
    Detects connectivity issues between AADConnect and Active Directory.

.DESCRIPTION
    ADConnectivityTools.psm1 is a Windows PowerShell script module that provides functions that are
    used to detect issues when link forests to AADConnect during the "Connect your directories" step
    of AADConnect's installation wizard.
#>

#----------------------------------------------------------
# STATIC VARIABLES
#----------------------------------------------------------
$MinAdForestVersion = [System.DirectoryServices.ActiveDirectory.ForestMode]::Windows2003Forest

# 53 - DNS
# 88 - Kerberos
# 389 - LDAP
$Ports = @('53', '88', '389')
$PortsNoDns = @('88', '389')

# PSCredential object that will be shared across the whole module
[System.Management.Automation.PSCredential] $Script:Credentials


#region Network Connectivity Validation

<#
    .SYNOPSIS
        Detects local network connectivity issues.

    .DESCRIPTION
        Runs local network connectivity tests.

        For the local networking tests, AAD Connect must be able to communicate with the named
        domain controllers on ports 53 (DNS), 88 (Kerberos) and 389 (LDAP) Most organizations run DNS
        on their DCs, which is why this test is currently integrated. Port 53 should be skipped
        if another DNS server has been specified.

    .PARAMETER SkipDnsPort
        If user is not using DNS services provided by the AD Site / Logon DC, then he\she may want
        to skip checking port 53.  User must still be able to resolve _.ldap._tcp.<forestfqdn>
        in order for the Active Directory Connector configuration to succeed.

    .PARAMETER DCs
        Specify DCs to test against.

    .PARAMETER ReturnResultAsPSObject
        Returns the result of this diagnosis in the form of a PSObject. Not necessary during manual interaction with
        this tool.

    .EXAMPLE
        Confirm-NetworkConnectivity -SkipDnsPort -DCs "MYDC1.CONTOSO.COM","MYDC2.CONTOSO.COM"

    .EXAMPLE
        Confirm-NetworkConnectivity -DCs "MYDC1.CONTOSO.COM","MYDC2.CONTOSO.COM" -Verbose
#>
Function Confirm-NetworkConnectivity
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [array] $DCs,

        [switch] $SkipDnsPort,

        [switch] $ReturnResultAsPSObject
    )

    If($SkipDnsPort)
    {
        $Ports = $PortsNoDns
    }

    # Test connectivity on every DC on every Port.
    Foreach ($DC in $DCs)
    {
        Foreach ($Port in $Ports)
        {
            Try
            {
                # Test connection.
                $Result = (Test-NetConnection -ComputerName $DC -Port $Port -ErrorAction Stop -WarningAction SilentlyContinue)
                Switch ($Result.TcpTestSucceeded)
                {
                    True
                    {
                        Write-Log "TCP connection to $($DC) on port $($Port) succeeded." -ForegroundColor Green
                    }
                    False
                    {
                        Write-Log
                        Write-Log "TCP connection to $($DC) on port $($Port) failed. " -ForegroundColor Red
                        Write-Log
                        Write-Log "WHAT TO TRY NEXT:" -ForegroundColor Yellow
                        Write-Log
                        Write-Log "`t Please make sure this port is not blocked. This check can be performed in `"Windows Firewall with" -ForegroundColor Yellow
                        Write-Log "`t Advanced Security`" by determining if there are not any firewall rules enabled and pointing to this" -ForegroundColor Yellow
                        Write-Log "`t port." -ForegroundColor Yellow
                        Write-Log
                        Write-Log "---------------------------------------------------------------------------------------------------------" -ForegroundColor Yellow
                        Write-Log
                        Write-Log "`t The command that failed was: Confirm-NetworkConnectivity. You may try it again once you think the " -ForegroundColor Yellow
                        Write-Log "`t problem is solved. Or you can try with Start-NetworkConnectivityDiagnosisTools if you prefer running all" -ForegroundColor Yellow
                        Write-Log "`t network connectivity tests from the start." -ForegroundColor Yellow
                        Write-Log
                        If($ReturnResultAsPSObject) {
                            Return Get-NetworkDiagnosisResultObject -ADConnectivityToolErrorCode ([ADConnectivityToolErrorCodes]::TCPConnectionFailed) -AssociatedMessage ($DC + ':' + $Port)
                        }
                        Return $False
                    }
                }
                Write-Log "Debug entry for $($DC) [$($Result.RemoteAddress)]:$($Port)."
                Write-Log "Remote endpoint: $($DC)"
                Write-Log "Remote port: $($Result.RemotePort)"
                Write-Log "Interface Alias: $($Result.InterfaceAlias)"
                Write-Log "Source Interface Address: $($Result.SourceAddress.IPAddress)"
                Write-Log "Ping Succeeded: $($Result.PingSucceeded)"
                Write-Log "Ping Reply Time (RTT) Status: $($Result.PingReplyDetails.Status)"
                Write-Log "Ping Reply Time (RTT) RoundTripTime: $($Result.PingReplyDetails.RoundtripTime)"
                Write-Log "TCPTestSucceeded: $($Result.TcpTestSucceeded)"
            }
            Catch
            {
                If($ReturnResultAsPSObject)
                {
                    Return Get-NetworkDiagnosisResultObject -ADConnectivityToolErrorCode ([ADConnectivityToolErrorCodes]::CallToTestNetConnectionFailed) -AssociatedMessage ($_.Exception.Message)
                }
                Write-Error "Error while testing TCP connectivity on $DC port: $Port. Exception message: $($_.Exception.Message). Please try again"
                Return $False
            }
        }
    }
    If($ReturnResultAsPSObject)
    {
        Return $null
    }
    Return $True
}

<#
    .SYNOPSIS
        Detects local Dns issues.

    .DESCRIPTION
        Runs local Dns connectivity tests.
        In order to configure the Active Directory connector, user must have both name resolution
        for the forest he\she is attempting to connect to as well as in the domain controllers
        associated to this forest.

    .PARAMETER Forest
        Specifies the name of the forest to test against.

    .PARAMETER DCs
        Specify DCs to test against.

    .PARAMETER ReturnResultAsPSObject
        Returns the result of this diagnosis in the form of a PSObject. Not necessary during manual interaction with
        this tool.

    .EXAMPLE
        Confirm-DnsConnectivity -Forest "TEST.CONTOSO.COM" -DCs "MYDC1.CONTOSO.COM","MYDC2.CONTOSO.COM"

    .EXAMPLE
        Confirm-DnsConnectivity -Forest "TEST.CONTOSO.COM"
#>
Function Confirm-DnsConnectivity
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [string] $Forest,

        [Parameter(Mandatory=$True)]
        [array] $DCs,

        [switch] $ReturnResultAsPSObject
    )

    # Get DNS targets.
    $DnsTargets = @("_ldap._tcp.$Forest") + $DCs

    Foreach ($HostName in $DnsTargets)
    {
        Try
        {
            # Resolve DNS.
            $DnsResult = Resolve-DnsName -Type ANY $HostName -ErrorAction Stop -WarningAction SilentlyContinue
            If ($DnsResult.Name)
            {
                Write-Log "Successfully resolved $($HostName)." -ForegroundColor Green
            }
            Else
            {
                Write-Log "Error attempting DNS resolution for $($HostName). DnsResult: $DnsResult" -ForegroundColor Red
                Write-Log
                Write-Log "WHAT TO TRY NEXT:" -ForegroundColor Yellow
                Write-Log
                Write-Log "`t Please refer to http://go.microsoft.com/fwlink/?LinkID=48893 or contact your network administrator" -ForegroundColor Yellow
                Write-Log "`t to resolve this issue." -ForegroundColor Yellow
                Write-Log
                Write-Log "---------------------------------------------------------------------------------------------------------" -ForegroundColor Yellow
                Write-Log
                Write-Log "`t The command that failed was: Confirm-DnsConnectivity. You may try it again once you think the " -ForegroundColor Yellow
                Write-Log "`t problem is solved. Or you can try with Start-NetworkConnectivityDiagnosisTools if you prefer running all" -ForegroundColor Yellow
                Write-Log "`t network connectivity tests from the start." -ForegroundColor Yellow
                Write-Log
                if($ReturnResultAsPSObject)
                {
                    Return Get-NetworkDiagnosisResultObject -ADConnectivityToolErrorCode ([ADConnectivityToolErrorCodes]::DNSResolutionFailed) -AssociatedMessage $HostName
                }
                Return $False
            }
        }
        Catch
        {
            if($ReturnResultAsPSObject)
            {
                Return Get-NetworkDiagnosisResultObject -ADConnectivityToolErrorCode ([ADConnectivityToolErrorCodes]::CallToResolveDNSNameFailed) -AssociatedMessage ($_.Exception.Message)
            }
            Write-Error "Error while calling Resolve-DnsName. Exception message: $($_.Exception.Message). Please try again"
            Return $False
        }
    }
    if($ReturnResultAsPSObject)
    {
        Return $null
    }
    Return $True
}

<#
    .SYNOPSIS
        Determines if a specified forest and its associated Domain Controllers are reachable.

    .DESCRIPTION
        Runs "ping" tests (whether a computer can reach a destination computer through the network
        and/or the internet)

    .PARAMETER Forest
        Specifies the name of the forest to test against.

    .PARAMETER DCs
        Specify DCs to test against.

    .EXAMPLE
        Confirm-TargetsAreReachable -Forest "TEST.CONTOSO.COM" -DCs "MYDC1.CONTOSO.COM","MYDC2.CONTOSO.COM"

    .EXAMPLE
        Confirm-TargetsAreReachable -Forest "TEST.CONTOSO.COM"
#>
Function Confirm-TargetsAreReachable
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [string] $Forest,

        [Parameter(Mandatory=$True)]
        [array] $DCs
    )

    $Destinations = @("$Forest") +  $DCs

    Foreach($Destination in $Destinations)
    {
        $Result = ping $Destination
        If($Result.SyncRoot)
        {
            Write-Log "$Destination is reachable." -ForegroundColor Green
        }
        Else
        {
            Write-Log "Ping failed! $Destination is not reachable." -ForegroundColor Red
            Write-Log "This failure can be ignored in case your Firewall is not allowing ICMP." -ForegroundColor Yellow
            Write-Log
        }
    }
}

<#
    .SYNOPSIS
        Determines if a specified forest exists.

    .DESCRIPTION
        Queries a DNS server for the IP addresses associated with a forest.

    .PARAMETER Forest
        Specifies the name of the forest to test against.

    .EXAMPLE
        Confirm-TargetsAreReachable -Forest "TEST.CONTOSO.COM"
#>
Function Confirm-ForestExists
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [string] $Forest
    )
    Try
    {
        [System.Net.Dns]::GetHostAddresses($Forest)
        Write-Log "$Forest exists" -ForegroundColor Green
        Return $True
    }
    Catch
    {
        Write-Log "$Forest could not be reached." -ForegroundColor Red
        Write-Log
        Write-Log "WHAT TO TRY NEXT:" -ForegroundColor Yellow
        Write-Log
        Write-Log "`t Please verify you have typed the forest name correctly and that the Active Directory Domain Services" -ForegroundColor Yellow
        Write-Log "`t service is running on all the Domain Controller(s) associated with $Forest " -ForegroundColor Yellow
        Write-Log
        Write-Log "`t The command that failed was: Confirm-ForestExists. You may try it again once you think the " -ForegroundColor Yellow
        Write-Log "`t problem is solved. Or you can try with Start-NetworkConnectivityDiagnosisTools if you prefer running all" -ForegroundColor Yellow
        Write-Log "`t network connectivity tests from the start." -ForegroundColor Yellow
        Return $False
    }
}

# Helper function to retrieve the name of the forest associated to the server in which AADConnect is being installed.
Function Get-CurrentForestName
{
    Param(
        [switch] $ValidCredentials
    )
    Try
    {
        $ForestName = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest().Name
        Return $ForestName
    }
    Catch
    {
        Write-Log "Cannot retrieve the forest that this machine is logged to." -ForegroundColor Red
        Write-Log
        Write-Log "WHAT TO TRY NEXT:" -ForegroundColor Yellow
        Write-Log
        if($ValidCredentials)
        {
            Write-Log "`t Even though the provided credentials were valid, we found the following issue: " -ForegroundColor Yellow
        }
        Write-Log "`t Unable to establish a connection to the current local computer's forest. Please make sure the Active " -ForegroundColor Yellow
        Write-Log "`t Directory Domain Services service is running and UDP and TCP ports 389 are open in the Domain Controller(s) " -ForegroundColor Yellow
        Write-Log "`t associated with the current local computer's forest. (The user has to perform this manual check on the" -ForegroundColor Yellow
        Write-Log "`t `"Windows Firewall with Advanced Security`" window. There must not be any firewall rules blocking these ports)." -ForegroundColor Yellow
        Write-Log
        Return $null
    }
}

# Helper function for network connectivity tests.
Function Get-DCsInForest
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [string] $ForestName,

        # We need the user credentials to address the scenario in which AADConnect is
        # installed on a different forest than the target forest.
        [Parameter(Mandatory=$True)]
        [System.Management.Automation.PSCredential] $Credentials
    )

    Get-AccountAndPassword -Credentials $Credentials

    # A side-functionality of Get-ForestFQDN is to validate UDP connection on port 389.
    $Forest = Get-ForestFQDN -Forest $ForestName

    If($Forest -eq $null)
    {
        Write-Log "Cannot retrieve DCs associated to a forest named: $ForestName." -ForegroundColor Red
        Write-Log
        Write-Log "WHAT TO TRY NEXT:" -ForegroundColor Yellow
        Write-Log
        Write-Log "`t Cannot establish a connection to the Domain Controller(s) associated to a forest named: `"$ForestName`"." -ForegroundColor Yellow
        Write-Log "`t Please make sure of the following:"
        Write-Log "`t - The Credentials (Username and Password) you have provided are correct" -ForegroundColor Yellow
        Write-Log "`t - UDP and TCP port 389 are open in these DCs (you have to perform this manual check on the `"Windows " -ForegroundColor Yellow
        Write-Log "`t Firewall with Advanced Security`" window on every Domain Controller)" -ForegroundColor Yellow
        Write-Log
        Return $null
    }

    Foreach($Domain in $Forest.Domains)
    {
        Write-Log "Attempting to retrieve domain: $Domain"
        Try {
            (Get-ADDomainController -Filter * -Credential $Script:Credentials -Server $Domain).HostName
        }
        Catch {
            Write-log "Please ensure that the domain: $Domain is reachable. Otherwise install using \`"Custom\`" option and provide user created account to proceed with unreachable domain(s)."
        }
    }
}

# Auxiliary enum that describes the different network connectivity errors detected by this tool.
Add-Type -TypeDefinition @"
    public enum ADConnectivityToolErrorCodes
    {
        NoError,
        ForestNotFound,
        CannotContactDCs,
        DNSResolutionFailed,
        CallToResolveDNSNameFailed,
        TCPConnectionFailed,
        CallToTestNetConnectionFailed,
        UnableToRetrieveForestName_ValidCredentials,
        UnableToRetrieveForestName_InvalidCredentials,
        InvalidCredentials_UsernameOrPassword,
        InvalidCredentials_Domain
    }
"@

#Auxiliary Function that creates a PSObject AADConnect Wizard is going to read.
Function Get-NetworkDiagnosisResultObject
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [ADConnectivityToolErrorCodes] $ADConnectivityToolErrorCode,

        [Parameter(Mandatory=$True)]
        [string] $AssociatedMessage
    )

    $NetworkDiagnosisResult = New-Object -TypeName psobject

    # We pass the numeric value of the error code, so the AADConnect Wizard can interpret the cause of the problem.
    $NetworkDiagnosisResult | Add-Member -MemberType NoteProperty -Name ADConnectivityToolErrorCode -Value $ADConnectivityToolErrorCode.value__

    # AssociatedMessage is a generic string that will hold the name of a Forest or a DC that are failing or an exception message, etc.
    $NetworkDiagnosisResult | Add-Member -MemberType NoteProperty -Name AssociatedMessage -Value $AssociatedMessage

    Return $NetworkDiagnosisResult
}

<#
    .SYNOPSIS
        Main function for network connectivity tests.

    .DESCRIPTION
        Runs local network connectivity tests.

    .PARAMETER Forest
        Specifies forest name to test against.

    .PARAMETER DCs
        Specify DCs to test against.

    .PARAMETER LogFileLocation
        Specifies a the location of a log file that will contain the output of this function.

    .PARAMETER DisplayInformativeMessage
        Flag that allows displaying a message about the purpose of this function.

    .PARAMETER ReturnResultAsPSObject
        Returns the result of this diagnosis in the form of a PSObject. Not necessary to specify during manual interaction with
        this tool.

    .PARAMETER ValidCredentials
        Indicates if the credentials the user typed are valid. Not necessary to specify during manual interaction with
        this tool.

     .EXAMPLE
        Start-NetworkConnectivityDiagnosisTools -Forest "TEST.CONTOSO.COM"

         .EXAMPLE
        Start-NetworkConnectivityDiagnosisTools -Forest "TEST.CONTOSO.COM" -DCs "DC1.TEST.CONTOSO.COM", "DC2.TEST.CONTOSO.COM"
#>
Function Start-NetworkConnectivityDiagnosisTools
{
    Param(
        [Parameter(Mandatory=$False)]
        [string] $Forest,

        [Parameter(Mandatory=$True)]
        [System.Management.Automation.PSCredential] $Credentials,

        [Parameter(Mandatory=$False)]
        [string] $LogFileLocation,

        [Parameter(Mandatory=$False)]
        [array] $DCs,

        [switch] $DisplayInformativeMessage,

        [switch] $ReturnResultAsPSObject,

        [switch] $ValidCredentials
    )

    # Make sure the Global Credentials object is populated before performing network connectivity diagnosis.
    $Script:Credentials = $Credentials

    if($DisplayInformativeMessage)
    {
        Write-Log
        Write-Log "There has been a problem while validating connectivity between AADConnect and the Active Directory." -ForegroundColor Yellow
        Write-Log "An attempt to diagnose the problem will be performed by running a set of network connectivity tests" -ForegroundColor Yellow
        Write-Log
        Read-host  "Press ENTER to continue"
    }

    Write-Log
    Write-Log "Starting NetworkConnectivityDiagnosisTools" -ForegroundColor Magenta
    Write-Log

    # Custom-install scenario
    If($Forest)
    {
        Write-Log
        Write-Log "Verifying that `'$Forest`' exists" -ForegroundColor Yellow
        Write-Log

        $ForestExists = Confirm-ForestExists -Forest $Forest
        If(-not $ForestExists)
        {
            If($ReturnResultAsPSObject)
            {
                Return Get-NetworkDiagnosisResultObject -ADConnectivityToolErrorCode ([ADConnectivityToolErrorCodes]::ForestNotFound) -AssociatedMessage $Forest
            }
            Return
        }
    }
    # Express-install scenario
    Else
    {
        Write-Log
        Write-Log "No Forest name was provided. Attempting to retrieve the forest that this machine is logged to." -ForegroundColor Yellow
        Write-Log

        If($ValidCredentials)
        {
            $Forest = Get-CurrentForestName -ValidCredentials
        }
        Else
        {
            $Forest = Get-CurrentForestName
        }
        If(-not $Forest) {
            If($ReturnResultAsPSObject)
            {
                If($ValidCredentials)
                {
                    Return Get-NetworkDiagnosisResultObject -ADConnectivityToolErrorCode ([ADConnectivityToolErrorCodes]::UnableToRetrieveForestName_ValidCredentials) -AssociatedMessage "NA"
                }
                Else
                {
                    Return Get-NetworkDiagnosisResultObject -ADConnectivityToolErrorCode ([ADConnectivityToolErrorCodes]::UnableToRetrieveForestName_InvalidCredentials) -AssociatedMessage "NA"
                }
            }
            Return
        }
    }

    Write-Log
    Write-Log "Verifying if the provided credentials are correct" -ForegroundColor Yellow
    Write-Log

    $Exception = Get-DomainFQDNData -Verbose -ReturnExceptionOnError
    If($Exception -ne $null)
    {
        Write-Log "There was an error during the validation of the credentials you have entered. Details: $($Exception.Message)" -ForegroundColor Red
        If($ReturnResultAsPSObject)
        {
            If($Exception.ErrorRecord.FullyQualifiedErrorId.Equals("AuthenticationException"))
            {
                Return Get-NetworkDiagnosisResultObject -ADConnectivityToolErrorCode ([ADConnectivityToolErrorCodes]::InvalidCredentials_UsernameOrPassword) -AssociatedMessage "NA"
            }
            Else
            {
                Return Get-NetworkDiagnosisResultObject -ADConnectivityToolErrorCode ([ADConnectivityToolErrorCodes]::InvalidCredentials_Domain) -AssociatedMessage "NA"
            }
        }
        Return
    }
    Write-Log
    Write-Log "The provided credentials were correct" -ForegroundColor Green
    Write-Log

    Write-Log
    Write-Log "Attempting to obtain Domain Controllers associated with $Forest" -ForegroundColor Yellow
    Write-Log

    If(-not $DCs)
    {
        $DCs = Get-DCsInForest -ForestName $Forest -Credentials $Credentials
        If($DCs -eq $null)
        {
            If($ReturnResultAsPSObject)
            {
                Return Get-NetworkDiagnosisResultObject -ADConnectivityToolErrorCode ([ADConnectivityToolErrorCodes]::CannotContactDCs) -AssociatedMessage $Forest
            }
            Return
        }
        Else
        {
            Write-Log "The following DCs where found:" -ForegroundColor Green
            ForEach($DC in $DCs)
            {
                Write-Log "- $DC" -ForegroundColor Green
            }
            Write-Log
        }
    }

    Write-Log "Validating DNS connectivity." -ForegroundColor Yellow
    Write-Log
    If($ReturnResultAsPSObject)
    {
        $ResultAsPSObject = Confirm-DnsConnectivity -Forest $Forest -DCs $DCs -ReturnResultAsPSObject
        If($ResultAsPSObject -ne $null)
        {
            Return $ResultAsPSObject
        }
    }
    Else
    {
        $Result = Confirm-DnsConnectivity -Forest $Forest -DCs $DCs
        If(-not $Result)
        {
            Return
        }
    }
    Write-Log
    Write-Log

    Write-Log "Determining if provided Forest and its associated DCs are reachable." -ForegroundColor Yellow
    Write-Log
    Confirm-TargetsAreReachable -Forest $Forest -DCs $DCs
    Write-Log
    Write-Log

    Write-Log "Validating network connectivity." -ForegroundColor Yellow
    Write-Log
    If($ReturnResultAsPSObject)
    {
        $ResultAsPSObject = Confirm-NetworkConnectivity -DCs $DCs -ReturnResultAsPSObject
        If($ResultAsPSObject -ne $null)
        {
            Return $ResultAsPSObject
        }
    }
    Else
    {
        $Result = Confirm-NetworkConnectivity -DCs $DCs -Verbose
        If(-not $Result)
        {
            Return
        }
    }
    Write-Log
    Write-Log

    If($ReturnResultAsPSObject) {
        Return Get-NetworkDiagnosisResultObject -ADConnectivityToolErrorCode ([ADConnectivityToolErrorCodes]::NoError) -AssociatedMessage "NA"
    }
    Write-Log "ALL NETWORK CONNECTIVITY TESTS HAVE PASSED." -ForegroundColor Magenta
}

#endregion

#region AD Connectivity Validation

<#
    .SYNOPSIS
        Retrieves a DomainFQDN out of an account and password combination.

    .DESCRIPTION
        Attempts to obtain a domainFQDN object out of provided credentials. If the domainFQDN is valid,
        a DomainFQDNName or RootDomainName will be returned, depending on the user's choice. Account (Domain\Username)
        and Password may be requested.

    .PARAMETER DomainFQDNDataType
        Desired kind of data that will be retrieved. Currently limited to "DomainFQDNName" or "RootDomainName".

    .PARAMETER RunWithCurrentlyLoggedInUserCredentials
        The function will use the credentials of the user that is currently logged in the computer, rather than
        requesting custom credentials from the user.

    .PARAMETER ReturnExceptionOnError
        Auxiliary parameter used by Start-NetworkConnectivityDiagnosisTools function

    .EXAMPLE
       Get-DomainFQDNData -DomainFQDNDataType DomainFQDNName -Verbose

    .EXAMPLE
       Get-DomainFQDNData -DomainFQDNDataType RootDomainName -RunWithCurrentlyLoggedInUserCredentials
#>
Function Get-DomainFQDNData
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$False)]
        [ValidateSet("DomainFQDNName","RootDomainName")]
        [string] $DomainFQDNDataType,

        [switch] $RunWithCurrentlyLoggedInUserCredentials,

        [switch] $ReturnExceptionOnError
    )

    Write-Log "Attempting to obtain a domainFQDN" -ForegroundColor Yellow

    If($RunWithCurrentlyLoggedInUserCredentials)
    {
        $DomainName = (Get-ADDomain).DNSRoot

        Write-Log "Using credentials of the user that is currently logged in. Domain Name will be: $DomainName"

        $DirectoryContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("domain", $DomainName)
    }
    Else
    {
        Get-AccountAndPassword
        $networkCredential = $Script:Credentials.GetNetworkCredential()
        # Create object that will allow the discovery of the DomainFQDN and then attempt to retrieve it.
        # NOTE: We need the "Domain\User" format for the User Name parameter here NOT just the User portion.
        $DirectoryContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("domain", $networkCredential.Domain,$Script:Credentials.UserName, $networkCredential.Password)
    }

    Write-Log "Attempting to retrieve DomainFQDN object..."
    Try
    {
        $DomainFQDN = [System.DirectoryServices.ActiveDirectory.Domain]::GetDomain($DirectoryContext)
    }
    Catch
    {
        If($ReturnExceptionOnError) {
            Return $_.Exception
        }
        Else
        {
            Write-Log $_.Exception.Message -ForegroundColor Red
            Write-Log
        }
        Return
    }

    # Return DomainFQDNName or RootDomainName.
    If ($DomainFQDNDataType -eq "DomainFQDNName")
    {
        Write-Log "DomainFQDN obtained" -ForegroundColor Green
        Return $DomainFQDN.Name
    }
    ElseIf($DomainFQDNDataType -eq "RootDomainName")
    {
        Write-Log "RootDomainName obtained" -ForegroundColor Green
        Return $DomainFQDN.Forest.Name
    }
    Return
}


<#
    .SYNOPSIS
        Verifies if a user has Enterprise Admin credentials.

    .DESCRIPTION
        Searches if provided user has Enterprise Admin credentials. Account (Domain\Username) and Password may
        be requested.

    .PARAMETER RunWithCurrentlyLoggedInUserCredentials
        The function will use the credentials of the user that is currently logged in the computer, rather than
        requesting custom credentials from the user.

    .EXAMPLE
        Confirm-ValidEnterpriseAdminCredentials -DomainName test.contoso.com -Verbose

    .EXAMPLE
        Confirm-ValidEnterpriseAdminCredentials -RunWithCurrentlyLoggedInUserCredentials -Verbose
#>
Function Confirm-ValidEnterpriseAdminCredentials
{
    [CmdletBinding()]
    Param(
        [switch] $RunWithCurrentlyLoggedInUserCredentials
    )

    Write-Log "Verifying provided credentials belong to Enterprise Admins group" -ForegroundColor Yellow

    # Define the kind of Sid we will look for.
    $SidType = [System.Security.Principal.WellKnownSidType]::AccountEnterpriseAdminsSid

    If($RunWithCurrentlyLoggedInUserCredentials)
    {
        # Retrieve RootDomainName
        $RootDomainName = Get-DomainFQDNData -DomainFQDNDataType RootDomainName -RunWithCurrentlyLoggedInUserCredentials

        Write-Log "Checking if the currently logged in user has $SidType privileges in $RootDomainName" -ForegroundColor Yellow

        # Get DirectoryEntry from DomainFQDN.
        $DirectoryContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("domain", $RootDomainName)

        $UserName = $env:UserName
    }
    Else
    {
        Get-AccountAndPassword

        # Retrieve RootDomainName.
        $RootDomainName = Get-DomainFQDNData -DomainFQDNDataType RootDomainName

        Write-Log "Checking if $Script:Credentials.UserName has $SidType privileges in $RootDomainName"

        # Get DirectoryEntry from DomainFQDN.
        $DirectoryContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("domain", $RootDomainName, $Script:Credentials.UserName, $Script:Credentials.GetNetworkCredential().password)

        $UserName = $Script:Credentials.UserName.Split('\\')[1]
    }

    Write-Log "Attempting to retrieve DomainFQDN object..."
    Try
    {
        $DomainFQDN = [System.DirectoryServices.ActiveDirectory.Domain]::GetDomain($DirectoryContext)
        $DirectoryEntry = $DomainFQDN.GetDirectoryEntry()
    }
    Catch
    {
        Write-Log $_.Exception.Message -ForegroundColor Red
        Return $False
    }

    # Obtain the DomainId as an array of bytes.
    [byte[]]$DomainSidInBytes = $DirectoryEntry.Properties["objectSid"].Value

    # Extract DomainSid and GroupSid
    $TargetDomainSid = New-Object System.Security.Principal.SecurityIdentifier($DomainSidInBytes, 0)
    $TargetGroupSid = New-Object System.Security.Principal.SecurityIdentifier($SidType, $TargetDomainSid)

    Write-Log "DomainSid - $TargetDomainSid, GroupSid - $TargetGroupSid"

    # Retrieve the group Sid of the groups the user is subscribed to.
    $GroupSids = GetGroupMembershipSidsForUser

    # Try to match the TargetGroupSid with any of the GroupSid's we just retrieved.
    Foreach ($GroupSid in $GroupSids)
    {
        If ($GroupSid -eq $TargetGroupSid)
        {
            Write-Log "EA membership was found!" -ForegroundColor Green
            Return $True
        }
    }
    Write-Log "EA membership not found." -ForegroundColor Red
    Write-Log
    Write-Log "WHAT TO TRY NEXT:" -ForegroundColor Yellow
    Write-Log
    Write-Log "`t Please make sure the credentials you are providing belong to the Enterprise Administrators group." -ForegroundColor Yellow
    Write-Log
    Write-Log "---------------------------------------------------------------------------------------------------------" -ForegroundColor Yellow
    Write-Log
    Write-Log "`t Once that is done, try typing `"Start-ConnectivityValidation -Forest <Forest you desire " -ForegroundColor Yellow
    Write-Log "`t to validate> -AutoCreateConnectorAccount <`$True if you chose `"Create new AD`"" -ForegroundColor Yellow
    Write-Log "`t account in the wizard, `$False otherwise>`"`, to run all connectivity tests from the start." -ForegroundColor Yellow
    Return $False
}

# Helper function that retrieves the group Sid of the groups that a user is subscribed to.
Function GetGroupMembershipSidsForUser
{
    Write-Log "Retrieving group membership SIDs from AD"
	# Initializing list that will contain results of the search.
    $UserNestedMembership = New-Object -TypeName System.Collections.Generic.List[System.Security.Principal.SecurityIdentifier]
	$networkCredential = $Script:Credentials.GetNetworkCredential()	
	$dc = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext([System.DirectoryServices.ActiveDirectory.DirectoryContextType]::Domain, $networkCredential.Domain, $networkCredential.UserName, $networkCredential.Password)			
	$domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetDomain($dc)		
	$de = $domain.GetDirectoryEntry()

	$searchFilter = "(samAccountName=$($networkCredential.UserName))"
    $directorySearcher = New-Object System.DirectoryServices.DirectorySearcher($de, $searchFilter)
    $searchResult = $directorySearcher.FindOne()
	If ($null -ne $searchResult)
    {
		$UserEntry = $searchResult.GetDirectoryEntry()
		$UserEntry.RefreshCache(@("tokenGroups"))

		# Add results to previously created list.
		Foreach ($ResultBytes in $UserEntry.Properties["tokenGroups"])
		{
			$Sid = New-Object System.Security.Principal.SecurityIdentifier($ResultBytes, 0)
			$UserNestedMembership.Add($Sid)
		}
	}   
    Return $UserNestedMembership
}

<#
    .SYNOPSIS
        Retrieves a ForestFQDN out of an account and password combination.

    .DESCRIPTION
        Attempts to obtain a ForestFQDN out of the provided credentials. Account (Domain\Username) and Password
        may be requested.

    .PARAMETER Forest
        Target forest.Default value is the Domain of the currently logged in user.

    .PARAMETER RunWithCurrentlyLoggedInUserCredentials
        The function will use the credentials of the user that is currently logged in the computer, rather than
        requesting custom credentials from the user.

    .EXAMPLE
        Get-ForestFQDN -Forest CONTOSO.MICROSOFT.COM -Verbose

    .EXAMPLE
        Get-ForestFQDN -Forest CONTOSO.MICROSOFT.COM -RunWithCurrentlyLoggedInUserCredentials -Verbose
#>
Function Get-ForestFQDN
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [string] $Forest,

        [switch] $RunWithCurrentlyLoggedInUserCredentials
    )

    Write-Log "Obtaining ForestFQDN" -ForegroundColor Yellow

    If($RunWithCurrentlyLoggedInUserCredentials)
    {
        Write-Log "Using currently logged in user credentials."

        # Create object that will allow the discovery of the ForestFQDN and then attempt to retrieve it. Use currently logged in user credentials.
        $DirectoryContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("forest", $Forest)
    }
    Else
    {
        Get-AccountAndPassword

        # Create object that will allow the discovery of the ForestFQDN and then attempt to retrieve it.
        $DirectoryContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("forest", $Forest, $Script:Credentials.UserName, $Script:Credentials.GetNetworkCredential().password)
    }

    Write-Log "Attempting to retrieve ForestFQDN..."
    Try
    {
        $ForestFQDN = [System.DirectoryServices.ActiveDirectory.Forest]::GetForest($DirectoryContext)
    }
    Catch
    {
        Write-Log $_.Exception.Message -ForegroundColor Red
        Write-Log
        Return
    }

    # Return ForestFQDN
    Write-Log "ForestFQDN Name is: $($ForestFQDN.Name)" -ForegroundColor Green
    Return $ForestFQDN
}

<#
    .SYNOPSIS
        Validate that the domains in the obtained Forest FQDN are reachable

    .DESCRIPTION
        Validate that all of the domains in the obtained Forest FQDN are reachable by attempting
        to retrieve DomainGuid and DomainDN. Account (Domain\Username) and Password may be requested.

    .PARAMETER Forest
        Target forest.

    .PARAMETER RunWithCurrentlyLoggedInUserCredentials
        The function will use the credentials of the user that is currently logged in the computer, rather than
        requesting custom credentials from the user.

    .PARAMETER ForestFQDN
        Target ForestFQDN Object.

    .EXAMPLE
       Confirm-ValidDomains -Forest "test.contoso.com" -Verbose

    .EXAMPLE
       Confirm-ValidDomains -Forest "test.contoso.com" -RunWithCurrentlyLoggedInUserCredentials -Verbose

    .EXAMPLE
       Confirm-ValidDomains -ForestFQDN $ForestFQDN -RunWithCurrentlyLoggedInUserCredentials -Verbose

#>
Function Confirm-ValidDomains
{
    [CmdletBinding()]
    Param(
        [Parameter(ParameterSetName='SamAccount')]
        [string] $Forest,

        [Parameter(ParameterSetName='ForestFQDN', Mandatory=$True)]
        [System.DirectoryServices.ActiveDirectory.Forest] $ForestFQDN,

        [switch] $RunWithCurrentlyLoggedInUserCredentials
    )

    Write-Log "Proceeding to validate that at least one of the domains associated to the obtained Forest FQDN are reachable" -ForegroundColor Yellow
    Write-Log "by attempting to retrieve DomainGuid and DomainDistinguishedName" -ForegroundColor Yellow

    $paramSetName = $PSCmdlet.ParameterSetName

    If($paramSetName -eq 'SamAccount')
    {
        If($RunWithCurrentlyLoggedInUserCredentials)
        {
            $ForestFQDN = Get-ForestFQDN -Forest $Forest -RunWithCurrentlyLoggedInUserCredentials -Verbose
        }
        Else
        {
            $ForestFQDN = Get-ForestFQDN -Forest $Forest -Verbose
        }
    }

    # Initializing the list that will contain the valid domains.
    $ReachableDomains = New-Object -TypeName 'System.Collections.Generic.List[string]'
    $UnreachableDomains = New-Object -TypeName 'System.Collections.Generic.List[string]'

    # Traverse through all the domains in the forest do determine which are reachable.
    ForEach($Domain in $ForestFQDN.Domains)
    {
        Write-Log "Currently validating Domain: $($Domain.Name)"
        Try
        {
            # Attempt to obtain DomainGuid and DomainDistinguishedName. In case of error, the Domain is not reachable.
            $DirectoryEntry = $Domain.GetDirectoryEntry()
            $DomainGuid = $DirectoryEntry.Guid.ToString()
            $DomainDistinguishedName = $DirectoryEntry.Properties["distinguishedName"].Value.ToString()

            $Name = $DirectoryEntry.Properties["name"].Value.ToString()
            Write-Log "Using $Name to validate domain $($Domain.Name)"

            $ReachableDomains.Add($Domain)
            Write-Log "Successfully examined domain: $($Domain.Name); GUID:$DomainGuid  DN:$DomainDistinguishedName"
        }
        Catch
        {
            $UnreachableDomains.Add($Domain)
            Write-Log "Unable to reach domain: $($Domain.Name)"
        }
    }

    # Having 1 or more reachable domains is fine. Having 0 is not.
    Write-Log "There are $($ReachableDomains.Count) reachable domain(s) and $($UnreachableDomains.Count) unreachable domain(s)"

    If($ReachableDomains.Count -eq 0)
    {
        Write-Log "There are no reachable domains." -ForegroundColor Red
        Write-Log
        Return
    }
    Else
    {
        Write-Log "There are valid domains" -ForegroundColor Green
        Return $True
    }
}

<#
    .SYNOPSIS
        Verifies AD forest functional level.

    .DESCRIPTION
        Verifies that the AD forest functional level is equal or more than a given MinAdForestVersion
        (WindowsServer2003). Account (Domain\Username) and Password may be requested.

    .PARAMETER Forest
        Target forest. Default value is the Forest of the currently logged in user.

    .PARAMETER RunWithCurrentlyLoggedInUserCredentials
        The function will use the credentials of the user that is currently logged in the computer, rather than
        requesting custom credentials from the user.

    .PARAMETER ForestFQDN
        Target ForestFQDN Object.

    .EXAMPLE
        Confirm-FunctionalLevel -Forest "test.contoso.com"

    .EXAMPLE
        Confirm-FunctionalLevel -Forest "test.contoso.com" -RunWithCurrentlyLoggedInUserCredentials -Verbose

    .EXAMPLE
        Confirm-FunctionalLevel -ForestFQDN $ForestFQDN -RunWithCurrentlyLoggedInUserCredentials -Verbose
#>
Function Confirm-FunctionalLevel
{
    [CmdletBinding()]
    Param(
        [Parameter(ParameterSetName='SamAccount', Mandatory=$True)]
        [string] $Forest,

        [Parameter(ParameterSetName='ForestFQDN', Mandatory=$True)]
        [System.DirectoryServices.ActiveDirectory.Forest] $ForestFQDN,

        [switch] $RunWithCurrentlyLoggedInUserCredentials
    )

    Write-Log "Verifying that the AD forest functional level is >= $MinAdForestVersion" -ForegroundColor Yellow

    $paramSetName = $PSCmdlet.ParameterSetName

    If($paramSetName -eq 'SamAccount')
    {
        If($RunWithCurrentlyLoggedInUserCredentials)
        {
            $ForestFQDN = Get-ForestFQDN -Forest $Forest -RunWithCurrentlyLoggedInUserCredentials -Verbose
        }
        Else
        {
            $ForestFQDN = Get-ForestFQDN -Forest $Forest -Verbose
        }
    }

    # Retrieve CurrentForestLevel
    $CurrentForestLevel = $ForestFQDN.ForestMode
    Write-Log "CurrentForestLevel is $CurrentForestLevel"

    # Newer versions of Windows will return a forest functional level of -1 (Unknown). In this case, we should return
    # true since it is NOT an indication that functional level is below the minimum level.
    If($CurrentForestLevel -eq -1)
    {
        Write-Log "The Active Directory forest functional level is correct" -ForegroundColor Green
        Return $True
    }

    If($CurrentForestLevel -lt $MinAdForestVersion)
    {
        Write-Log "Current forest functional level ($CurrentForestLevel) is not supported."
        Write-Log
        Write-Log "WHAT TO TRY NEXT:" -ForegroundColor Yellow
        Write-Log
        Write-Log "`t Upgrade your forest to at least $MinAdForestVersion. More information: https://go.microsoft.com/fwlink/?linkid=875541" -ForegroundColor Yellow
        Return $False
    }

    Write-Log "The Active Directory forest functional level is correct" -ForegroundColor Green
    Return $True
}

<#
    .SYNOPSIS
        Main function.

    .DESCRIPTION
        Runs all the available mechanisms that verify AD credentials are valid.

    .PARAMETER Forest
        Target forest.

    .PARAMETER AutoCreateConnectorAccount
        For Custom-installations:
            Flag that is $True if the user chose "Create new AD account" on the AD Forest Account window of AADConnect's
            wizard. $False if the user chose "Use existing AD account".
        For Express-installations:
            The value of this variable must be $True for Express-installations.

    .PARAMETER Username
        Parameter that pre-populates the Username field when user's credentials are requested.

    .PARAMETER RunWithCurrentlyLoggedInUserCredentials
        The function will use the credentials of the user that is currently logged in the computer, rather than
        requesting custom credentials from the user.

    .EXAMPLE
        Start-ConnectivityValidation -Forest "test.contoso.com" -AutoCreateConnectorAccount $True -Verbose

#>
Function Start-ConnectivityValidation
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [string] $Forest,

        [Parameter(Mandatory=$True)]
        [bool] $AutoCreateConnectorAccount,

        [Parameter(Mandatory=$False)]
        [string] $UserName
    )

    # Step 1 - Get user's credentials.
    If ($AutoCreateConnectorAccount)
    {
        $Script:Credentials = Get-CredentialsFromPowerShellWindow -Message "Please provide the credentials of the Enterprise Administrator account you entered on AADConnect Wizard." -UserName $UserName
    }
    Else
    {
        $Script:Credentials = Get-CredentialsFromPowerShellWindow -Message "Please provide the credentials of the account you entered on AADConnect Wizard." -UserName $UserName
    }

    Write-Log
    Write-Log
    Write-Log "Diagnosis is starting..."
    Write-Log
    Write-Progress -Activity "ADconnectivityTool" -PercentComplete (1/6 * 100)

    # Step 2 - GetDomainFQDN Name
    $DomainFQDNName = Get-DomainFQDNData -DomainFQDNDataType DomainFQDNName -Verbose
    If (-not $DomainFQDNName)
    {
        Write-Progress -Activity "ADconnectivityTool" -Completed
        Start-NetworkConnectivityDiagnosisTools -DisplayInformativeMessage -Forest $Forest -Credentials $Script:Credentials
        Return
    }
    Write-Log
    Write-Log
    Write-Progress -Activity "ADconnectivityTool" -PercentComplete (2/6 * 100)

    # Step 3 - If applicable, validate the provided credentials belong to the EA group.
    If ($AutoCreateConnectorAccount)
    {
        $ValidEACredentials = Confirm-ValidEnterpriseAdminCredentials -Verbose
        If (-not $ValidEACredentials)
        {
            Write-Progress -Activity "ADconnectivityTool" -Completed
            Return
        }
    }
    Else
    {
        Write-Log "Skipping step to verify provided credentials belong to Enterprise Admins group" -ForegroundColor DarkGreen
    }
    Write-Log
    Write-Log
    Write-Progress -Activity "ADconnectivityTool" -PercentComplete (3/6 * 100)

    # Step 4 - Obtain ForestFQDN object.
    $ForestFQDN = Get-ForestFQDN -Forest $Forest -Verbose
    If (-not $ForestFQDN)
    {
        Write-Progress -Activity "ADconnectivityTool" -Completed
        Start-NetworkConnectivityDiagnosisTools -DisplayInformativeMessage -Forest $Forest -Credentials $Script:Credentials
        Return
    }
    Write-Log
    Write-Log
    Write-Progress -Activity "ADconnectivityTool" -PercentComplete (4/6 * 100)

    # Step 5 - Confirm the domains associated with the ForestFQDN object are reachable.
    $ValidDomainsInForestFQDN = Confirm-ValidDomains -ForestFQDN $ForestFQDN -Verbose
    If (-not $ValidDomainsInForestFQDN)
    {
        Write-Progress -Activity "ADconnectivityTool" -Completed
        Start-NetworkConnectivityDiagnosisTools -DisplayInformativeMessage -Forest $Forest -Credentials $Script:Credentials
        Return
    }
    Write-Log
    Write-Log
    Write-Progress -Activity "ADconnectivityTool" -PercentComplete (5/6 * 100)

    # Step 6 - Verify that the functional level is more or greater that the minimum required.
    $ValidFunctionalLevel = Confirm-FunctionalLevel -ForestFQDN $ForestFQDN -Verbose
    If (-not $ValidFunctionalLevel)
    {
        Write-Progress -Activity "ADconnectivityTool" -Completed
        Return
    }
    Write-Log
    Write-Log
    Write-Progress -Activity "ADconnectivityTool" -Completed

    Write-Log "ALL CONNECTIVITY TESTS HAVE PASSED. PLEASE GO BACK TO AADCONNECT INSTALLATION WIZARD AND PROVIDE YOUR CREDENTIALS AGAIN." -ForegroundColor Magenta
    Write-Log
}

#endregion

#region Global Utilities

# Auxiliary function to request username\password from the PowerShell window
Function Get-CredentialsFromPowerShellWindow
{
    Param(
        [Parameter(Mandatory=$False)]
        [string] $Message = "Retrieving user's credentials.",

        [Parameter(Mandatory=$False)]
        [string] $UserName
    )

    Write-Log $Message -ForegroundColor Yellow

    If(-not $UserName)
    {
        $UserName = Read-Host "DOMAIN\Username"
    }
    Else
    {
        Write-Log "DOMAIN\Username: $UserName  (previously obtained)"
    }
    $Password = Read-Host "Password" -AsSecureString

    $Credentials = New-Object System.Management.Automation.PSCredential ($UserName, $Password)

    Return $Credentials
}

# Function that retrieves user credentials and makes them available for the whole module.
Function Get-AccountAndPassword
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$False)]
        [System.Management.Automation.PSCredential] $Credentials
    )

    If(-not $Script:Credentials)
    {
        If($Credentials)
        {
            $Script:Credentials = $Credentials
        }
        Else
        {
            $Script:Credentials = Get-CredentialsFromPowerShellWindow
        }
    }
}

#Auxiliary Function that writes an output to a log file or the PowerShell window
Function Write-Log {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$False, Position=1)]
        [string] $Message,

        [Parameter(Mandatory=$False, Position=2)]
        [string] $ForegroundColor = "Cyan"
    )
    Switch ($ForegroundColor)
    {
        Green { $Severity = "SUCCESS" }
        Red { $Severity = "ERROR  " }
        Default { $Severity = "INFO   " }
    }
    If($LogFileLocation)
    {
        If($Message -ne "")
        {
            $Message = "[" + (Get-Date).ToString() + "] [$Severity] " + $Message
            Out-File -Append -FilePath $LogFileLocation -InputObject $Message
        }
    }
    Else
    {
        Write-Host $Message -ForegroundColor $ForegroundColor
    }
}

#endregion

Export-ModuleMember -Function Get-DomainFQDNData
Export-ModuleMember -Function Confirm-ValidEnterpriseAdminCredentials
Export-ModuleMember -Function Get-ForestFQDN
Export-ModuleMember -Function Confirm-ValidDomains
Export-ModuleMember -Function Confirm-FunctionalLevel
Export-ModuleMember -Function Confirm-NetworkConnectivity
Export-ModuleMember -Function Confirm-DnsConnectivity
Export-ModuleMember -Function Confirm-TargetsAreReachable
Export-ModuleMember -Function Confirm-ForestExists
Export-ModuleMember -Function Start-ConnectivityValidation
Export-ModuleMember -Function Start-NetworkConnectivityDiagnosisTools
# SIG # Begin signature block
# MIInnwYJKoZIhvcNAQcCoIInkDCCJ4wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAt7IxQyufApPfY
# N8RkQiriIa/jbR95CpyuSnUzwrZgbqCCDYIwggYAMIID6KADAgECAhMzAAADXJXz
# SFtKBGrPAAAAAANcMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwNDA2MTgyOTIyWhcNMjQwNDAyMTgyOTIyWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDijA1UCC84R0x+9Vr/vQhPNbfvIOBFfymE+kuP+nho3ixnjyv6vdnUpgmm6RT/
# pL9cXL27zmgVMw7ivmLjR5dIm6qlovdrc5QRrkewnuQHnvhVnLm+pLyIiWp6Tow3
# ZrkoiVdip47m+pOBYlw/vrkb8Pju4XdA48U8okWmqTId2CbZTd8yZbwdHb8lPviE
# NMKzQ2bAjytWVEp3y74xc8E4P6hdBRynKGF6vvS6sGB9tBrvu4n9mn7M99rp//7k
# ku5t/q3bbMjg/6L6mDePok6Ipb22+9Fzpq5sy+CkJmvCNGPo9U8fA152JPrt14uJ
# ffVvbY5i9jrGQTfV+UAQ8ncPAgMBAAGjggF/MIIBezArBgNVHSUEJDAiBgorBgEE
# AYI3TBMBBgorBgEEAYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUXgIsrR+tkOQ8
# 10ekOnvvfQDgTHAwRQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEWMBQGA1UEBRMNMjMzMTEwKzUwMDg2ODAfBgNVHSMEGDAWgBRI
# bmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEt
# MDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBABIm
# T2UTYlls5t6i5kWaqI7sEfIKgNquF8Ex9yMEz+QMmc2FjaIF/HQQdpJZaEtDM1Xm
# 07VD4JvNJEplZ91A4SIxjHzqgLegfkyc384P7Nn+SJL3XK2FK+VAFxdvZNXcrkt2
# WoAtKo0PclJOmHheHImWSqfCxRispYkKT9w7J/84fidQxSj83NPqoCfUmcy3bWKY
# jRZ6PPDXlXERRvl825dXOfmCKGYJXHKyOEcU8/6djs7TDyK0eH9ss4G9mjPnVZzq
# Gi/qxxtbddZtkREDd0Acdj947/BTwsYLuQPz7SNNUAmlZOvWALPU7OOVQlEZzO8u
# Ec+QH24nep/yhKvFYp4sHtxUKm1ZPV4xdArhzxJGo48Be74kxL7q2AlTyValLV98
# u3FY07rNo4Xg9PMHC6sEAb0tSplojOHFtGtNb0r+sioSttvd8IyaMSfCPwhUxp+B
# Td0exzQ1KnRSBOZpxZ8h0HmOlMJOInwFqrCvn5IjrSdjxKa/PzOTFPIYAfMZ4hJn
# uKu15EUuv/f0Tmgrlfw+cC0HCz/5WnpWiFso2IPHZyfdbbOXO2EZ9gzB1wmNkbBz
# hj8hFyImnycY+94Eo2GLavVTtgBiCcG1ILyQabKDbL7Vh/OearAxcRAmcuVAha07
# WiQx2aLghOSaZzKFOx44LmwUxRuaJ4vO/PRZ7EzAMIIHejCCBWKgAwIBAgIKYQ6Q
# 0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5
# WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQD
# Ex9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4
# BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe
# 0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato
# 88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v
# ++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDst
# rjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN
# 91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4ji
# JV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmh
# D+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbi
# wZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8Hh
# hUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaI
# jAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTl
# UAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNV
# HQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQF
# TuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29m
# dC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNf
# MjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNf
# MjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnlj
# cHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5
# AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oal
# mOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0ep
# o/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1
# HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtY
# SWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInW
# H8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZ
# iWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMd
# YzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7f
# QccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKf
# enoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOpp
# O6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZO
# SEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGXMwghlvAgEBMIGVMH4xCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jv
# c29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAANclfNIW0oEas8AAAAAA1ww
# DQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII8dHtiJ
# lo+J06U60HZSWvx1LZpabc25LmI0RS3NbH0nMEIGCisGAQQBgjcCAQwxNDAyoBSA
# EgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20w
# DQYJKoZIhvcNAQEBBQAEggEApYKOAupKIWNpa4msgQh9Z5jbSyH6r2ahBsbR11XD
# pk37HbSIxpdombgJdbLZbuODLdOumzQyjZ1J4rOO6GA7AgJQBZEHdSfMFdk0cLw/
# ULJJnUoS1ZtFSSNOfQA3jNrXIfRJUb4QS2QyYTjmK9LbWUEHz6A1uV8L83RpT8ex
# BvRPPfUqYAgqZQWz4B551w+LhaRL56D+Z1hNeTqsQaLioDKd6wJLEqFHftC0LU0j
# mJrQ2J8IEiXKPfg3C/cJoeMiyn3qXjghGOmT+O4tkbqLxAJ7cCceIXZKf/BJeVIW
# pchFEkrf+wnrOvhjwii8Ax4UbBuq6WTLWr2cyDl+ElZMsKGCFv0wghb5BgorBgEE
# AYI3AwMBMYIW6TCCFuUGCSqGSIb3DQEHAqCCFtYwghbSAgEDMQ8wDQYJYIZIAWUD
# BAIBBQAwggFRBgsqhkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoD
# ATAxMA0GCWCGSAFlAwQCAQUABCDec/YDj2OGNRjBoyv7cosevzZNpgxVwvnW9DhA
# Jrv2eAIGZFzVBrDhGBMyMDIzMDUxNzIyNTUzMS4yNTNaMASAAgH0oIHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjpERDhDLUUzMzctMkZBRTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaCCEVQwggcMMIIE9KADAgECAhMzAAABxQPNzSGh9O85AAEAAAHF
# MA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4X
# DTIyMTEwNDE5MDEzMloXDTI0MDIwMjE5MDEzMlowgcoxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNh
# IE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkREOEMtRTMzNy0y
# RkFFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjAN
# BgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAq0hds70eX23J7pappaKXRhz+TT7J
# J3OvVf3+N8fNpxRs5jY4hEv3BV/w5EWXbZdO4m3xj01lTI/xDkq+ytjuiPe8xGXs
# ZxDntv7L1EzMd5jISqJ+eYu8kgV056mqs8dBo55xZPPPcxf5u19zn04aMQF5PXV/
# C4ZLSjFa9IFNcribdOm3lGW1rQRFa2jUsup6gv634q5UwH09WGGu0z89RbtbyM55
# vmBgWV8ed6bZCZrcoYIjML8FRTvGlznqm6HtwZdXMwKHT3a/kLUSPiGAsrIgEzz7
# NpBpeOsgs9TrwyWTZBNbBwyIACmQ34j+uR4et2hZk+NH49KhEJyYD2+dOIaDGB2E
# UNFSYcy1MkgtZt1eRqBB0m+YPYz7HjocPykKYNQZ7Tv+zglOffCiax1jOb0u6IYC
# 5X1Jr8AwTcsaDyu3qAhx8cFQN9DDgiVZw+URFZ8oyoDk6sIV1nx5zZLy+hNtakeP
# X9S7Y8n1qWfAjoXPE6K0/dbTw87EOJL/BlJGcKoFTytr0zPg/MNJSb6f2a/wDkXo
# GCGWJiQrGTxjOP+R96/nIIG05eE1Lpky2FOdYMPB4DhW7tBdZautepTTuShmgn+G
# KER8AoA1gSSk1EC5ZX4cppVngJpblMBu8r/tChfHVdXviY6hDShHwQCmZqZebgSY
# HnHl4urE+4K6ZC8CAwEAAaOCATYwggEyMB0GA1UdDgQWBBRU6rs4v1mxNYG/rtpL
# wrVwek0FazAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8E
# WDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9N
# aWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYB
# BQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEw
# KDEpLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqG
# SIb3DQEBCwUAA4ICAQCMqN58frMHOScciK+Cdnr6dK8fTsgQDeZ9bvQjCuxNIJZJ
# 92+xpeKRCf3Xq47qdRykkKUnZC6dHhLwt1fhwyiy/LfdVQ9yf1hYZ/RpTS+z0hna
# oK+P/IDAiUNm32NXLhDBu0P4Sb/uCV4jOuNUcmJhppBQgQVhFx/57JYk1LCdjIee
# //GrcfbkQtiYob9Oa93DSjbsD1jqaicEnkclUN/mEm9ZsnCnA1+/OQDp/8Q4cPfH
# 94LM4J6X0NtNBeVywvWH0wuMaOJzHgDLCeJUkFE9HE8sBDVedmj6zPJAI+7ozLjY
# qw7i4RFbiStfWZSGjwt+lLJQZRWUCcT3aHYvTo1YWDZskohWg77w9fF2QbiO9Dfn
# qoZ7QozHi7RiPpbjgkJMAhrhpeTf/at2e9+HYkKObUmgPArH1Wjivwm1d7PYWsar
# L7u5qZuk36Gb1mETS1oA2XX3+C3rgtzRohP89qZVf79lVvjmg34NtICK/pMk99SB
# utghtipFSMQdbXUnS2oeLt9cKuv1MJu+gJ83qXTNkQ2QqhxtNRvbE9QqmqJQw5VW
# /4SZze1pPXxyOTO5yDq+iRIUubqeQzmUcCkiyNuCLHWh8OLCI5mIOC1iLtVDf2lw
# 9eWropwu5SDJtT/ZwqIU1qb2U+NjkNcj1hbODBRELaTTWd91RJiUI9ncJkGg/jCC
# B3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAw
# gYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMT
# KU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIx
# MDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57Ry
# IQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VT
# cVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhx
# XFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQ
# HJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1
# KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s
# 4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUg
# fX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3
# Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je
# 1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUY
# hEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUY
# P3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGC
# NxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4w
# HQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYB
# BAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcD
# CDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0T
# AQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNV
# HR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9w
# cm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEE
# TjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOC
# AgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/a
# ZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp
# 4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq
# 95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qB
# woEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG
# +jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3B
# FARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77
# IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJ
# fn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K
# 6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDx
# yKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLLMIICNAIBATCB
# +KGB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEl
# MCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMd
# VGhhbGVzIFRTUyBFU046REQ4Qy1FMzM3LTJGQUUxJTAjBgNVBAMTHE1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVACEAGvYXZJK7cUo6
# 2+LvEYQEx7/noIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAw
# DQYJKoZIhvcNAQEFBQACBQDoDzt5MCIYDzIwMjMwNTE3MTkzOTM3WhgPMjAyMzA1
# MTgxOTM5MzdaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIFAOgPO3kCAQAwBwIBAAIC
# JlowBwIBAAICVCswCgIFAOgQjPkCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYB
# BAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOB
# gQAod9dxSGcVPcJFw9uXD6Sgl+ckUKHTqRBX8yFEDvoDpMNdHTdG/+r1rhX6itQ0
# EiM5X5JQ5B5G3lKxEuJaCoetNdEKCs2WYYJBU7Uu4dPG2ctG3mUk9QX3KtsYns9j
# gJao5Gad+72HZAglNQJ7iOtKlHjutjbT3UJhzIV4OfMUuzGCBA0wggQJAgEBMIGT
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABxQPNzSGh9O85AAEA
# AAHFMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQ
# AQQwLwYJKoZIhvcNAQkEMSIEIFf95pd3d8FJyAqSXyx89wmgdDg83NraDpQlVksU
# rGj1MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgGQGxkfYkd0wK+V09wO0s
# O+sm8gAMyj5EuKPqvNQ/fLEwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAcUDzc0hofTvOQABAAABxTAiBCBwYugKFVKYVjoe+yb+rUyO
# cC01pxRTB+vR3wl7l3zeojANBgkqhkiG9w0BAQsFAASCAgA98tSvmZTcrrx8O7uB
# L0D3VCKFdvdLPMCb5LOcY8C+wyL3T1xPUIdzase5YuHmPR0uVPOggIPv6pjS+w4R
# cY8FtD98dZqdiE1AnxD8ORncaNYdUpkRFxjTyUjzqEdZ+gz/Y4esPpd2JUSv26Ay
# BqSl9a9HiZekhaf6+jbvIH5UfpK4YKS9HTV1CIYVUrOyIwda1Jp7Wn52HXv2BBFX
# z5xrvj/pdjyApvEWrFPUyefr7nA645JMDmuMxMRBOyU9pr/0GdTH7t1uCTOh/mYN
# MToEfsi8lZb9k0nY4z531XAcz8X5Hf9mZ1jW/5D8dcA5mF7WXMprsv8EUr7p25C/
# jdrTd2ZBViad9FS/1RtRzMYAwMokmQy0NvAloyYoow1e6eKzJ3Ke9Kagw8lyehrX
# uUDSKLdlRbpfi38QwJ4pHneTKV5kRJuaRzIWJx1Nq3k2k//o8JI0CsMRZ1oBz6is
# fOBxc/Y9vnTT/2gjkoxAgw2L2TJ0Imqcacd7tjDdUkE3Y3VYoDdQP5FdIlWu5r7f
# 0974Fpd+6oI918XuUCM2dOZHFMUKbyQtUHXvVOOz/idWOVzjNl7TJP2tCSrVXzDY
# Or0iO7jmDoPaa+R9yC3KYVLxv486huZmu5SxV5yCkj5+o8RusLUzMvbBLq5Btx2E
# AJQYolWYOBMRk4h9ltW/4ve43w==
# SIG # End signature block
