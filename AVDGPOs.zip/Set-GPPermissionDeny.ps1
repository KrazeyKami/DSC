﻿function Set-GPPermissionDeny {
Param(
    [STRING]$GroupName,
    [STRING]$GpoName
)


    $Domain = (Get-ADDomain).NetbiosName
    $DomainDN = (Get-ADDomain).DistinguishedName
    $Account = ('{0}\{1}' -f $Domain, $GroupName)
    $GPO = Get-GPO -Name $GpoName

    if (![STRING]::IsNullOrWhiteSpace($Domain) -and ![STRING]::IsNullOrWhiteSpace($Account) -and ![STRING]::IsNullOrWhiteSpace($GpoName))
    {
        Write-Host ('Permissions set for GPO: {0} => ' -f $GPO.DisplayName) -NoNewline

        $ADGpo = [ADSI]"LDAP://CN=`{$($GPO.Id.guid)`},CN=Policies,CN=System,$($DomainDN)"

        $Rule = New-Object System.DirectoryServices.ActiveDirectoryAccessRule(
                [System.Security.Principal.NTAccount]$Account,
                "ExtendedRight",
                "Deny",
                [Guid]"edacfd8f-ffb3-11d1-b41d-00a0c968f939"
            )

        $acl = $ADGpo.ObjectSecurity
        $acl.AddAccessRule($Rule)
        try {
            $ADGpo.CommitChanges()
            Write-Host 'successfull' -ForegroundColor Green
            
        } catch {
            Write-Host 'failed' -ForegroundColor Red
        }
    } else {
        'Something went wrong...'
    }
}