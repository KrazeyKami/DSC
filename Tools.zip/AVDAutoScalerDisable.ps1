Function Set-AVDHostPoolAutoScaling {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [string]$ScalingPlanName,
        [Parameter(Mandatory = $true)]
        [string]$HostPoolResourceId,
        [Parameter(Mandatory = $true)]
        [bool]$EnableAutoScale

    )
    Begin {

        #To be filled later if needed

    }

    Process {

        Update-AzWvdScalingPlan `
            -ResourceGroupName $ResourceGroupName `
            -Name $ScalingPlanName `
            -HostPoolReference @(
            @{
                'hostPoolArmPath'    = $HostPoolResourceId;
                'scalingPlanEnabled' = $EnableAutoScale;
            }
        ) `
    
    }
}