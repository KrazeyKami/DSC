$SubscriptionID = "06041922-b293-4053-8469-fa2c18138bb5"
# Get Token for UAI
$response = Invoke-WebRequest -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fmanagement.azure.com%2F' -Headers @{Metadata="true"}
$content = $response.Content | ConvertFrom-Json
$ArmToken = $content.access_token

#Connect to Az using UAI:
Connect-AzAccount -Identity
Select-AzSubscription "06041922-b293-4053-8469-fa2c18138bb5" | Set-AzContext

$ResourceGroupName = "rg-09000-aa10a1-prod-weu-1"
$ScalingPlanName = "vdscaling-09000-aa10a1-prod-weu-1"
$HostPoolName = "vdpool-09000-aa10a1-prod-weu-1"
$HostPoolResourceId = "/subscriptions/$SubscriptionID/resourceGroups/$ResourceGroupName/providers/Microsoft.DesktopVirtualization/hostpools/$HostPoolName"
$EnableAutoScale = $false
import-module C:\temp\AVDAutoScalerDisable.ps1
Set-AVDHostPoolAutoScaling -ResourceGroupName $ResourceGroupName -ScalingPlanName $ScalingPlanName -HostPoolResourceId $HostPoolResourceId -EnableAutoScale $EnableAutoScale
$AVDHosts = Get-AZVM -status 
foreach ($avdhost in $AVDHosts)
{
   if ($avdhost.PowerState -ne "VM running")
   {
    write-output "Starting session host " $avdhost.Name
    $params = @{
    ResourceGroupName = $ResourceGroupName
    HostPoolName = $HostPoolName
    Name = $avdhost.Name
    AllowNewSession = $False
    }
    Update-AzWvdSessionHost @params
    Start-AzVM -Name $avdhost.Name -ResourceGroupName $ResourceGroupName
   }
}