Start-Sleep 60
Get-ChildItem C:\Users -recurse | where-object {$_.Name -like "Microsoft Edge*"} | where-object {$_.Name-notlike "Microsoft Edge.lnk"} | Remove-Item -erroraction Ignore -Confirm $true