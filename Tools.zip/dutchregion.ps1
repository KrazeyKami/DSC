$language = "nl-NL"
$geoId = "176" 
Set-WinUILanguageOverride -Language $language -ErrorAction ignore
$OldList = Get-WinUserLanguageList
$UserLanguageList = New-WinUserLanguageList -Language $language
$UserLanguageList += $OldList | where { $_.LanguageTag -ne $language }
$UserLanguageList | select LanguageTag
Set-WinUserLanguageList -LanguageList $UserLanguageList -Force -ErrorAction ignore
Set-Culture -CultureInfo $language -ErrorAction ignore
Set-WinHomeLocation -GeoId $geoId -ErrorAction ignore
Set-WinDefaultInputMethodOverride "0413:00020409"
Copy-UserInternationalSettingsToSystem -WelcomeScreen $True -NewUser $True -ErrorAction ignore


"$(get-date) - $env:computername Region Config parameters" | out-file c:\temp\AVDSettings.txt -Append
"$(get-date) - $env:computername WhoAmI" | out-file c:\temp\AVDSettings.txt -Append
whoami | out-file c:\temp\AVDSettings.txt -Append
"$(get-date) - $env:computername Get-WinUILanguageOverride" | out-file c:\temp\AVDSettings.txt -Append
Get-WinUILanguageOverride | out-file c:\temp\AVDSettings.txt -Append
"$(get-date) - $env:computername Get-WinUserLanguageList" | out-file c:\temp\AVDSettings.txt -Append
Get-WinUserLanguageList | out-file c:\temp\AVDSettings.txt -Append
"$(get-date) - $env:computername Get-Culture" | out-file c:\temp\AVDSettings.txt -Append
Get-Culture | out-file c:\temp\AVDSettings.txt -Append
"$(get-date) - $env:computername Get-WinHomeLocation" | out-file c:\temp\AVDSettings.txt -Append
Get-WinHomeLocation | out-file c:\temp\AVDSettings.txt -Append
"$(get-date) - $env:computername Get-WinDefaultInputMethodOverride" | out-file c:\temp\AVDSettings.txt -Append
Get-WinDefaultInputMethodOverride | out-file c:\temp\AVDSettings.txt -Append