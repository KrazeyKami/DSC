get-childitem cert:\localmachine\my | where-object {$_.Subject -like "*CN=DscEncryptionCert*"} | remove-item

$cert = New-SelfSignedCertificate -Type DocumentEncryptionCertLegacyCsp -DnsName 'DscEncryptionCert' -HashAlgorithm SHA256
$cert | Export-Certificate -FilePath "C:\TEMP\DscPublicKey.cer" -Force

$Thumbprint = (get-childitem cert:\localmachine\my | where-object {$_.Subject -like "*CN=DscEncryptionCert*"}).Thumbprint


$ConfigData= @{ 
    AllNodes = @(     
            @{   
                NodeName = "localhost" 

                CertificateFile = "C:\TEMP\DscPublicKey.cer" 

                Thumbprint = $Thumbprint 
            }; 
        );    
    }


Configuration AddSessionHost {
	
param
    (
        [Parameter(Mandatory = $true)]
        [string]$HostPoolName,
		
		[Parameter(Mandatory)]
        [String]$repoLoc,	
		
		[Parameter(Mandatory)]
        [String]$dlM365LanguagePack,	
		
		[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,
		
		[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$hybridAdminCreds,
				
		[Parameter(Mandatory)]
        [String]$DCName,
		
		[Parameter(Mandatory)]
        [String]$DomainName,
		
		[Parameter(Mandatory)]
        [String]$SGFSContributorGroups,
		
		[Parameter(Mandatory)]
        [String]$SGFSEleContributorGroups,
		
		[Parameter(Mandatory)]
        [String]$SGAVDHostpoolDAG,		
		
		[Parameter(Mandatory)]
        [String]$workspaceResourceGroup,
		
		[Parameter(Mandatory)]
        [String]$LanguageLocale,		

        [Parameter(Mandatory = $true)]
        [string]$RegistrationInfoToken,

        [Parameter(Mandatory = $false)]
        [bool]$AadJoin = $false,

        [Parameter(Mandatory = $false)]
        [bool]$AadJoinPreview = $false,

        [Parameter(Mandatory = $false)]
        [string]$MdmId = "",

        [Parameter(Mandatory = $false)]
        [string]$SessionHostConfigurationLastUpdateTime = "",

        [Parameter(Mandatory = $false)]
        [bool]$EnableVerboseMsiLogging = $false,
        
        [Parameter(Mandatory = $false)]
        [bool]$UseAgentDownloadEndpoint = $false	
    )

    $ErrorActionPreference = 'Stop'
    
    $ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)
    . (Join-Path $ScriptPath "Functions.ps1")

    $rdshIsServer = isRdshServer
		
	$clearUserAdmin = $AdminCreds.GetNetworkCredential().username
	$clearPassAdmin = $AdminCreds.GetNetworkCredential().password | Protect-CmsMessage -To $Thumbprint

	$clearUserAzure = $hybridAdminCreds.GetNetworkCredential().username
	$clearPassAzure = $hybridAdminCreds.GetNetworkCredential().password | Protect-CmsMessage -To $Thumbprint	
	
	Import-DscResource -ModuleName xPSDesiredStateConfiguration
	
 
    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
			ConfigurationMode = "ApplyOnly"
			CertificateId = $Thumbprint 	
       
        }
		
		Script InvokeSAJoin
			{
				GetScript = 
				{
				   Return $@{}
				}
			  
				SetScript =
				{			
						$HostPoolName0 = $using:HostPoolName
						$workspaceResourceGroup0 = $using:workspaceResourceGroup
						$DCName2 = $using:DCName	
						
						$clearUserAdmin1 = $using:clearUserAdmin
						$clearPassAdmin1 = Unprotect-CmsMessage -Content $using:clearPassAdmin

						$User2 = $clearUserAdmin1
						$PWord2 = ConvertTo-SecureString -String $clearPassAdmin1 -AsPlainText -Force
						$Credential2 = New-Object System.Management.Automation.PSCredential($User2,$PWord2)
				
						$ps = New-PSSession -ComputerName $DCName2 -Credential $Credential2
						$clearUserAzure0 = $using:clearUserAzure
						$clearPassAzure0 = Unprotect-CmsMessage -Content $using:clearPassAzure
						$DomainName1 = $using:DomainName
						$MyHostName = $using:env:computername
						$AllHosts += $using:env:computername
						
						$parameters = @{						
							Session = $ps						
							ScriptBlock  = {
								Param ($param0,$param1,$param2,$param3,$param4,$param5,$param6,$param7,$param8)
								$clearUserAzure0 = $param0
								$clearPassAzure0 = $param1								
								$HostPoolName0 = $param2
								$workspaceResourceGroup0 = $param3
								$clearUserAdmin1 = $param4
								$clearPassAdmin1 = $param5
								$DomainName1 = $param6
								$MyHostName = $param7
								$AllHosts = $param8								
								Start-Sleep -s 5								
								$runOn =($AllHosts | Measure -Minimum).Minimum
								Start-Sleep -s 5
								if (Test-Path C:\Temp\RunOn.txt)
								{}
								else
								{
									$runOn | Out-File "c:\temp\RunOn.txt"	
								}
								
								
							}
							ArgumentList = "$clearUserAzure0","$clearPassAzure0","$HostPoolName0","$workspaceResourceGroup0","$clearUserAdmin1","$clearPassAdmin1","$DomainName1","$MyHostName","$AllHosts"
						}
						Invoke-Command @parameters
							
						$parameters1 = @{					
							Session = $ps					
							ScriptBlock  = {

										
										$whichHost = Get-Content -Path "c:\temp\RunOn.txt"
										if ($whichHost -eq $MyHostName)	
										{				
												$date = get-date 
												$append2log = "$MyHostName -- $date -- Starting SAJoin..."
												$append2log | Out-File -Append "c:\temp\AZJoin&SSO_start.txt"	
																	
											 if (Test-Path C:\Temp\AVDDSC)
											 {		
																			 
												C:\Temp\AVDDSC\JoinStorageAccountToDomain.ps1 -JoinStorageAccountToDomain -JSON -JSONInputPath C:\Temp\AVDDSC\AZFiles.json -ConfigureIAMRoles -ConfigureNTFSPermissions
											 }
										}
										
							}									
						}
						Invoke-Command @parameters1

						$parameters2 = @{					
							Session = $ps					
							ScriptBlock  = {														
								 if (Test-Path C:\Temp\AVDDSC)
								 {		
									
									$whichHost = Get-Content -Path "c:\temp\RunOn.txt"
									if ($whichHost -eq $MyHostName)	
									{					
											$date = get-date 
											$append2log = "$MyHostName -- $date -- Starting Seamless SSO config..."
											$append2log | Out-File -Append "c:\temp\AZJoin&SSO_start.txt"	 						 
										#Checking if AZUREADSSOACC was already joined. 
										try{						 
											$Storage1Present = Get-ADComputer "AZUREADSSOACC"
											if ($Storage1Present -ne $null)
											{	
											
												$User2 = "$DomainName1\$clearUserAdmin1"
												$PWord2 = ConvertTo-SecureString -String $clearPassAdmin1 -AsPlainText -Force
												$Credential2 = New-Object System.Management.Automation.PSCredential($User2,$PWord2)
												$User3 = $clearUserAzure0
												$PWord3 = ConvertTo-SecureString -String $clearPassAzure0 -AsPlainText -Force
												$Credential3 = New-Object System.Management.Automation.PSCredential($User3,$PWord3)
												
												import-module "C:\Temp\AVDDSC\Microsoft Azure Active Directory Connect\AzureADSSO.psd1"
												New-AzureADSSOAuthenticationContext -CloudCredentials $Credential3
													$ssostatus = Get-AzureADSSOStatus
													if (($ssostatus).Contains($DomainName1) -eq 'True')
													{
															$date = get-date 
															$append2log = "$MyHostName -- $date -- SSO Configured for Tenant: $ssostatus"
															$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"					
														
													}
													else
													{
														
															$date = get-date 
															$append2log = "$MyHostName -- $date -- SSO NOT configured for Tenant.... Adding..."
															$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"
															Enable-AzureADSSOForest -OnPremCredentials $Credential2 
															Enable-AzureADSSO -Enable $true
															$ssostatus = Get-AzureADSSOStatus
															$append2log = "$MyHostName -- $date -- SSO Configured for Tenant: $ssostatus"
															$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"	
															
															
															
														
														
													}
												$date = get-date 
												$append2log = "$MyHostName -- $date -- SSO Account already joined...exiting..."
												$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"												
												import-module "C:\Temp\AVDDSC\Microsoft Azure Active Directory Connect\AzureADSSO.psd1"
												New-AzureADSSOAuthenticationContext -CloudCredentials $Credential3 
												$append2log = $Storage1Present
												$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"
												Get-AzureADSSOStatus | Out-File -Append "c:\temp\SSO_Installation.txt"	
												if (Test-Path C:\Temp\RunOn.txt)
												{Remove-Item -Force c:\temp\RunOn.txt}													
												
											}
											else
											{
												
												$date = get-date 
												$append2log = "$MyHostName -- $date -- SSO Account not joined...Starting SSO join..."
												$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"

												$User2 = "$DomainName1\$clearUserAdmin1"
												$PWord2 = ConvertTo-SecureString -String $clearPassAdmin1 -AsPlainText -Force
												$Credential2 = New-Object System.Management.Automation.PSCredential($User2,$PWord2)
												$User3 = $clearUserAzure0
												$PWord3 = ConvertTo-SecureString -String $clearPassAzure0 -AsPlainText -Force
												$Credential3 = New-Object System.Management.Automation.PSCredential($User3,$PWord3)
												
												msiexec /a C:\Temp\AVDDSC\AzureADConnect.msi /qb TARGETDIR=C:\Temp\AVDDSC\ADCC
												import-module "C:\Temp\AVDDSC\Microsoft Azure Active Directory Connect\AzureADSSO.psd1"
												New-AzureADSSOAuthenticationContext -CloudCredentials $Credential3
													$ssostatus = Get-AzureADSSOStatus
													if (($ssostatus).Contains($DomainName1) -eq 'True')
													{
															$date = get-date 
															$append2log = "$MyHostName -- $date -- SSO Configured for Tenant: $ssostatus"
															$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"					
														
													}
													else
													{
														
															$date = get-date 
															$append2log = "$MyHostName -- $date -- SSO NOT configured for Tenant.... Adding..."
															$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"
															Enable-AzureADSSOForest -OnPremCredentials $Credential2 
															Enable-AzureADSSO -Enable $true
															$ssostatus = Get-AzureADSSOStatus
															$append2log = "$MyHostName -- $date -- SSO Configured for Tenant: $ssostatus"
															$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"	
															
															
															
														
														
													}
												$date = get-date 
												$append2log = "$MyHostName -- $date -- SSO Account joined...SSO configured:"
												$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"
												if (Test-Path C:\Temp\RunOn.txt)
												{Remove-Item -Force c:\temp\RunOn.txt}	
												
											}													
										}
										catch{
											$User2 = "$DomainName1\$clearUserAdmin1"
											$PWord2 = ConvertTo-SecureString -String $clearPassAdmin1 -AsPlainText -Force
											$Credential2 = New-Object System.Management.Automation.PSCredential($User2,$PWord2)
											$User3 = $clearUserAzure0
											$PWord3 = ConvertTo-SecureString -String $clearPassAzure0 -AsPlainText -Force
											$Credential3 = New-Object System.Management.Automation.PSCredential($User3,$PWord3)
											
											$date = get-date 
											$append2log = "$MyHostName -- $date -- Catching error.."
											$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"
											$append2log = "$MyHostName -- $date -- SSO Account already joined...exiting..."
											$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"
											import-module "C:\Temp\AVDDSC\Microsoft Azure Active Directory Connect\AzureADSSO.psd1"
											New-AzureADSSOAuthenticationContext -CloudCredentials $Credential3
													$ssostatus = Get-AzureADSSOStatus
													if (($ssostatus).Contains($DomainName1) -eq 'True')
													{
															$date = get-date 
															$append2log = "$MyHostName -- $date -- SSO Configured for Tenant: $ssostatus"
															$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"					
														
													}
													else
													{
														
															$date = get-date 
															$append2log = "$MyHostName -- $date -- SSO NOT configured for Tenant.... Adding..."
															$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"
															Enable-AzureADSSOForest -OnPremCredentials $Credential2 
															Enable-AzureADSSO -Enable $true
															$ssostatus = Get-AzureADSSOStatus
															$append2log = "$MyHostName -- $date -- SSO Configured for Tenant: $ssostatus"
															$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"	
															
															
															
														
														
													}
											$date = get-date 
											$append2log = "$MyHostName -- $date -- SSO Account already joined...exiting..."
											$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"												
											import-module "C:\Temp\AVDDSC\Microsoft Azure Active Directory Connect\AzureADSSO.psd1"
											New-AzureADSSOAuthenticationContext -CloudCredentials $Credential3 
											$append2log = $Storage1Present
											$append2log | Out-File -Append "c:\temp\SSO_Installation.txt"
											Get-AzureADSSOStatus | Out-File -Append "c:\temp\SSO_Installation.txt"	
											if (Test-Path C:\Temp\RunOn.txt)
											{Remove-Item -Force c:\temp\RunOn.txt}													
										}
									}
								 }
								
							}
																
						}
						Invoke-Command @parameters2						
						
					}
				
					
				TestScript =
				{
				   Return $false
				}			
				
			}		
		
		xRemoteFile M365LanguagePack {
		Uri			    = "$repoLoc$dlM365LanguagePack"
		DestinationPath = "C:\temp\$dlM365LanguagePack"		
		MatchSource     = $false
		}
		
		Script InstallM365LP
        {
		    GetScript = 
			{
			  Return $@{}
			}
	   
            SetScript =
            { 
			    	$dlM365LanguagePack = $using:dlM365LanguagePack
					Start-Process -FilePath c:\temp\$dlM365LanguagePack	-WindowStyle Hidden   				
			
			}				
					
				
			TestScript =
			{
				   Return $false
			}
	  		DependsOn =  "[xRemoteFile]M365LanguagePack"
        }
		
			Script AVDLocalSettings
        {
		    GetScript = 
			{
			  Return $@{}
			}
	   
            SetScript =
            { 
			    		$LanguageLocale = $using:LanguageLocale						  
						  
						#Set Time Zone:
						Set-TimeZone -Id "W. Europe Standard Time"
 
						#Set NTP server and VMIC:
						reg add HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\w32time\Parameters\NT5DS /v Enabled /t REG_SZ /d 1 /f
						
						Get-AppXPackage *microsoft.windowscommunicationsapps* | remove-appxpackage -AllUsers					
						Get-AppXPackage *solita* | remove-appxpackage -AllUsers
						
						#Disable Store auto update:
						reg add HKLM\Software\Policies\Microsoft\WindowsStore /v AutoDownload /t REG_DWORD /d 0 /f
						#Schtasks /Change /Tn "\Microsoft\Windows\WindowsUpdate\Automatic app update" /Disable
						Schtasks /Change /Tn "\Microsoft\Windows\WindowsUpdate\Scheduled Start" /Disable

						#Disable Content Delivery auto download apps that they want to promote to users:
						reg add HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager /v PreInstalledAppsEnabled /t REG_DWORD /d 0 /f

						reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager\Debug /v ContentDeliveryAllowedOverride /t REG_DWORD /d 0x2 /f
						
						#Set Language and Regional settings
						$OldList = Get-WinUserLanguageList
						$OldList.Add("$LanguageLocale")
						Set-WinUserLanguageList -LanguageList $OldList -Force
						Set-WinSystemLocale -SystemLocale $LanguageLocale
						
						
			
			}				
					
				
			TestScript =
			{
				   Return $false
			}
	  		DependsOn =  "[Script]InstallM365LP"
        }
		

	    Script Cleanup
        {
           GetScript = 
           {
               Return $@{}
           }
	   
           SetScript =
           {
		#  if (Test-Path c:\Temp) 
		# 	{
		# 		Remove-Item -Recurse -Force c:\Temp\*
		# 	} 
		# 	else
		# 	{
		# 		Write-Host "Path Temp doesn't exits"
		# 	}				
			    $DCName2 = $using:DCName	
				$clearUserAdmin1 = $using:clearUserAdmin
				$clearPassAdmin1 = Unprotect-CmsMessage -Content $using:clearPassAdmin

				$User2 = $clearUserAdmin1
				$PWord2 = ConvertTo-SecureString -String $clearPassAdmin1 -AsPlainText -Force
				$Credential2 = New-Object System.Management.Automation.PSCredential($User2,$PWord2)
		
				$ps = New-PSSession -ComputerName $DCName2 -Credential $Credential2
				
				$parameters0 = @{						
						Session = $ps						
						ScriptBlock  = {							
							
			#  if (Test-Path c:\StorageAccounts) 
			#  {
			#  	Remove-Item -Recurse -Force c:\StorageAccounts
			#  } 
			#  else
			#  {
			#  	Write-Host "Path StorageAccounts doesn't exits"
			#  }
			#  	
			#  	if (Test-Path c:\Temp) 
			#  	{
			#  		Remove-Item -Recurse -Force c:\Temp\*
			#  	} 
			#  	else
			#  	{
			#  		Write-Host "Path Temp doesn't exits"
			#  	}
				}							
				}
						
					
				Invoke-Command @parameters0
				
			  
           }
	   
        TestScript =
        {
               Return $false
            }
	  		DependsOn =  "[Script]AVDLocalSettings"
        }
		
	   if ($rdshIsServer)
        {
            "$(get-date) - rdshIsServer = true: $rdshIsServer" | out-file c:\windows\temp\rdshIsServerResult.txt -Append
            WindowsFeature RDS-RD-Server
            {
                Ensure = "Present"
                Name = "RDS-RD-Server"
            }

            Script ExecuteRdAgentInstallServer
            {
                DependsOn = "[WindowsFeature]RDS-RD-Server"
                GetScript = {
                    return @{'Result' = ''}
                }
                SetScript = {
                    . (Join-Path $using:ScriptPath "Functions.ps1")
                    try {
                        & "$using:ScriptPath\Script-SetupSessionHost.ps1" -HostPoolName $using:HostPoolName -RegistrationInfoToken $using:RegistrationInfoToken -AadJoin $using:AadJoin -AadJoinPreview $using:AadJoinPreview -MdmId $using:MdmId -SessionHostConfigurationLastUpdateTime $using:SessionHostConfigurationLastUpdateTime -UseAgentDownloadEndpoint $using:UseAgentDownloadEndpoint -EnableVerboseMsiLogging:($using:EnableVerboseMsiLogging)
                    }
                    catch {
                        $ErrMsg = $PSItem | Format-List -Force | Out-String
                        Write-Log -Err $ErrMsg
                        throw [System.Exception]::new("Some error occurred in DSC ExecuteRdAgentInstallServer SetScript: $ErrMsg", $PSItem.Exception)
                    }
                }
                TestScript = {
                    . (Join-Path $using:ScriptPath "Functions.ps1")
                    
                    try {
                        return (& "$using:ScriptPath\Script-TestSetupSessionHost.ps1" -HostPoolName $using:HostPoolName)
                    }
                    catch {
                        $ErrMsg = $PSItem | Format-List -Force | Out-String
                        Write-Log -Err $ErrMsg
                        throw [System.Exception]::new("Some error occurred in DSC ExecuteRdAgentInstallServer TestScript: $ErrMsg", $PSItem.Exception)
                    }
                }
            }	
				
        }
        else
        {
            "$(get-date) - rdshIsServer = false: $rdshIsServer" | out-file c:\windows\temp\rdshIsServerResult.txt -Append
            Script ExecuteRdAgentInstallClient
            {
                GetScript = {
                    return @{'Result' = ''}
                }
                SetScript = {
                    . (Join-Path $using:ScriptPath "Functions.ps1")
                    try {
                        & "$using:ScriptPath\Script-SetupSessionHost.ps1" -HostPoolName $using:HostPoolName -RegistrationInfoToken $using:RegistrationInfoToken -AadJoin $using:AadJoin -AadJoinPreview $using:AadJoinPreview -MdmId $using:MdmId -SessionHostConfigurationLastUpdateTime $using:SessionHostConfigurationLastUpdateTime -UseAgentDownloadEndpoint $using:UseAgentDownloadEndpoint -EnableVerboseMsiLogging:($using:EnableVerboseMsiLogging)
                    }
                    catch {
                        $ErrMsg = $PSItem | Format-List -Force | Out-String
                        Write-Log -Err $ErrMsg
                        throw [System.Exception]::new("Some error occurred in DSC ExecuteRdAgentInstallClient SetScript: $ErrMsg", $PSItem.Exception)
                    }
                }
                TestScript = {
                    . (Join-Path $using:ScriptPath "Functions.ps1")
                    
                    try {
                        return (& "$using:ScriptPath\Script-TestSetupSessionHost.ps1" -HostPoolName $using:HostPoolName)
                    }
                    catch {
                        $ErrMsg = $PSItem | Format-List -Force | Out-String
                        Write-Log -Err $ErrMsg
                        throw [System.Exception]::new("Some error occurred in DSC ExecuteRdAgentInstallClient TestScript: $ErrMsg", $PSItem.Exception)
                    }

                }
            }
        }
    }
}
