/* DigiJust Tracker Bootstrap
  
  Versie DJ8-19-07rc1
  2019-07-05  initial version
  2019-07-11  Move public key from config to main.js
  2019-07-17  DJ8-6664, fix response duplicate content-length header
  2019-07-26  1.0 - Start Bootstrap version with 1.0
  2020-02-18  1.1 - To support other loadbalancers prepare cookies in Hoofdscherm.js iso this js
  2020-03-04  1.1 - remove nosaml : true. Causes problems in JenV loadbalancer
  2020-03-19  1.2 - always add nosaml=digijustttracker to cookies if no nosaml is provided
  2020-03-19  1.2 - querystring parse translates + char to space in cookie value. Translate back

*/

const {app, Menu, Tray, shell, dialog, nativeImage} = require('electron');
const chokidar = require('chokidar');
const crc = require('crc');
const fs = require('fs-extra');
const log = require('node-file-logger');
const config = require('./config.json');
process.binding('http_parser').HTTPParser = require('http-parser-js').HTTPParser; //DJ8-6664
const request = require('request');
const querystring = require('querystring');
const path = require('path');
const officeDocumentProperties = require('office-document-properties');

var trackerVersion = ""; //filled in Remote code
var bootstrapTrackerVersion = "1.2";

var keepAliveRunning = false;
var watchPath = '';
var watcher = null;

var cookie_DigiJust = '';
var repositoryId = '';
var documentBase = '';
var security_token_global = '';

var documentsInEdit = [];
var eventHistory = [];

var digijustUri = '';
var handleUriCode = '';
var werkplekId = '';

//Force Single Instance Application
const shouldQuit = app.makeSingleInstance((argv, workingDirectory) => {
	
	 digijustUri = argv.slice(1)[0];
	 
	 //Enable for local testing
	 //handleUriCode = fs.readFileSync(path.join(__dirname, 'remote_loaded_code.js'), {encoding: 'utf8'});
     if (digijustUri.indexOf('action=initialize') > -1 && handleUriCode == "") {
         getTrackerCode(digijustUri);
     } else {
         eval(handleUriCode);
     }
	return true;
});
if (shouldQuit) {
	app.quit();
	return;
}

app.on('ready', () => {
	const logFolder = resolvePath(config.logFolder);
	const logOptions = {
			timeZone: 'Europe/Amsterdam',
			folderPath: logFolder,
			dateBasedFileNaming: true,
			fileNamePrefix: 'DailyLogs_',
			fileNameExtension: '.log',
			dateFormat: 'YYYY-MM-DD',
			timeFormat: 'HH:mm:ss.SSS',
			onlyFileLogging: false
	};

	fs.ensureDirSync(logFolder);
	log.SetUserOptions(logOptions);
	deleteLogs(logFolder, 7);

	log.Info('Starting DigijustTracker bootstap '+bootstrapTrackerVersion+', werkplek config ID: '+config.werkplekId);
	trackerStarted = getFormattedDate();

	var iconPath = path.join(__dirname, 'icons/neutral-16x16.png');
	var trayIcon = nativeImage.createFromPath(iconPath);
	tray = new Tray(trayIcon);

	const contextMenu = Menu.buildFromTemplate([{label: 'Info', click: () => openInfoWindow()}]);
	tray.setToolTip('DigiJust Tracker (niet verbonden)');
	tray.setContextMenu(contextMenu);

	digijustUri = process.argv.slice(1)[0];

	//Enable for local testing
	//handleUriCode = fs.readFileSync(path.join(__dirname, 'remote_loaded_code.js'), {encoding: 'utf8'});
	if (digijustUri.indexOf('action=initialize') > -1 && handleUriCode == "") {
		getTrackerCode(digijustUri);
	} else {
		eval(handleUriCode);
	}
})

function openInfoWindow() {

	var infoMessage = 'Bootstrap '+bootstrapTrackerVersion+', tracker '+trackerVersion+', werkplek: '+werkplekId+'\n';
	if (watchPath != '') {
		var normalize = require('normalize-path');
		infoMessage += '   '+normalize(watchPath)+'\n\n';
	}

	if (!keepAliveRunning) {
		infoMessage += '(Her)start DigiJust client om de verbinding te initialiseren.'
	} else {
		for (var i in eventHistory) {
			infoMessage += '  '+eventHistory[i]+'\n';
		}
	}
	infoMessage += '\n';

	Object.keys(documentsInEdit).forEach(function(vsid) {
		infoMessage += '  '+documentsInEdit[vsid]+'\n';
	});
	dialog.showMessageBox({ title: 'DigiJust Tracker Info', type: 'info', message: infoMessage, buttons: ['OK'] });
}


function resolvePath(path) {
	var processedPath = path;
	var envVars = path.split('%');
	if (envVars.length > 0) {
		for (var i=1; i<envVars.length; i+=2) {
			var envVar = process.env[envVars[i]];
			if (envVar != undefined) {
				processedPath = processedPath.replace('%'+envVars[i]+'%', envVar);
			} else {
				log.error('Path: '+path+', environment variable not found!: '+envVars[i]);
			}
		}
	}
	return processedPath;
}

function deleteLogs(logFolder, numberOfDays) {
	var today = new Date().getTime();
	var oneDay = 1000*60*60*24;
	fs.readdirSync(logFolder).forEach(file => {
		var fileStatus = fs.statSync(logFolder+'/'+file);
		var fileDate = new Date(fileStatus.birthtime).getTime();
		var daysOld = Math.round((today-fileDate)/oneDay);
		if ((daysOld > numberOfDays) && file.endsWith('.log')) {
			fs.removeSync(logFolder+'/'+file);
			log.Info('Logfile deleted: '+logFolder+'/'+file+' ('+daysOld+' days old)');
		}
	});
}

function getFormattedDate() {
	var d = new Date();
	d = d.getFullYear() + "-" +
	('0' + (d.getMonth() + 1)).slice(-2) + "-" +
	('0' + d.getDate()).slice(-2) + " " +
	('0' + d.getHours()).slice(-2) + ":" +
	('0' + d.getMinutes()).slice(-2) + ":" +
	('0' + d.getSeconds()).slice(-2);
	return d;
}

function getTrackerCode(digijustUri) {
  log.Info('DigiJust Client raw request (getTrackerCode): '+digijustUri);
  
  var digijustIndex = digijustUri.indexOf('digijusturi:');
  var digijustParameters = digijustUri.substring(digijustIndex+12);
  var q = querystring.parse(digijustParameters);

  cookie_DigiJust = ['LtpaToken2='+q.cookie_LtpaToken2.split(' ').join('+'), 'JSESSIONID='+q.cookie_JSESSIONID];
  
  //Additional cookies - starting with addcookie_
  var NSC_handled = false;
  for (var key of Object.keys(q)) {
	  if (key.startsWith('addcookie_')) {
		  var cookie_key = key.substring(10);
		  cookie_DigiJust.push(cookie_key+'='+q[key].split(' ').join('+'));
		  if (cookie_key == 'nosaml') {
			  NSC_handled = true; 
		  }
	  }
  }
  
  if (q.cookie_NSC_xxx_value && !NSC_handled) { //only if not already handled
    cookie_DigiJust.push('nosaml='+q.cookie_NSC_xxx_value);
  } else {
	  if (!NSC_handled) { //for F5 loadbalancer, always push nosaml with identifier, e.g. user-agent
		  cookie_DigiJust.push('nosaml=digijusttracker');
	  }
  }
  log.Info('cookie_DigiJust: '+JSON.stringify(cookie_DigiJust));

  var options = {
      strictSSL: false,
      url: q.documentBase+'navigator/jaxrs/plugin',
      qs: { 'security_token': q.security_token,
        'desktop': 'digijust',
        'repositoryId': q.repositoryId,
        'plugin': 'HoofdScherm',
        'action': 'TrackerCodeService',
        'codeaction': 'get',
        'werkplekId' : config.werkplekId
      },
      method: 'GET',
      headers: {'Cookie': cookie_DigiJust}
  };

  var code = "";
  request(options, function (error, response, body) {
    var errorText = '';

    if (error || body.startsWith('<')) {
    	errorText = error ? error : body;
    } else {
    	var response_body_json = JSON.parse(body);
    	if (response_body_json && response_body_json.status == "found") { 
    		log.Info('Remote code found for werkplekId: '+response_body_json.werkplekId);
    		werkplekId = response_body_json.werkplekId;
    		handleUriCode = response_body_json.trackerCode;

    		const signature = response_body_json.signature;
    		//Public key. Will not change in foreseeable future
    		const trackercodePublic = 'MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKYyrB6xauksnAYVWG9I7RfgiIDfKUONUQDN+UbwRfuqIgimncdKTio58TZyRkvO8kL7wfCx2qqHhjdXdHd95X8CAwEAAQ==';
    		const public_key = '-----BEGIN PUBLIC KEY-----\r\n'+trackercodePublic+'\r\n-----END PUBLIC KEY-----';

    		const crypto = require('crypto');
    		const verifier = crypto.createVerify('sha256');
    		verifier.update(handleUriCode);
    		verifier.end();

    		log.Info('Remote code signature verifying for signature and public key: '+signature+', '+trackercodePublic);
    		try {
    			var verified = verifier.verify(public_key, signature, 'hex');
    		} catch (e) {
    			verified = false;
    		}

    		if (verified) {
    			log.Info('Remote code signature verify succeeded');
    			eval(handleUriCode);
    		} else {  
    			handleUriCode = ''; //reset
    			log.Error('Remote code signature verify failed');

    			tray.setImage(nativeImage.createFromPath(path.join(__dirname, 'icons/red-16x16.png')));
    			tray.setToolTip('Trackercode validatiefout!');
    		}
    	} else {
    		log.Error('Remote code not found for werkplekId: '+response_body_json.werkplekId);
    	}
    }
    if (errorText != '') {
    	log.Error('getTrackerCode : '+errorText);
    }
  });

  return code;
}
