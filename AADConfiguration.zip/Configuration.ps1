if (!(Test-Path "C:\TEMP")) { New-Item -ItemType Directory -Force -Path "C:\TEMP"}
#if (!(Test-Path "D:\FSLOGIX\ProfileCache")) { New-Item -ItemType Directory -Force -Path "D:\FSLOGIX\ProfileCache"}
if (!(Test-Path HKLM:\SOFTWARE\AVDConfig_Status))
{New-Item -Path HKLM:\SOFTWARE\AVDConfig_Status -force}


get-childitem cert:\localmachine\my | where-object {$_.Subject -like "*CN=DscEncryptionCert*"} | remove-item
$cert = New-SelfSignedCertificate -Type DocumentEncryptionCertLegacyCsp -DnsName 'DscEncryptionCert' -HashAlgorithm SHA256
$cert | Export-Certificate -FilePath "C:\TEMP\DscPublicKey.cer" -Force
$Thumbprint = (get-childitem cert:\localmachine\my | where-object {$_.Subject -like "*CN=DscEncryptionCert*"}).Thumbprint
$ConfigData= @{ 
    AllNodes = @(     
            @{   
                NodeName = "localhost" 

                CertificateFile = "C:\TEMP\DscPublicKey.cer" 

                Thumbprint = $Thumbprint 
            }; 
        );    
    }

Configuration AddSessionHost
{
    param
    (		
        [Parameter(Mandatory = $true)]
        [string]$HostPoolName,
		
		[Parameter(Mandatory = $true)]
        [string]$AppGroupName,

        [Parameter(Mandatory = $true)]
        [string]$RegistrationInfoToken,

        [Parameter(Mandatory = $false)]
        [bool]$AadJoin = $false,

        [Parameter(Mandatory = $false)]
        [bool]$AadJoinPreview = $false,

        [Parameter(Mandatory = $false)]
        [string]$MdmId = "",

        [Parameter(Mandatory = $false)]
        [string]$SessionHostConfigurationLastUpdateTime = "",

        [Parameter(Mandatory = $false)]
        [bool]$EnableVerboseMsiLogging = $false,
        
        [Parameter(Mandatory = $false)]
        [bool]$UseAgentDownloadEndpoint = $false,
		
		[Parameter(Mandatory = $false)]
        [System.Management.Automation.PSCredential]$localAdminCreds,
		
		[Parameter(Mandatory = $false)]
        [System.Management.Automation.PSCredential]$AzureSPCertCreds,
		
		[Parameter(Mandatory)]
        [String]$SubscriptionId,
		
		[Parameter(Mandatory)]
        [String]$KVName,
		
		[Parameter(Mandatory)]
        [String]$ResourceGroupNameAVD,
		
		[Parameter(Mandatory)]
        [String]$StorageAccountName,
		
		[Parameter(Mandatory)]
        [String]$AVDHostpoolUsers,
		
		[Parameter(Mandatory)]
        [String]$AVDHostpoolAdmins,
		
		[Parameter(Mandatory)]
        [string]$FriendlyVDI,
		
		[Parameter(Mandatory)]
        [string]$FirstAVDHost,
		
		[Parameter(Mandatory = $false)]
        [string]$SPCertificateThumbprint,
		
		[Parameter(Mandatory = $false)]
        [string]$SPApplicationID,
		
		[Parameter(Mandatory = $false)]
        [string]$SPTenantID,
		
		[Parameter(Mandatory = $false)]
        [string]$Subscription,
		
		[Parameter(Mandatory = $false)]
        [string]$SPCertificateName,
		
		[Parameter(Mandatory = $false)]
        [string]$userAssignedIdentityID,
		
		[Parameter(Mandatory = $false)]
        [bool]$SPUseCertAuth,
		
		[Parameter(Mandatory = $false)]
        [bool]$DebugDSCDeployment,
		
		[Parameter(Mandatory = $false)]
        [bool]$Tools,
		
		[Parameter(Mandatory = $false)]
        [bool]$UseFSLogix,
		
		[Parameter(Mandatory = $false)]
        [bool]$DisableFSLogix,
		
		[Parameter(Mandatory = $false)]
        [bool]$UseProxy,
		
		[Parameter(Mandatory = $false)]
        [string]$ProxyValue,
		
		[Parameter(Mandatory = $false)]
        [string]$ProxyBypass,
		
		[Parameter(Mandatory = $false)]
        [bool]$UseDefaultConfig,
		
		[Parameter(Mandatory = $false)]
        [bool]$DutchOS,
		
		[Parameter(Mandatory = $false)]
        [string]$dscsaname,
		
		[Parameter(Mandatory = $false)]
        [string]$SASToken,
		
		[Parameter(Mandatory = $false)]
        [string]$nestedTemplatesLocation
		
    )

    $ErrorActionPreference = 'Stop'
    
    $ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)
    . (Join-Path $ScriptPath "Functions.ps1")

    $rdshIsServer = isRdshServer	

	Import-DscResource -ModuleName xPendingReboot	
	
    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
			ConfigurationMode = "ApplyOnly"
			CertificateId = $Thumbprint 	
       
        }	
 	 
		if ($rdshIsServer)
        {
            "$(get-date) - rdshIsServer = true: $rdshIsServer" | out-file c:\windows\temp\rdshIsServerResult.txt -Append
            WindowsFeature RDS-RD-Server
            {
                Ensure = "Present"
                Name = "RDS-RD-Server"
            }

            Script ExecuteRdAgentInstallServer
            {
                DependsOn = "[WindowsFeature]RDS-RD-Server"
                GetScript = {
                    return @{'Result' = ''}
                }
                SetScript = {
                    . (Join-Path $using:ScriptPath "Functions.ps1")
                    try {
                        & "$using:ScriptPath\Script-SetupSessionHost.ps1" -HostPoolName $using:HostPoolName -RegistrationInfoToken $using:RegistrationInfoToken -AadJoin $using:AadJoin -AadJoinPreview $using:AadJoinPreview -MdmId $using:MdmId -SessionHostConfigurationLastUpdateTime $using:SessionHostConfigurationLastUpdateTime -UseAgentDownloadEndpoint $using:UseAgentDownloadEndpoint -EnableVerboseMsiLogging:($using:EnableVerboseMsiLogging)
                    }
                    catch {
                        $ErrMsg = $PSItem | Format-List -Force | Out-String
                        Write-Log -Err $ErrMsg
                        throw [System.Exception]::new("Some error occurred in DSC ExecuteRdAgentInstallServer SetScript: $ErrMsg", $PSItem.Exception)
                    }
                }
                TestScript = {
                    . (Join-Path $using:ScriptPath "Functions.ps1")
                    
                    try {
                        return (& "$using:ScriptPath\Script-TestSetupSessionHost.ps1" -HostPoolName $using:HostPoolName)
                    }
                    catch {
                        $ErrMsg = $PSItem | Format-List -Force | Out-String
                        Write-Log -Err $ErrMsg
                        throw [System.Exception]::new("Some error occurred in DSC ExecuteRdAgentInstallServer TestScript: $ErrMsg", $PSItem.Exception)
                    }
                }
            }
        }
        else
        {
            "$(get-date) - rdshIsServer = false: $rdshIsServer" | out-file c:\windows\temp\rdshIsServerResult.txt -Append
            Script ExecuteRdAgentInstallClient
            {
                GetScript = {
                    return @{'Result' = ''}
                }
                SetScript = {
                    . (Join-Path $using:ScriptPath "Functions.ps1")
                    try {
                        & "$using:ScriptPath\Script-SetupSessionHost.ps1" -HostPoolName $using:HostPoolName -RegistrationInfoToken $using:RegistrationInfoToken -AadJoin $using:AadJoin -AadJoinPreview $using:AadJoinPreview -MdmId $using:MdmId -SessionHostConfigurationLastUpdateTime $using:SessionHostConfigurationLastUpdateTime -UseAgentDownloadEndpoint $using:UseAgentDownloadEndpoint -EnableVerboseMsiLogging:($using:EnableVerboseMsiLogging)
                    }
                    catch {
                        $ErrMsg = $PSItem | Format-List -Force | Out-String
                        Write-Log -Err $ErrMsg
                        throw [System.Exception]::new("Some error occurred in DSC ExecuteRdAgentInstallClient SetScript: $ErrMsg", $PSItem.Exception)
                    }
                }
                TestScript = {
                    . (Join-Path $using:ScriptPath "Functions.ps1")
                    
                    try {
                        return (& "$using:ScriptPath\Script-TestSetupSessionHost.ps1" -HostPoolName $using:HostPoolName)
                    }
                    catch {
                        $ErrMsg = $PSItem | Format-List -Force | Out-String
                        Write-Log -Err $ErrMsg
                        throw [System.Exception]::new("Some error occurred in DSC ExecuteRdAgentInstallClient TestScript: $ErrMsg", $PSItem.Exception)
                    }

                }
            }
        }
		if ($UseDefaultConfig -eq $false)
		{	

			
			
			$localAdminCredUser = $localAdminCreds.GetNetworkCredential().username
			$localAdminCredPass = $localAdminCreds.GetNetworkCredential().password | Protect-CmsMessage -To $Thumbprint
			Set-LocalUser -Name $localAdminCredUser -PasswordNeverExpires 1
			
			$LAUser = ".\"+$localAdminCredUser
			$LAPass1 = Unprotect-CmsMessage -Content $localAdminCredPass
			$LAPass = ConvertTo-SecureString -String $LAPass1 -AsPlainText -Force
			$LACred = New-Object System.Management.Automation.PSCredential($LAUser,$LAPass)
			
			
			if ($SPApplicationID)
			{
				$clearAzureSPCertUser = $AzureSPCertCreds.GetNetworkCredential().username
				$clearAzureSPCertPass = $AzureSPCertCreds.GetNetworkCredential().password | Protect-CmsMessage -To $Thumbprint
				
			}
			if ($SASToken)
			{
				$SASTokenEnc = $SASToken | Protect-CmsMessage -To $Thumbprint
				
			}			
				
			Script AVDLocalSettings
			{
				GetScript = 
				{
				  Return $@{}
				}
		   
				SetScript =
				{ 	$AVDConfigDone = Get-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name AVDconfig_Done -erroraction ignore
					if ($AVDConfigDone -eq $null)
					{					
						#Validating all files are present in package
						"$(get-date) - $env:computername Validating all files are present in package..." | out-file c:\temp\AVDSettings.txt -Append					
						Start-Process -FilePath "cmd.exe"  -ArgumentList '/c "dir c:\packages /B /S"' -Wait -RedirectStandardOutput c:\temp\packagelist.txt
						$packageoutput = Get-Content C:\temp\packagelist.txt
						$packageoutput | out-file c:\temp\AVDSettings.txt -Append 
						
						"$(get-date) - $env:computername Downloading AZ Cmdlets MSI..." | out-file c:\temp\AVDSettings.txt -Append
						if ($using:SASTokenEnc)
						{	$SAS = Unprotect-CmsMessage -Content $using:SASTokenEnc
							$url0 = "https://$using:dscsaname.blob.core.windows.net/dsc/Tools.zip?$using:SAS"
							$url1 = "https://$using:dscsaname.blob.core.windows.net/dsc/Az-Cmdlets-10.1.0.37441-x64.msi"
							$url2 = "https://$using:dscsaname.blob.core.windows.net/dsc/DigiJust Tracker 2.0.zip"
							
						}
						else
						{
							$url0 = "$using:nestedTemplatesLocationTools.zip"
							$url1 = "$using:nestedTemplatesLocationAz-Cmdlets-10.1.0.37441-x64.msi"	
							$url2 = "$using:nestedTemplatesLocationDigiJust Tracker 2.0.zip"
														
						}
							$url3 = "https://$using:dscsaname.blob.core.windows.net/dsc/pdf24-creator-11.17.0-x64.msi"
							
							
						# Downloading Tools
						$dest0 = "c:\temp\Tools.zip"					
						Invoke-WebRequest -Uri $url0 -OutFile $dest0
						"$(get-date) - $env:computername Downloading Tools from: $url0 ..." | out-file c:\temp\AVDSettings.txt -Append	

						# Downloading Az-Cmdlets-10.1.0.37441-x64.msi
						$dest1 = "c:\temp\Az-Cmdlets-10.1.0.37441-x64.msi"					
						Invoke-WebRequest -Uri $url1 -OutFile $dest1
						"$(get-date) - $env:computername Downloading from: $url1 ..." | out-file c:\temp\AVDSettings.txt -Append						
						
						# Downloading DigiJust Tracker
						$dest2 = "c:\temp\DigiJust Tracker 2.0.zip"					
						Invoke-WebRequest -Uri $url2 -OutFile $dest2
						"$(get-date) - $env:computername Downloading from: $url2 ..." | out-file c:\temp\AVDSettings.txt -Append		
						
						# Downloading pdf24-creator-11.17.0-x64.msi
						$dest3 = "c:\temp\pdf24-creator-11.17.0-x64.msi"			
						Invoke-WebRequest -Uri $url3 -OutFile $dest3
						"$(get-date) - $env:computername Downloading from: $url3 ..." | out-file c:\temp\AVDSettings.txt -Append	
						
						#Extracting Tools					
						"$(get-date) - $env:computername Extracting Tools..." | out-file c:\temp\AVDSettings.txt -Append
						expand-Archive -Force -Path "C:\Temp\Tools.zip" -DestinationPath "C:\Temp" -Erroraction silentlycontinue
						
						#Extracting DJ Tracker 2.0					
						"$(get-date) - $env:computername Extracting DigiJust 2.0..." | out-file c:\temp\AVDSettings.txt -Append
						expand-Archive -Force -Path "C:\Temp\DigiJust Tracker 2.0.zip" -DestinationPath "C:\Program Files\DigiJust Tracker" -Erroraction silentlycontinue
						
						#Registering NuGet Package Provider
						"$(get-date) - $env:computername Registering NuGet Package Provider..." | out-file c:\temp\AVDSettings.txt -Append
						if (!(test-path "C:\Program Files\PackageManagement\ProviderAssemblies\nuget"))
						{
							expand-Archive -Path "C:\Temp\nuget.zip" -DestinationPath "C:\Program Files\PackageManagement\ProviderAssemblies"
						}
						Import-PackageProvider -Name NuGet				
						
						$env:Path                             
						$env:Path = 'C:\Program Files\PackageManagement\ProviderAssemblies;' + $env:Path
						"$(get-date) - $env:computername Registering NuGet Package Provider registered..." | out-file c:\temp\AVDSettings.txt -Append
						
						#Importing AzureAD Module					
						"$(get-date) - $env:computername Importing AzureAD Module..." | out-file c:\temp\AVDSettings.txt -Append
						expand-Archive -Force -Path "C:\Temp\AzureAD.zip" -DestinationPath "C:\Program Files\WindowsPowerShell\Modules" -Erroraction silentlycontinue
						Import-Module -Name "C:\Program Files\WindowsPowerShell\Modules\AzureAD\2.0.2.182\AzureAD.psd1" -Erroraction silentlycontinue
						"$(get-date) - $env:computername AzureAD Module imported ..." | out-file c:\temp\AVDSettings.txt -Append
						
						#Install Az Cmdlets
						"$(get-date) - $env:computername Starting Az Cmdlets MSI installation..." | out-file c:\temp\AVDSettings.txt -Append					
						Start-Process msiexec.exe -Wait -ArgumentList '/I C:\temp\Az-Cmdlets-10.1.0.37441-x64.msi /quiet'
						"$(get-date) - $env:computername Az-CmdLets installed ..." | out-file c:\temp\AVDSettings.txt -Append
						
						#Install PDF24 Creator
						"$(get-date) - $env:computername Starting PDF24 Creator MSI installation..." | out-file c:\temp\AVDSettings.txt -Append					
						Start-Process msiexec.exe -Wait -ArgumentList '/I C:\temp\pdf24-creator-11.17.0-x64.msi /quiet'
						"$(get-date) - $env:computername PDF24 Creator MSI installed ..." | out-file c:\temp\AVDSettings.txt -Append
						Remove-Item "C:\Users\Public\Desktop\*.*" -force
						
						#Importing WinInetProxy Module					
						"$(get-date) - $env:computername Importing WinInetProxy Module..." | out-file c:\temp\AVDSettings.txt -Append
						expand-Archive -Force -Path "C:\Temp\WinInetProxy.zip" -DestinationPath "C:\Program Files\WindowsPowerShell\Modules\WinInetProxy" -Erroraction silentlycontinue
						Import-Module -Name "C:\Program Files\WindowsPowerShell\Modules\WinInetProxy\WinInetProxy.psd1" -Erroraction silentlycontinue
						"$(get-date) - $env:computername WinInetProxy Module imported ..." | out-file c:\temp\AVDSettings.txt -Append
						
						#Importing Intune-PowerShell-SDK Module					
						"$(get-date) - $env:computername Importing Intune-PowerShell-SDK Module..." | out-file c:\temp\AVDSettings.txt -Append
						expand-Archive -Force -Path "C:\Temp\Intune-PowerShell-SDK.zip" -DestinationPath "C:\Program Files\WindowsPowerShell\Modules\Microsoft.Graph.Intune" -Erroraction silentlycontinue
						Import-Module -Name "C:\Program Files\WindowsPowerShell\Modules\Microsoft.Graph.Intune\Microsoft.Graph.Intune.psd1" -Erroraction silentlycontinue					
						"$(get-date) - $env:computername Intune-PowerShell-SDK Module imported ..." | out-file c:\temp\AVDSettings.txt -Append
						
						#Copy IntuneManagementExtensionDiagnostics.PS1 to C:\Temp
						"$(get-date) - $env:computername Copy IntuneManagementExtensionDiagnostics.PS1 to C:\Temp..." | out-file c:\temp\AVDSettings.txt -Append							
						Copy-Item "C:\Program Files\WindowsPowerShell\Modules\Microsoft.Graph.Intune\Get-IntuneManagementExtensionDiagnostics.ps1" -Destination "C:\Temp\Get-IntuneManagementExtensionDiagnostics.ps1"
						
						#Copy Error Diagnostics tool to C:\Windows\System32
						"$(get-date) - $env:computername Copy Error Diagnostics tool to C:\Windows\System32..." | out-file c:\temp\AVDSettings.txt -Append							
						Copy-Item "C:\Temp\err.exe" -Destination "C:\Windows\System32"
						
						#Install Java RE
						"$(get-date) - $env:computername Starting Java RE 8 installation..." | out-file c:\temp\AVDSettings.txt -Append					
						Start-Process msiexec.exe -Wait -ArgumentList '/I C:\temp\jre1.8.0_40164.msi /quiet'
						"$(get-date) - $env:computername JAVA RE 8 installed ..." | out-file c:\temp\AVDSettings.txt -Append

						New-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name AVDconfig_Done -Value "DON'T REMOVE! Required for correct DSC rerun of AVD configuration." -force
					}	
					
					#Create Credentials
					if ($using:SPApplicationID)
					{	 	
						if ($using:SPUseCertAuth -eq $true)
						{
							$PFXPresent = Get-ChildItem -path Cert:\*$Using:SPCertificateThumbprint -Recurse
							"$(get-date) - $env:computername Checking if Automation Certificate is imported..." | out-file c:\temp\AVDSettings.txt -Append
							$PFXPresent | out-file c:\temp\AVDSettings.txt -Append
							if ($PFXPresent -eq $null)
							{
								#Importing Automation Certificate
								"$(get-date) - $env:computername Using Cert Auth...Not present. Importing Automation Certificate..." | out-file c:\temp\AVDSettings.txt -Append
								$CAPass1 = Unprotect-CmsMessage -Content $using:clearAzureSPCertPass
								$CAPass2 = ConvertTo-SecureString -String $CAPass1 -AsPlainText -Force
								$CertPathArray = Get-ChildItem C:\Packages\Plugins\Microsoft.Powershell.DSC -Filter $using:SPCertificateName -Recurse | % { $_.FullName }
								"$(get-date) - $env:computername CertPathArray: $CertPathArray" | out-file c:\temp\AVDSettings.txt -Append	 					
								
								
								if (($CertPathArray -is [system.array]) -eq $false)
								{
									$CertPath = [string]$CertPathArray
									"$(get-date) - $env:computername CertPathArray[0]: $CertPath" | out-file c:\temp\AVDSettings.txt -Append
								}
								else
								{
									$CertPath = [string]$CertPathArray[0]
									"$(get-date) - $env:computername CertPathArray: $CertPath" | out-file c:\temp\AVDSettings.txt -Append
								}
								
								
								$params = @{
									FilePath = $CertPath
									CertStoreLocation = 'Cert:\LocalMachine\My'
									Password = $CAPass2
								}
								Import-PfxCertificate @params | out-file c:\temp\AVDSettings.txt -Append
							}
							else
							{
								"$(get-date) - $env:computername Automation Certificate already imported..." | out-file c:\temp\AVDSettings.txt -Append
							}
							
							#Connect to Az using SP:
							"$(get-date) - $env:computername Connecting to AzAccount with SP and Cred..." | out-file c:\temp\AVDSettings.txt -Append								
							Connect-AzAccount -CertificateThumbprint $using:SPCertificateThumbprint -ApplicationId $using:SPApplicationID -TenantId $using:SPTenantID -Subscription $using:Subscription | out-file c:\temp\AVDSettings.txt -Append								
							Set-AzContext -Subscription $using:SubscriptionId
							Get-AzContext | out-file c:\temp\AVDSettings.txt -Append
															
						}
						else
						{							
							#use UAI 	
							$response = Invoke-WebRequest -UseBasicParsing -Uri "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&client_id=$using:userAssignedIdentityID&resource=https://vault.azure.net" -Method GET -Headers @{Metadata="true"}
							$content = $response.Content | ConvertFrom-Json
							$ArmToken = $content.access_token
							$KeyVaultToken = $ArmToken
							Invoke-RestMethod -Uri "https://$using:KVName.vault.azure.net//secrets/AutomationCert?api-version=2016-10-01" -Method GET -Headers @{Authorization="Bearer $KeyVaultToken"}  -UseBasicParsing
												
							Start-Sleep -Seconds 5
							#Connect to Az using UAI:
							Connect-AzAccount -Identity
							Set-AzContext -SubscriptionId $using:SubscriptionId
							#Connect to AzureAD using UAI:
							$token = Get-AzAccessToken
							Connect-AzureAD -AadAccessToken $token -AccountId $using:userAssignedIdentityID -TenantId $using:SPTenantID 
						}
						
					}
					#Set Time Zone:
					"$(get-date) - $env:computername Setting TimeZone to ""W. Europe Standard Time""... " | out-file c:\temp\AVDSettings.txt -Append
					Set-TimeZone -Id "W. Europe Standard Time"
					"$(get-date) - $env:computername TimeZone Set to ""W. Europe Standard Time""... " | out-file c:\temp\AVDSettings.txt -Append
					Get-TimeZone | out-file c:\temp\AVDSettings.txt -Append 
							
					#Configure FSLogix
					if ($using:UseFSLogix -eq $true)
					{	
						
						"$(get-date) - $env:computername Checking if FSLogix config ran before..." | out-file c:\temp\AVDSettings.txt -Append
						$FSLogixConfigDone = Get-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name FSLogixKey_Installed -erroraction ignore
						if ($FSLogixConfigDone -eq $null)								
						{									
							Connect-AzAccount -CertificateThumbprint $using:SPCertificateThumbprint -ApplicationId $using:SPApplicationID -TenantId $using:SPTenantID -Subscription $using:Subscription
							Set-AzContext -Subscription $using:SubscriptionId
							"$(get-date) - $env:computername FSLogix not yet configured...starting... Getting Az Context:" | out-file c:\temp\AVDSettings.txt -Append
							Get-AzContext | out-file c:\temp\AVDSettings.txt -Append
						
							"$(get-date) - $env:computername Starting FSLogix Key Config.." | out-file c:\temp\AVDSettings.txt -Append
							#Create FSLogix Blob Storage Access Keys								
							$ValueType1 = "type=azure,name=""AZURE PROVIDER 1"",connectionString=""|fslogix/"
							$ValueType2 = $using:StorageAccountName
							$ValueType3 = "-CS1|"""
							$ValueType = $ValueType1+$ValueType2+$ValueType3
							#"$(get-date) - $env:computername ValueType is $ValueType ." | out-file c:\temp\AVDSettings.txt -Append
							
							#Get-AZContext | out-file c:\temp\AVDSettings.txt -Append					
							$fslBlob1ConnectString = (Get-AzStorageAccount -ResourceGroupName $using:ResourceGroupNameAVD -Name $ValueType2).Context.ConnectionString
							if ($fslBlob1ConnectString -eq $null)
							{
								throw "Can't reach storage account to set secure key. This is a terminating error."
							}
							else
							{								
								$fslApp = "C:\Program Files\FSLogix\Apps\frx.exe"
								$arguments = "add-secure-key -key $ValueType2-CS1 -value ""$fslBlob1ConnectString"""								
								start-process $fslApp $arguments 					
								New-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles\ -Name CCDLocations -PropertyType multistring -Value $ValueType -Force
								
								New-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name FSLogixKey_Installed -Value "DON'T REMOVE! Required for correct DSC rerun of FSLogix configuration." -force	
								
								"$(get-date) - $env:computername Dumping FSLogix Connection String Key..." | out-file c:\temp\AVDSettings.txt -Append
								$fslBlob1ConnectString | out-file c:\temp\AVDSettings.txt -Append								
							}
							
						}
	 
						"$(get-date) - $env:computername Configuring FSLogix Registry Keys..." | out-file c:\temp\AVDSettings.txt -Append
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name Enabled -Value 1
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name LockedRetryCount -Value 3
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name LockedRetryInterval -Value 15
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name ReAttachIntervalSeconds -Value 15
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name ReAttachRetryCount -Value 3
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name VolumeType -Value "VHDX"
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name DeleteLocalProfileWhenVHDShouldApply -Value 1
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name CleanupInvalidSessions -Value 1
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name PreventLoginWithTempProfile -Value 1
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name PreventLoginWithFailure -Value 1
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name FlipFlopProfileDirectoryName -Value 1
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name ClearCacheOnLogoff -Value 1
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name CleanOutNotifications -Value 1
						Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name LogonSyncMutexTimeout -Value 60000
						
						#Setting WriteCache to D: temp disk
						#Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\frxccd\Parameters -Name CacheDirectory -Value "D:\FSLOGIX\ProfileCache"
						#Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\frxccds\Parameters -Name WriteCacheDirectory -Value "D:\FSLOGIX\ProfileCache"
						
						
							
						#	#Add $using:AVDHostpoolAdmins to local FSLogix Exclude group
						#	#Connect to AzureAD using SP:						
						##	Connect-AzureAD -CertificateThumbprint $using:SPCertificateThumbprint -ApplicationId $using:SPApplicationID -TenantId $using:SPTenantID							
						##	"$(get-date) - $env:computername Adding $using:AVDHostpoolAdmins to local FSLogix Exclude group "  | out-file c:\temp\AVDSettings.txt -Append						
						##	$i = 0
						##	$admingroup = Get-AzADGroup -DisplayName $using:AVDHostpoolAdmins
						##	$user = Get-AzureADGroupMember -ObjectId $admingroup.Id
						##	for ($i =0; $i -lt $user.Count; $i++) {$userprefixes += $user[$i].UserPrincipalName.Split("@")[0]}							
						## powershell:  foreach ($admin in $userprefixes){Add-LocalGroupMember -Group "FSLogix Profile Exclude List" -Member AzureAD\$admin -erroraction silentlycontinue}
						## powershell:  foreach ($admin in $userprefixes){Add-LocalGroupMember -Group "FSLogix ODFC Exclude List" -Member AzureAD\$admin -erroraction silentlycontinue}
						## cmd: foreach ($admin in $userprefixes){net localgroup "FSLogix Profile Exclude List" AzureAD\$admin /add}
						## cmd: foreach ($admin in $userprefixes){net localgroup "FSLogix ODFC Exclude List" AzureAD\$admin /add}
						
						
						#	$members = get-localgroup | get-localgroupmember -ErrorAction Ignore
						#	"$(get-date) - $env:computername Members of Local Administrators: $members"  | out-file c:\temp\AVDSettings.txt -Append						
						#	"$(get-date) - $env:computername Split Members of $using:AVDHostpoolAdmins... $userprefixes"  | out-file c:\temp\AVDSettings.txt -Append						
						#	$i = 0
						#	$a = 0
						#	$addFSLogixExcludes = foreach ($member in $members){for ($a =0; $a -lt $userprefixes.Count; $a++){if ($member.Name -ilike "*"+$userprefixes[$a]+"*"){if ($member.Name -ne $null){if ($userprefixes[$a] -ne $null){Add-LocalGroupMember -Group "FSLogix Profile Exclude List" -Member $member -erroraction Ignore}}}} if ($a -eq $userprefixes.Count) {$a = 0}}	
							
						Add-LocalGroupMember -Group "FSLogix Profile Exclude List" -Member $using:localAdminCredUser -erroraction silentlycontinue
						Add-LocalGroupMember -Group "FSLogix ODFC Exclude List" -Member $using:localAdminCredUser -erroraction silentlycontinue								
						
					
					}
						#Configure AzureAD Kerberos for Hybrid FSLogix:
						#"$(get-date) - $env:computername Configuring AzureAD Kerberos for Hybrid FSLogix..." | out-file c:\temp\AVDSettings.txt -Append
						#reg add HKLM\Software\Policies\Microsoft\AzureADAccount /v LoadCredKeyFromProfile /t REG_DWORD /d 1
						#reg add HKLM\SYSTEM\CurrentControlSet\Control\Lsa\Kerberos\Parameters /v CloudKerberosTicketRetrievalEnabled /t REG_DWORD /d 1
						
					
					"$(get-date) - $env:computername FSLogix disabled: $using:DisableFSLogix" | out-file c:\temp\AVDSettings.txt -Append
					
					"$(get-date) - $env:computername FSLogix Registry settings..." | out-file c:\temp\AVDSettings.txt -Append 
					Get-ItemProperty HKLM:\Software\FSLogix\Profiles | out-file c:\temp\AVDSettings.txt -Append 
					Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Services\frxccd\Parameters | out-file c:\temp\AVDSettings.txt -Append 
					Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Services\frxccds\Parameters | out-file c:\temp\AVDSettings.txt -Append 
					"$(get-date) - $env:computername FSLogix configuration done..." | out-file c:\temp\AVDSettings.txt -Append
							
							
					if ($env:computername -eq $using:FirstAVDHost)
					{	
						
							
						if ($using:SPUseCertAuth -eq $false)
						{								
						
							
							"$(get-date) - $env:computername Starting AVD Resource Group IAM and HostPool Assignment..." | out-file c:\temp\AVDSettings.txt -Append								
							#AVD Resource Group IAM and HostPool Assignment
							$graphUrl = "https://graph.microsoft.com/v1.0/groups?\$filter=displayName eq '$using:AVDHostpoolUsers'"
							$accessToken = Invoke-RestMethod -Method POST -Headers @{"Metadata"="true"} -Uri "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://graph.microsoft.com/" | Select-Object -ExpandProperty access_token
							
							$groups = Invoke-RestMethod -Method GET -Uri $graphUrl -Headers @{Authorization=("Bearer " + $accessToken)}
							if ($groups.value.Count -eq 0) {
								Write-Host "Group with name '$groupName' not found."
								return $null
							}
							$groupId = $groups.value[0].id
							return $groupId
							
							$VMUserLoginRole = Get-AzRoleDefinition "Virtual Machine User Login" # Role required for AAD logon to Azure VM's
							$VMAdminLoginRole = Get-AzRoleDefinition "Virtual Machine Administrator Login" # Role required for AAD Administrator logon to Azure VM's
							"$(get-date) - $env:computername Adding $using:AVDHostpoolUsers to Virtual Desktop User Login role... " | out-file c:\temp\AVDSettings.txt -Append								
							foreach ($Group in $using:AVDHostpoolUsers) {
								
								try {
									$VMUserLoginGroup = @{
										ObjectId           = $groupId
										RoleDefinitionName = $VMUserLoginRole.Name
										ResourceGroupName = $using:ResourceGroupNameAVD
										ErrorAction        = "Ignore"
									}
									New-AzRoleAssignment @VMUserLoginGroup
									
								}
								catch {
									"$(get-date) - $env:computername Failed to add $using:AVDHostpoolUsers to $VMUserLoginRole.Name... "
								}
							}
							
							"$(get-date) - $env:computername Adding $using:AVDHostpoolAdmins to Virtual Desktop Administrator Login role... " | out-file c:\temp\AVDSettings.txt -Append
							$graphUrl = "https://graph.microsoft.com/v1.0/groups?\$filter=displayName eq '$using:AVDHostpoolAdmins'"
							$accessToken = Invoke-RestMethod -Method POST -Headers @{"Metadata"="true"} -Uri "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://graph.microsoft.com/" | Select-Object -ExpandProperty access_token
							
							$groups = Invoke-RestMethod -Method GET -Uri $graphUrl -Headers @{Authorization=("Bearer " + $accessToken)}
							if ($groups.value.Count -eq 0) {
								Write-Host "Group with name '$groupName' not found."
								return $null
							}
							$groupId = $groups.value[0].id
							return $groupId
							foreach ($Group in $using:AVDHostpoolAdmins) {
								
								try {
									$VMAdminLoginGroup = @{
										ObjectId           = $groupId
										RoleDefinitionName = $VMAdminLoginRole.Name
										ResourceGroupName = $using:ResourceGroupNameAVD
										ErrorAction        = "Ignore"
									}
									New-AzRoleAssignment @VMAdminLoginGroup
									
								}
								catch {
									"$(get-date) - $env:computername Failed to add $using:AVDHostpoolAdmins to Virtual Desktop Administrator Login... "  | out-file c:\temp\AVDSettings.txt -Append
								}
							}
							# Add AVD Assignment Groups
							"$(get-date) - $env:computername Adding $using:AVDHostpoolUsers to AVD Application User Access Group Assignment... " | out-file c:\temp\AVDSettings.txt -Append
							$graphUrl = "https://graph.microsoft.com/v1.0/groups?\$filter=displayName eq '$using:AVDHostpoolUsers'"
							$accessToken = Invoke-RestMethod -Method POST -Headers @{"Metadata"="true"} -Uri "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://graph.microsoft.com/" | Select-Object -ExpandProperty access_token
							
							$groups = Invoke-RestMethod -Method GET -Uri $graphUrl -Headers @{Authorization=("Bearer " + $accessToken)}
							if ($groups.value.Count -eq 0) {
								Write-Host "Group with name '$groupName' not found."
								return $null
							}
							$groupId = $groups.value[0].id
							return $groupId
							foreach ($Group in $using:AVDHostpoolUsers) {
								
								try {
									# Get the object ID of the user group you want to assign to the application group
									$userGroupId = $groupId
					
									# Assign users to the application group
									$parameters = @{
										ObjectId = $userGroupId
										ResourceName = "$using:AppGroupName"
										ResourceGroupName = "$using:ResourceGroupNameAVD"
										RoleDefinitionName = 'Desktop Virtualization User'
										ResourceType = 'Microsoft.DesktopVirtualization/applicationGroups'
										ErrorAction        = "Ignore"
									}
					
									New-AzRoleAssignment @parameters
									#Write-Log -Message "Successfully added application group assignment" -Level Info
								}
								catch {
									"$(get-date) - $env:computername Failed to add $using:AVDHostpoolUsers to User Access Group Assignment... "  | out-file c:\temp\AVDSettings.txt -Append
								}
							}
							$graphUrl = "https://graph.microsoft.com/v1.0/groups?\$filter=displayName eq '$using:AVDHostpoolAdmins'"
							$accessToken = Invoke-RestMethod -Method POST -Headers @{"Metadata"="true"} -Uri "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://graph.microsoft.com/" | Select-Object -ExpandProperty access_token
							
							$groups = Invoke-RestMethod -Method GET -Uri $graphUrl -Headers @{Authorization=("Bearer " + $accessToken)}
							if ($groups.value.Count -eq 0) {
								Write-Host "Group with name '$groupName' not found."
								return $null
							}
							$groupId = $groups.value[0].id
							
							"$(get-date) - $env:computername Adding $using:AVDHostpoolAdmins to AVD Application User Access Group Assignment... " | out-file c:\temp\AVDSettings.txt -Append
							foreach ($Group in $using:AVDHostpoolAdmins) {
								
								try {
									# Get the object ID of the user group you want to assign to the application group
									$userGroupId = $groupId
					
									# Assign users to the application group
									$parameters = @{
										ObjectId = $userGroupId
										ResourceName = "$using:AppGroupName"
										ResourceGroupName = "$using:ResourceGroupNameAVD"
										RoleDefinitionName = 'Desktop Virtualization User'
										ResourceType = 'Microsoft.DesktopVirtualization/applicationGroups'
										ErrorAction        = "Ignore"
									}
					
									New-AzRoleAssignment @parameters
									#Write-Log -Message "Successfully added application group assignment" -Level Info
								}
								catch {
									"$(get-date) - $env:computername Failed to add $using:AVDHostpoolAdmins to AVD User Access Group Assignment... "  | out-file c:\temp\AVDSettings.txt -Append
								}
							}
							
							
						}
						else
						{	
							"$(get-date) - $env:computername FirstAVDHost - Using SPCertAuth...." | out-file c:\temp\AVDSettings.txt -Append				
							Connect-AzAccount -CertificateThumbprint $using:SPCertificateThumbprint -ApplicationId $using:SPApplicationID -TenantId $using:SPTenantID -Subscription $using:Subscription
							Set-AzContext -Subscription $using:SubscriptionId
							"$(get-date) - $env:computername Az Context:" | out-file c:\temp\AVDSettings.txt -Append
							Get-AzContext | out-file c:\temp\AVDSettings.txt -Append
							#Connect to AzureAD using SP:						
							Connect-AzureAD -CertificateThumbprint $using:SPCertificateThumbprint -ApplicationId $using:SPApplicationID -TenantId $using:SPTenantID								
							"$(get-date) - $env:computername Starting AVD Resource Group IAM and HostPool Assignment..." | out-file c:\temp\AVDSettings.txt -Append								
							
							
							
							
							#AVD Resource Group IAM and HostPool Assignment
							$VMUserLoginRole = Get-AzRoleDefinition "Virtual Machine User Login" # Role required for AAD logon to Azure VM's
							$VMAdminLoginRole = Get-AzRoleDefinition "Virtual Machine Administrator Login" # Role required for AAD Administrator logon to Azure VM's
							"$(get-date) - $env:computername Adding $using:AVDHostpoolUsers to UserLogin... " | out-file c:\temp\AVDSettings.txt -Append								
							foreach ($Group in $using:AVDHostpoolUsers) {
								
								try {
									$VMUserLoginGroup = @{
										ObjectId           = (Get-AzADGroup -SearchString $Group).Id
										RoleDefinitionName = $VMUserLoginRole.Name
										ResourceGroupName = $using:ResourceGroupNameAVD
										ErrorAction        = "Ignore"
									}
									New-AzRoleAssignment @VMUserLoginGroup
									
								}
								catch {
									"$(get-date) - $env:computername Failed to add $using:AVDHostpoolUsers to $VMUserLoginRole.Name... "
								}
							}
							"$(get-date) - $env:computername Adding $using:AVDHostpoolAdmins to Virtual Desktop Administrator Login... " | out-file c:\temp\AVDSettings.txt -Append
							foreach ($Group in $using:AVDHostpoolAdmins) {
								
								try {
									$VMAdminLoginGroup = @{
										ObjectId           = (Get-AzADGroup -SearchString $Group).Id
										RoleDefinitionName = $VMAdminLoginRole.Name
										ResourceGroupName = $using:ResourceGroupNameAVD
										ErrorAction        = "Ignore"
									}
									New-AzRoleAssignment @VMAdminLoginGroup
									
								}
								catch {
									"$(get-date) - $env:computername Failed to add $using:AVDHostpoolAdmins to Virtual Desktop Administrator Login... "  | out-file c:\temp\AVDSettings.txt -Append
								}
							}
							
							# Add AVD Assignment Groups
							"$(get-date) - $env:computername Adding $using:AVDHostpoolUsers to AVD Application User Access Group Assignment... " | out-file c:\temp\AVDSettings.txt -Append
							foreach ($Group in $using:AVDHostpoolUsers) {
								
								try {
									# Get the object ID of the user group you want to assign to the application group
									$userGroupId = (Get-AzADGroup -DisplayName "$using:AVDHostpoolUsers").Id
					 
									# Assign users to the application group
									$parameters = @{
										ObjectId = $userGroupId
										ResourceName = "$using:AppGroupName"
										ResourceGroupName = "$using:ResourceGroupNameAVD"
										RoleDefinitionName = 'Desktop Virtualization User'
										ResourceType = 'Microsoft.DesktopVirtualization/applicationGroups'
										ErrorAction        = "Ignore"
									}
					 
									New-AzRoleAssignment @parameters
									#Write-Log -Message "Successfully added application group assignment" -Level Info
								}
								catch {
									"$(get-date) - $env:computername Failed to add $using:AVDHostpoolUsers to User Access Group Assignment... "  | out-file c:\temp\AVDSettings.txt -Append
								}
							}
							
							"$(get-date) - $env:computername Adding $using:AVDHostpoolAdmins to AVD Application User Access Group Assignment... " | out-file c:\temp\AVDSettings.txt -Append
							foreach ($Group in $using:AVDHostpoolAdmins) {
								
								try {
									# Get the object ID of the user group you want to assign to the application group
									$userGroupId = (Get-AzADGroup -DisplayName "$using:AVDHostpoolAdmins").Id
					 
									# Assign users to the application group
									$parameters = @{
										ObjectId = $userGroupId
										ResourceName = "$using:AppGroupName"
										ResourceGroupName = "$using:ResourceGroupNameAVD"
										RoleDefinitionName = 'Desktop Virtualization User'
										ResourceType = 'Microsoft.DesktopVirtualization/applicationGroups'
										ErrorAction        = "Ignore"
									}
					 
									New-AzRoleAssignment @parameters
									#Write-Log -Message "Successfully added application group assignment" -Level Info
								}
								catch {
									"$(get-date) - $env:computername Failed to add $using:AVDHostpoolAdmins to AVD User Access Group Assignment... "  | out-file c:\temp\AVDSettings.txt -Append
								}
							}							
							
							#Update AVD Desktop Friendly name
							"$(get-date) - $env:computername Updating Friendly SessionDesktop name for $using:AppGroupName in $using:ResourceGroupNameAVD  ... " | out-file c:\temp\AVDSettings.txt -Append
							Update-AzWvdDesktop -ResourceGroupName $using:ResourceGroupNameAVD -ApplicationGroupName $using:AppGroupName -Name SessionDesktop -FriendlyName $using:FriendlyVDI
							Start-Sleep -Seconds 5
							
							
						}
					}
			
					"$(get-date) - $env:computername Finished settings AVD config..." | out-file c:\temp\AVDSettings.txt -Append
							
							
					}		
				}
			
				TestScript =
				{
					Return $false
					
					#$AVDConfigDone = Get-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name AVDconfig_Done -erroraction ignore
					#if ($AVDConfigDone -eq $null)
					#{
					#	$false
					#}else{
					#	$true
					#}					
				}
				
			}
			
			Script Afterconfig
			{
					GetScript = 
					{
						Return $@{}
					}
				
					SetScript =
					{	
						#$AfterconfigDone = Get-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name Afterconfig_Done -erroraction ignore
						#if ($AfterconfigDone -eq $null)
						#{	
					
					
							"$(get-date) - $env:computername Starting Afterconfig..." | out-file c:\temp\AVDSettings.txt -Append
							#Running Afterconfig script
							PowerShell.exe -ExecutionPolicy Bypass -File c:\temp\Afterconfig.ps1
							#New-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name Afterconfig_Done -Value "DON'T REMOVE! Required for correct DSC rerun of Afterconfig." -force
						#}
					
					}
					TestScript =
					{		
						Return $false
						#$AfterconfigDone = Get-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name Afterconfig_Done -erroraction ignore
						#if ($AfterconfigDone -eq $null)
						#{
						#	$false
						#}else{
						#	$true
						#}					
					}
					#DependsOn =  "[script]AVDLocalSettings"
			}
			
			$DutchConfig =  Get-WinDefaultInputMethodOverride
			if ($DutchConfig.InputMethodTip -eq "0413:00020409")
			{}
			else
			{
				Script Dutch_OS
				{		
					Credential = $LACred	
					GetScript = 
					{
						Return $@{}
					}
				
					SetScript =
					{	
						$DutchOSDone = Get-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name DutchOS_Done -erroraction ignore
						if ($DutchOSDone -eq $null)
						{
							if ($using:DutchOS -eq $true)
								{									
									$language = "nl-NL"
									$geoId = "176" 													
									Install-Language $language -CopyToSettings -ErrorAction ignore
									Set-SystemPreferredUILanguage $language -ErrorAction ignore
									Set-WinUILanguageOverride -Language $language -ErrorAction ignore
									$OldList = Get-WinUserLanguageList
									$UserLanguageList = New-WinUserLanguageList -Language $language
									$UserLanguageList += $OldList | where { $_.LanguageTag -ne $language }
									$UserLanguageList | select LanguageTag
									Set-WinUserLanguageList -LanguageList $UserLanguageList -Force -ErrorAction ignore
									Set-Culture -CultureInfo $language -ErrorAction ignore
									Set-WinHomeLocation -GeoId $geoId -ErrorAction ignore
									Set-WinDefaultInputMethodOverride "0413:00020409"
									Copy-UserInternationalSettingsToSystem -WelcomeScreen $True -NewUser $True -ErrorAction ignore
									Get-CimInstance -Namespace "root\cimv2\mdm\dmmap" -ClassName "MDM_EnterpriseModernAppManagement_AppManagement01" | Invoke-CimMethod -MethodName "UpdateScanMethod"	

									"$(get-date) - $env:computername Region Config parameters" | out-file c:\temp\RegionAVDSettings.txt -Append
									"$(get-date) - $env:computername WhoAmI" | out-file c:\temp\RegionAVDSettings.txt -Append
									whoami | out-file c:\temp\RegionAVDSettings.txt -Append
									"$(get-date) - $env:computername Get-WinUILanguageOverride" | out-file c:\temp\RegionAVDSettings.txt -Append
									Get-WinUILanguageOverride | out-file c:\temp\RegionAVDSettings.txt -Append
									"$(get-date) - $env:computername Get-WinUserLanguageList" | out-file c:\temp\RegionAVDSettings.txt -Append
									Get-WinUserLanguageList | out-file c:\temp\RegionAVDSettings.txt -Append
									"$(get-date) - $env:computername Get-Culture" | out-file c:\temp\RegionAVDSettings.txt -Append
									Get-Culture | out-file c:\temp\RegionAVDSettings.txt -Append
									"$(get-date) - $env:computername Get-WinHomeLocation" | out-file c:\temp\RegionAVDSettings.txt -Append
									Get-WinHomeLocation | out-file c:\temp\RegionAVDSettings.txt -Append
									"$(get-date) - $env:computername Get-WinDefaultInputMethodOverride" | out-file c:\temp\RegionAVDSettings.txt -Append
									Get-WinDefaultInputMethodOverride | out-file c:\temp\RegionAVDSettings.txt -Append	
																		
								}	
								
								$DutchConfig =  Get-WinDefaultInputMethodOverride
								if ($DutchConfig.InputMethodTip -eq "0413:00020409")
								{								
								New-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name DutchOS_Done -Value "DON'T REMOVE! Required for correct DSC rerun of DutchOS." -force
								}								
							
						}
					}
					TestScript =
					{						
						$DutchOSDone = Get-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name DutchOS_Done -erroraction ignore
						if ($DutchOSDone -eq $null)
						{
							$false
						}else{
							$true
						}						
					}
					
			}
			}
			Script CleanUp
			{
				GetScript = 
				{
					Return $@{}
				}
			
				SetScript =
				{	$ResizeDone = Get-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name Resize_Done -erroraction ignore
					if ($ResizeDone -eq $null)
					{	
				
						"$(get-date) - $env:computername Resizing Disk..." | out-file c:\temp\AVDSettings.txt -Append
						#Resize C: partition to max
						$ErrorOccured1 = $false
						$supportedSize = (Get-PartitionSupportedSize -DriveLetter C)
						if ($SupportedSize.SizeMax -ne $supportedSize.Size)
						{
							do
							{
								
								try 
									{
										Resize-Partition -DriveLetter C -Size $supportedSize.SizeMax -ErrorAction Ignore
										$ErrorOccured1 = $false
									}
								catch 
									{
										$ErrorOccured1 = $true								
										Start-Sleep 5 
									}
								
							}
							while ($ErrorOccured1 -eq $true)
						}
						New-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name Resize_Done -Value "DON'T REMOVE! Required for correct DSC rerun of disk resize." -force	
					}
					
					##Cleanup				
					if ($using:DebugDSCDeployment -eq $false)
					{	"$(get-date) - $env:computername Starting Cleanup..." | out-file c:\temp\AVDSettings.txt -Append
						
						 
						 #Remove automation pfx
						 "$(get-date) - $env:computername Removing Automation Certificates..." | out-file c:\temp\AVDSettings.txt -Append
						 Get-ChildItem C:\Packages\Plugins\Microsoft.Powershell.DSC -Filter $Using:SPCertificateName -Recurse | % { $_.FullName } | remove-item
						 Get-ChildItem -path Cert:\*$Using:SPCertificateThumbprint -Recurse | remove-item	
						
						if ($using:Tools -eq $true)
						{	
							if (Test-Path c:\Temp) 
								{	"$(get-date) - $env:computername Running Tempfolder Cleanup..." | out-file c:\temp\AVDSettings.txt -Append
									Get-ChildItem -Path C:\Temp\* -Exclude 'NM34_x64.exe','Get-IntuneManagementExtensionDiagnostics.ps1','cis.zip' | ForEach-Object {Remove-Item $_ -Recurse }
								} 							
							
						}
						else 
						{								
							if (Test-Path c:\Temp) 
								{	"$(get-date) - $env:computername Running Tempfolder Cleanup..." | out-file c:\temp\AVDSettings.txt -Append
									Get-ChildItem -Path C:\Temp\* | ForEach-Object {Remove-Item $_ -Recurse }
								} 
							
						}												
						#Setting Finished Cleanup
						
						#New-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name Cleanup_Done -Value "DON'T REMOVE! Required for correct DSC rerun of installation file cleanup." -force	
												
					}
					
					$RebootDone = Get-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name Reboot_Done -erroraction ignore 						
					if ($RebootDone -eq $null)	
					{
						#This triggers the reboot
						"$(get-date) - $env:computername AVD Configuration done...rebooting..." | out-file c:\temp\AVDConfigDone.txt -Append
						New-Item -Path HKLM:\SOFTWARE\MyMainKey\RebootKey -Force
						$global:DSCMachineStatus = 1 
						New-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name Reboot_Done -Value "DON'T REMOVE! Required for correct DSC rerun of AVD host reboot." -force	
					}
				}
				TestScript =
				{		
					Return $false				
					#$CleanupDone = Get-ItemProperty -Path HKLM:\SOFTWARE\AVDConfig_Status -Name Cleanup_Done -erroraction ignore
					#	if ($CleanupDone -eq $null)
					#	{
					#		$false
					#	}else{
					#		$true
					#	}				
				}
				#DependsOn =  "[script]Afterconfig"
				
			}
			
			Script Disable_FSLogix
			{
					GetScript = 
					{
						Return $@{}
					}
				
					SetScript =
					{	
						if ($using:DisableFSLogix -eq $true)
						{	
							if (Test-Path HKLM:\SOFTWARE\FSLogix\Profiles)
							{
							 Set-ItemProperty -Path HKLM:\SOFTWARE\FSLogix\Profiles -Name Enabled -Value 0
							}
						}

						#Set Proxy
						if ($using:UseProxy -eq $true)
						{
							#Configuring System-wide Proxy
							Import-Module -Name "C:\Program Files\WindowsPowerShell\Modules\WinInetProxy\WinInetProxy.psd1" -Erroraction silentlycontinue
							Set-WinInetProxy -ProxySettingsPerUser 0 -ProxyServer $using:ProxyValue -ProxyBypass $using:ProxyBypass -AutoDetect 1
						}
						else
						{
							#Configuring System-wide Proxy
							Import-Module -Name "C:\Program Files\WindowsPowerShell\Modules\WinInetProxy\WinInetProxy.psd1" -Erroraction silentlycontinue
							Set-WinInetProxy -AutoDetect 1
						}							
					
					}
					TestScript =
					{
						Return $false					
					}
					
			}

			xPendingReboot Reboot
			{
				Name = "Reboot"				
			}
		}			
	}	
}